const test = require('node:test'), assert = require('node:assert'), fs = require('fs'), vm = require('vm');
for (const f of ['main.js', 'preload.js', 'src/renderer.js'])
  test('sintaxe válida: ' + f, () => { new vm.Script(fs.readFileSync(f, 'utf8'), { filename: f }); });
test('package.json completo', () => {
  const p = JSON.parse(fs.readFileSync('package.json', 'utf8'));
  assert.ok(p.main && p.build.productName && p.dependencies.sharp);
});
test('HTML referencia arquivos existentes', () => {
  const h = fs.readFileSync('src/index.html', 'utf8');
  for (const m of h.matchAll(/(?:src|href)="([^"]+\.(?:js|css))"/g)) assert.ok(fs.existsSync('src/' + m[1]), m[1]);
});
