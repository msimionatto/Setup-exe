const { app, BrowserWindow, ipcMain, dialog, nativeImage, shell } = require('electron');
const path = require('path');
const fs = require('fs');

if (!app.requestSingleInstanceLock()) app.quit();
const D = n => path.join(app.getPath('userData'), n);
const dbFile = () => D('albums.json');
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const IMG = ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp'];
let win;
const crypto = require('crypto');
let sharp = null; try { sharp = require('sharp'); } catch {}

const log = msg => fs.appendFile(D('app.log'), `${new Date().toISOString()} ${msg}\n`, () => {});
process.on('uncaughtException', e => log('uncaught: ' + e.stack));
const stateFile = () => D('window.json');
function createWindow() {
  let s = {}; try { s = JSON.parse(fs.readFileSync(stateFile(), 'utf8')); } catch {}
  win = new BrowserWindow({
    width: s.width || 1280, height: s.height || 800, x: s.x, y: s.y, minWidth: 900, minHeight: 600,
    backgroundColor: '#0a1220', title: 'Meu Álbum', autoHideMenuBar: true,
    icon: path.join(__dirname, 'imagens', 'Logo.ico'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true }
  });
  if (s.max) win.maximize();
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));   // bloqueia janelas externas
  win.webContents.on('will-navigate', e => e.preventDefault());       // bloqueia navegação
  win.on('close', () => { try { fs.writeFileSync(stateFile(), JSON.stringify({ ...win.getNormalBounds(), max: win.isMaximized() })); } catch {} });
  win.loadFile(path.join(__dirname, 'src', 'index.html'));
}
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
function setupUpdater() {                      // atualização automática via GitHub Releases
  if (!app.isPackaged) return;
  try {
    const { autoUpdater } = require('electron-updater');
    autoUpdater.on('update-downloaded', () => win?.webContents.send('update:ready'));
    autoUpdater.on('error', e => log('updater: ' + e.message));
    autoUpdater.checkForUpdatesAndNotify().catch(e => log('updater: ' + e.message));
  } catch (e) { log('updater indisponível: ' + e.message); }
}
app.whenReady().then(() => {
  ['photos', 'covers', 'thumbs'].forEach(d => fs.mkdirSync(D(d), { recursive: true }));
  createWindow();
  setupUpdater();
});
app.on('window-all-closed', () => app.quit());

/* ---- helpers ---- */
async function makeThumb(src, id) {          // sharp respeita a orientação EXIF; nativeImage é o plano B
  const f = id + '.jpg', out = path.join(D('thumbs'), f);
  try {
    if (sharp) { await sharp(src).rotate().resize({ width: 400, withoutEnlargement: true }).jpeg({ quality: 80 }).toFile(out); return f; }
    const img = nativeImage.createFromPath(src), { width } = img.getSize();
    if (!width) return null;
    fs.writeFileSync(out, (width > 400 ? img.resize({ width: 400, quality: 'good' }) : img).toJPEG(80));
    return f;
  } catch (e) { log('miniatura: ' + e.message); return null; }
}
async function importPaths(paths) {          // assíncrono, com progresso e tolerância a falhas
  const valid = paths.filter(p => IMG.includes(path.extname(p).slice(1).toLowerCase())), out = [];
  let done = 0;
  for (const p of valid) {
    try {
      const id = uid(), file = id + path.extname(p).toLowerCase(), dest = path.join(D('photos'), file);
      await fs.promises.copyFile(p, dest);
      const hash = crypto.createHash('sha1').update(await fs.promises.readFile(dest)).digest('hex');
      out.push({ id, file, thumb: await makeThumb(dest, id), hash });
    } catch (e) { log(`import falhou (${p}): ${e.message}`); if (e.code === 'ENOSPC') throw new Error('Disco cheio: libere espaço e tente novamente'); }
    win?.webContents.send('import:progress', { done: ++done, total: valid.length });
    await new Promise(r => setImmediate(r));
  }
  return out;
}
async function squareCover(src) {
  const f = uid() + '.png', out = path.join(D('covers'), f);
  if (sharp) { await sharp(src).rotate().resize(500, 500, { fit: 'cover' }).png().toFile(out); return f; }
  let img = nativeImage.createFromPath(src);
  const { width, height } = img.getSize(), s = Math.min(width, height);
  img = img.crop({ x: Math.floor((width - s) / 2), y: Math.floor((height - s) / 2), width: s, height: s }).resize({ width: 500, height: 500, quality: 'best' });
  fs.writeFileSync(out, img.toPNG());
  return f;
}
const pick = (title, multi) => dialog.showOpenDialog({
  title, properties: multi ? ['openFile', 'multiSelections'] : ['openFile'],
  filters: [{ name: 'Imagens', extensions: IMG }]
});

/* ---- IPC ---- */
ipcMain.handle('db:load', () => {
  let albums = [];
  for (const f of [dbFile(), dbFile() + '.bak']) {
    try { albums = JSON.parse(fs.readFileSync(f, 'utf8')); break; } catch {}
  }
  return { albums, dir: app.getPath('userData') };
});
ipcMain.handle('db:save', (_, albums) => {          // gravação atômica + cópia de segurança
  const f = dbFile(), tmp = f + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(albums, null, 2));
  if (fs.existsSync(f)) fs.copyFileSync(f, f + '.bak');
  fs.renameSync(tmp, f);
  return true;
});
ipcMain.handle('photos:pick', async () => { const r = await pick('Adicionar fotos', true); return r.canceled ? [] : importPaths(r.filePaths); });
ipcMain.handle('photos:import', (_, paths) => importPaths(paths));
ipcMain.handle('photos:copy', (_, photos) => importPaths(photos.map(p => path.join(D('photos'), p.file))));
ipcMain.handle('cover:pick', async () => { const r = await pick('Escolher capa', false); return r.canceled ? null : squareCover(r.filePaths[0]); });
ipcMain.handle('cover:fromPhoto', (_, file) => squareCover(path.join(D('photos'), file)));
ipcMain.handle('files:delete', (_, { kind, files }) => {
  const rm = (d, f) => { try { fs.unlinkSync(path.join(D(d), f)); } catch {} };
  files.forEach(f => { if (kind === 'cover') rm('covers', f); else { rm('photos', f.file); if (f.thumb) rm('thumbs', f.thumb); } });
  return true;
});

const chooseDir = title => dialog.showOpenDialog({ title, properties: ['openDirectory', 'createDirectory'] });
const SUB = ['photos', 'covers', 'thumbs'];
ipcMain.handle('backup:export', async () => {
  const r = await chooseDir('Escolha a pasta do backup'); if (r.canceled) return false;
  const dest = path.join(r.filePaths[0], 'MeuAlbum-Backup-' + new Date().toISOString().slice(0, 10));
  await fs.promises.mkdir(dest, { recursive: true });
  for (const n of SUB) await fs.promises.cp(D(n), path.join(dest, n), { recursive: true });
  if (fs.existsSync(dbFile())) fs.copyFileSync(dbFile(), path.join(dest, 'albums.json'));
  return true;
});
ipcMain.handle('backup:restore', async () => {
  const r = await chooseDir('Escolha a pasta do backup'); if (r.canceled) return false;
  const src = r.filePaths[0];
  if (!fs.existsSync(path.join(src, 'albums.json'))) throw new Error('Pasta de backup inválida');
  for (const n of SUB) if (fs.existsSync(path.join(src, n))) await fs.promises.cp(path.join(src, n), D(n), { recursive: true, force: true });
  fs.copyFileSync(path.join(src, 'albums.json'), dbFile());
  return true;
});
ipcMain.handle('album:export', async (_, a) => {
  const r = await chooseDir('Exportar álbum para…'); if (r.canceled) return null;
  const dir = path.join(r.filePaths[0], a.name.replace(/[<>:"/\\|?*]/g, '_').trim() || 'Album');
  await fs.promises.mkdir(dir, { recursive: true });
  let n = 0;
  for (const [i, p] of a.photos.entries()) {
    try { await fs.promises.copyFile(path.join(D('photos'), p.file), path.join(dir, String(i + 1).padStart(3, '0') + path.extname(p.file))); n++; }
    catch (e) { log('export: ' + e.message); }
  }
  fs.writeFileSync(path.join(dir, 'LEIA-ME.txt'), `${a.name}\n\n${a.desc || ''}\n\n${n} foto(s)`);
  shell.openPath(dir);
  return n;
});

async function dirSize(d) { let t = 0; try { for (const f of await fs.promises.readdir(d)) t += (await fs.promises.stat(path.join(d, f))).size; } catch {} return t; }
ipcMain.handle('app:info', async () => ({
  version: app.getVersion(),
  size: (await Promise.all(SUB.map(n => dirSize(D(n))))).reduce((a, b) => a + b, 0)
}));
ipcMain.handle('app:repo', () => shell.openExternal('https://github.com/msimionatto/MPhotos'));
ipcMain.handle('photo:info', async (_, file) => {
  const p = path.join(D('photos'), file), st = await fs.promises.stat(p);
  let w = 0, h = 0;
  try {
    if (sharp) { const md = await sharp(p).metadata(); w = md.width; h = md.height; }
    else { const s = nativeImage.createFromPath(p).getSize(); w = s.width; h = s.height; }
  } catch {}
  return { size: st.size, width: w, height: h, added: st.birthtimeMs };
});
