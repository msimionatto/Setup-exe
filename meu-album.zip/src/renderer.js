let albums = [], dataDir = '';
let currentId = null, query = '', selectMode = false, selected = new Set();
const $ = s => document.querySelector(s);
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const url = (sub, f) => 'file:///' + dataDir.replace(/\\/g, '/') + '/' + sub + '/' + encodeURIComponent(f);
const thumbUrl = p => p.thumb ? url('thumbs', p.thumb) : url('photos', p.file);
let dragId = null, sortBy = 'recent', lastSel = -1, onlyFav = false, trashView = false, infoOpen = false;
const active = () => albums.filter(a => !a.deletedAt);
const fmtSize = b => b > 1e9 ? (b / 1e9).toFixed(2) + ' GB' : (b / 1e6).toFixed(1) + ' MB';
const hay = a => [a.name, a.desc, ...a.photos.map(p => (p.caption || '') + ' ' + (p.tags || []).join(' '))].join(' ').toLowerCase();
const statsHtml = () => {
  const act = active(), st = (t, v) => `<div class="stat"><b>${v}</b><small>${t}</small></div>`;
  return `<div class="stats">${st('Álbuns', act.length)}${st('Fotos', act.reduce((n, a) => n + a.photos.length, 0))}${st('Favoritas', act.reduce((n, a) => n + a.photos.filter(p => p.fav).length, 0))}<div class="stat"><b id="stSize">…</b><small>Espaço usado</small></div></div>`;
};
const sorted = () => active().sort(sortBy === 'name' ? (a, b) => a.name.localeCompare(b.name, 'pt-BR') : sortBy === 'count' ? (a, b) => b.photos.length - a.photos.length : (a, b) => b.created - a.created);
const persist = () => api.save(albums);
const current = () => albums.find(a => a.id === currentId);
const plural = n => n === 1 ? '1 foto' : n + ' fotos';

function toast(msg, act, fn) {
  const t = $('#toast');
  t.innerHTML = esc(msg) + (act ? ` <button id="tAct">${esc(act)}</button>` : '');
  t.classList.toggle('act', !!act); t.classList.add('show');
  if (act) $('#tAct').onclick = () => { fn(); t.classList.remove('show'); };
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), act ? 6000 : 2200);
}

/* ---------- Modais ---------- */
function openModal(html) {
  $('#modalRoot').innerHTML = `<div class="overlay"><div class="modal" role="dialog" aria-modal="true">${html}</div></div>`;
  $('.modal').querySelector('input,textarea,button')?.focus();
}
function closeModal() { $('#modalRoot').innerHTML = ''; }

function confirmBox(title, text, okLabel) {
  return new Promise(res => {
    openModal(`<h3>${esc(title)}</h3><p style="color:var(--muted);line-height:1.5">${esc(text)}</p>
      <div class="actions"><button class="btn" id="cNo">Cancelar</button><button class="btn danger" id="cYes">${esc(okLabel)}</button></div>`);
    $('#cNo').onclick = () => { closeModal(); res(false); };
    $('#cYes').onclick = () => { closeModal(); res(true); };
  });
}

function albumForm(album) {
  const editing = !!album;
  let cover = album?.cover || null, newCover = null;
  openModal(`<h3>${editing ? 'Editar álbum' : 'Criar álbum'}</h3>
    <label>Nome</label><input type="text" id="fName" maxlength="60" value="${esc(album?.name)}" placeholder="Ex.: Viagem à serra">
    <label>Descrição</label><textarea id="fDesc" rows="3" maxlength="300" placeholder="Conte do que se trata este álbum">${esc(album?.desc)}</textarea>
    <label>Capa</label>
    <div class="cover-pick"><div id="fPrev"></div>
      <div><button class="btn" id="fPick">Escolher imagem</button><small>Será salva em PNG 500×500</small></div></div>
    <div class="actions"><button class="btn" id="fCancel">Cancelar</button><button class="btn primary" id="fOk">${editing ? 'Salvar alterações' : 'Criar álbum'}</button></div>`);
  const prev = () => $('#fPrev').innerHTML = cover ? `<img src="${url('covers', cover)}">` : '<div class="ph">🖼</div>';
  prev(); $('#fName').focus();
  $('#fPick').onclick = async () => {
    const f = await api.pickCover(); if (!f) return;
    if (newCover) api.deleteFiles('cover', [newCover]);
    newCover = cover = f; prev();
  };
  $('#fCancel').onclick = () => { if (newCover) api.deleteFiles('cover', [newCover]); closeModal(); };
  $('#fOk').onclick = async () => {
    const name = $('#fName').value.trim();
    if (!name) { toast('Dê um nome ao álbum'); return; }
    const desc = $('#fDesc').value.trim();
    if (editing) {
      if (newCover && album.cover) api.deleteFiles('cover', [album.cover]);
      Object.assign(album, { name, desc, cover });
      toast('Álbum atualizado');
    } else {
      const a = { id: uid(), name, desc, cover, photos: [], created: Date.now() };
      albums.unshift(a); currentId = a.id; toast('Álbum criado');
    }
    await persist(); closeModal(); render();
  };
}

/* ---------- Ações ---------- */
async function addList(list, a = current()) {
  const seen = new Set(a.photos.map(p => p.hash).filter(Boolean)), fresh = [], dups = [];
  list.forEach(p => { if (p.hash && seen.has(p.hash)) dups.push(p); else { fresh.push(p); if (p.hash) seen.add(p.hash); } });
  if (dups.length) api.deleteFiles('photo', dups);                       // descarta cópias duplicadas
  if (fresh.length) { a.photos.push(...fresh); await persist(); render(); }
  toast(fresh.length ? `${plural(fresh.length)} adicionada(s)` + (dups.length ? ` · ${dups.length} duplicada(s) ignorada(s)` : '') : `${dups.length} duplicada(s) ignorada(s)`);
}
const addPhotos = async () => addList(await api.pickPhotos());

let pending = null;
function finalize() {
  if (!pending) return;
  clearTimeout(pending.t); api.deleteFiles('photo', pending.items.map(i => i.p)); pending = null;
}
async function removePhotos(ids) {
  finalize();
  const a = current(), items = [];
  a.photos.forEach((p, i) => { if (ids.includes(p.id)) items.push({ p, i }); });
  a.photos = a.photos.filter(p => !ids.includes(p.id));
  await persist(); selected.clear(); render();
  pending = { t: setTimeout(finalize, 6500), items };
  toast(`${plural(items.length)} excluída(s)`, 'Desfazer', async () => {
    const pd = pending; if (!pd) return;
    clearTimeout(pd.t); pending = null;
    pd.items.forEach(({ p, i }) => a.photos.splice(Math.min(i, a.photos.length), 0, p));
    await persist(); render();
  });
}
async function setCover(p) {
  const a = current(), f = await api.coverFromPhoto(p.file); if (!f) return;
  if (a.cover) api.deleteFiles('cover', [a.cover]);
  a.cover = f; await persist(); render(); toast('Capa atualizada');
}
function pickTarget(mode) {
  const others = active().filter(a => a.id !== currentId);
  if (!others.length) { toast('Crie outro álbum primeiro'); return; }
  openModal(`<h3>${mode === 'move' ? 'Mover' : 'Copiar'} ${plural(selected.size)} para…</h3>
    <div class="targets">${others.map(a => `<button class="side-item" data-id="${a.id}">
      ${a.cover ? `<img src="${url('covers', a.cover)}">` : '<div class="ph">🖼</div>'}
      <div><b>${esc(a.name)}</b><small>${plural(a.photos.length)}</small></div></button>`).join('')}</div>
    <div class="actions"><button class="btn" id="tNo">Cancelar</button></div>`);
  $('#tNo').onclick = closeModal;
  document.querySelectorAll('.targets .side-item').forEach(b => b.onclick = async () => {
    const dest = albums.find(a => a.id === b.dataset.id), src = current();
    const sel = src.photos.filter(p => selected.has(p.id));
    if (mode === 'move') { src.photos = src.photos.filter(p => !selected.has(p.id)); dest.photos.push(...sel); }
    else dest.photos.push(...await api.copyPhotos(sel));
    await persist(); closeModal(); selected.clear(); selectMode = false; render();
    toast(`${plural(sel.length)} ${mode === 'move' ? 'movida(s)' : 'copiada(s)'} para "${dest.name}"`);
  });
}
async function purge(a) {
  await api.deleteFiles('photo', a.photos);
  if (a.cover) await api.deleteFiles('cover', [a.cover]);
  albums = albums.filter(x => x.id !== a.id);
}
async function deleteAlbum() {
  const a = current();
  if (!await confirmBox('Mover para a lixeira?', `"${a.name}" ficará na lixeira por 30 dias e poderá ser restaurado.`, 'Mover para a lixeira')) return;
  finalize(); a.deletedAt = Date.now(); await persist();
  currentId = null; selectMode = false; render();
  toast('Álbum movido para a lixeira', 'Desfazer', async () => { delete a.deletedAt; await persist(); render(); });
}
function go(id) { trashView = false; currentId = id; selectMode = false; selected.clear(); render(); }

/* ---------- Lightbox ---------- */
let lbScale = 1, lbRot = 0;
const applyT = () => { const im = $('#lightbox img'); if (im) im.style.transform = `scale(${lbScale}) rotate(${lbRot}deg)`; };
let lbIdx = 0, ssSec = 5, lbTimer = null, playing = false;
function openLightbox(i) { lbIdx = i; lbScale = 1; lbRot = 0; drawLb(); $('#lightbox').classList.remove('hidden'); }
function drawLb() {
  const ph = current().photos;
  $('#lightbox').innerHTML = `<img src="${url('photos', ph[lbIdx].file)}">
    <button class="lb-prev" aria-label="Anterior">‹</button><button class="lb-next" aria-label="Próxima">›</button><button class="lb-ibtn" aria-label="Detalhes da foto" title="Detalhes (I)">ⓘ</button><button class="lb-rot" aria-label="Girar 90 graus" title="Girar (R)">⟳</button><button class="lb-close" aria-label="Fechar">✕</button>
    ${playing ? '<span class="lb-hint">Espaço pausa · Esc sai</span>' : ''}
    ${ph[lbIdx].caption && !infoOpen ? `<div class="lb-cap">${esc(ph[lbIdx].caption)}</div>` : ''}${infoOpen ? panelHtml(ph[lbIdx]) : ''}`;
  $('.lb-prev').onclick = e => { e.stopPropagation(); step(-1); };
  $('.lb-next').onclick = e => { e.stopPropagation(); step(1); };
  $('.lb-close').onclick = closeLb;
  $('.lb-ibtn').onclick = e => { e.stopPropagation(); infoOpen = !infoOpen; drawLb(); };
  if (infoOpen) {
    const p = ph[lbIdx];
    $('#pCap').onchange = async e => { p.caption = e.target.value.trim(); await persist(); };
    $('#pTags').onchange = async e => { p.tags = e.target.value.split(',').map(t => t.trim()).filter(Boolean); await persist(); };
    api.photoInfo(p.file).then(i => { const el = $('#pInfo'); if (el) el.innerHTML = `<div><span>Resolução</span>${i.width} × ${i.height} px</div><div><span>Tamanho</span>${fmtSize(i.size)}</div><div><span>Adicionada em</span>${new Date(i.added).toLocaleDateString('pt-BR')}</div>`; });
  }
  $('.lb-rot').onclick = e => { e.stopPropagation(); lbRot = (lbRot + 90) % 360; applyT(); };
  applyT();
}
function step(d) { const n = current().photos.length; lbIdx = (lbIdx + d + n) % n; lbScale = 1; lbRot = 0; drawLb(); if (playing && lbTimer) tick(); }
function tick() { clearInterval(lbTimer); lbTimer = setInterval(() => step(1), ssSec * 1000); }
function startShow() { playing = true; openLightbox(0); tick(); document.documentElement.requestFullscreen?.().catch(() => {}); }
function closeLb() {
  clearInterval(lbTimer); lbTimer = null; playing = false;
  $('#lightbox').classList.add('hidden'); if (document.fullscreenElement) document.exitFullscreen();
}
$('#lightbox').onclick = e => { if (e.target.id === 'lightbox') closeLb(); };
$('#lightbox').addEventListener('wheel', e => { e.preventDefault(); lbScale = Math.min(5, Math.max(.5, lbScale + (e.deltaY < 0 ? .15 : -.15))); applyT(); }, { passive: false });
document.addEventListener('fullscreenchange', () => { if (!document.fullscreenElement && playing) closeLb(); });

document.addEventListener('keydown', e => {
  if (!$('#lightbox').classList.contains('hidden')) {
    if (/INPUT|TEXTAREA/.test(document.activeElement.tagName)) { if (e.key === 'Escape') document.activeElement.blur(); return; }
    if (e.key === 'Escape') closeLb();
    if (e.key === 'i' || e.key === 'I') { infoOpen = !infoOpen; drawLb(); }
    if (e.key === 'ArrowLeft') step(-1);
    if (e.key === 'ArrowRight') step(1);
    if (e.key === 'r' || e.key === 'R') { lbRot = (lbRot + 90) % 360; applyT(); }
    if (e.key === ' ' && playing) { e.preventDefault(); if (lbTimer) { clearInterval(lbTimer); lbTimer = null; toast('Pausado'); } else tick(); }
    return;
  }
  if (e.key === 'Tab' && $('.modal')) {                                   // mantém o foco dentro do modal
    const f = [...$('.modal').querySelectorAll('button,input,textarea,select')], i = f.indexOf(document.activeElement);
    e.preventDefault(); f[(i + (e.shiftKey ? -1 : 1) + f.length) % f.length].focus(); return;
  }
  if (e.key === 'Escape') return closeModal();
  const typing = /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName);
  if (e.ctrlKey && e.key === 'n') { e.preventDefault(); albumForm(null); }
  else if (e.ctrlKey && e.key === 'f') { e.preventDefault(); $('#search').focus(); }
  else if (!typing && selectMode) {
    if (e.ctrlKey && e.key === 'a') { e.preventDefault(); $('#bAll')?.click(); }
    if (e.key === 'Delete') $('#bDelSel')?.click();
  }
});

/* Arrastar e soltar do Explorer */
const hasFiles = e => e.dataTransfer?.types?.includes('Files');
window.addEventListener('dragover', e => { if (hasFiles(e)) e.preventDefault(); });
window.addEventListener('drop', async e => {
  if (!hasFiles(e)) return;
  e.preventDefault();
  const side = e.target.closest('.sidebar');
  if (!side && !currentId) { toast('Abra um álbum ou solte na barra lateral'); return; }
  const list = await api.importPaths([...e.dataTransfer.files].map(f => api.pathOf(f)).filter(Boolean));
  if (!list.length) { toast('Nenhuma imagem válida encontrada'); return; }
  if (!side) return addList(list);
  const a = { id: uid(), name: 'Novo álbum', desc: '', cover: await api.coverFromPhoto(list[0].file), photos: list, created: Date.now() };
  albums.unshift(a); currentId = a.id; await persist(); render(); toast('Álbum criado — clique em Editar para renomear');
});

function renderTrash() {
  const list = albums.filter(a => a.deletedAt);
  $('#view').innerHTML = `<div class="toolbar"><button class="btn" id="tBack">‹ Voltar</button><span class="spacer"></span>
    <button class="btn danger" id="tEmpty" ${list.length ? '' : 'disabled'}>Esvaziar lixeira</button></div>
    <h2 class="page-title">Lixeira</h2><p class="sub" style="margin-bottom:22px">Os álbuns são removidos definitivamente após 30 dias.</p>` +
    (list.length ? `<div class="grid">${list.map(a => `<div class="card">
      ${a.cover ? `<img class="cover" src="${url('covers', a.cover)}">` : '<div class="cover ph">🖼</div>'}
      <div class="info"><b>${esc(a.name)}</b><small>${plural(a.photos.length)} · ${Math.max(0, 30 - Math.floor((Date.now() - a.deletedAt) / 864e5))} dia(s) restantes</small>
      <div class="card-actions"><button class="btn" data-r="${a.id}">Restaurar</button><button class="btn danger" data-d="${a.id}">Excluir</button></div></div></div>`).join('')}</div>`
      : '<div class="empty"><div class="big">🗑</div><p>A lixeira está vazia.</p></div>');
  $('#tBack').onclick = () => go(null);
  $('#tEmpty').onclick = async () => {
    if (await confirmBox('Esvaziar lixeira?', 'Os álbuns e suas fotos serão apagados definitivamente.', 'Esvaziar')) { for (const a of list) await purge(a); await persist(); render(); toast('Lixeira esvaziada'); }
  };
  document.querySelectorAll('[data-r]').forEach(b => b.onclick = async () => { delete albums.find(x => x.id === b.dataset.r).deletedAt; await persist(); render(); toast('Álbum restaurado'); });
  document.querySelectorAll('[data-d]').forEach(b => b.onclick = async () => {
    const a = albums.find(x => x.id === b.dataset.d);
    if (await confirmBox('Excluir definitivamente?', `"${a.name}" não poderá ser recuperado.`, 'Excluir')) { await purge(a); await persist(); render(); }
  });
}
async function aboutBox() {
  const i = await api.info();
  openModal(`<div class="about"><div class="logo big"><img src="../imagens/Logo.png" alt=""></div><h3>MPhotos</h3>
    <p class="sub">Versão ${esc(i.version)}</p><p>Gerenciador de fotos com álbuns no estilo playlist.</p>
    <p class="sub">Desenvolvido por <b>Marcos Simionatto</b><br>© ${new Date().getFullYear()} · Todos os direitos reservados</p></div>
    <div class="actions"><button class="btn" id="aRepo">Repositório</button><button class="btn primary" id="aOk">Fechar</button></div>`);
  $('.about img').onerror = e => e.target.replaceWith(document.createTextNode('◐'));
  $('#aOk').onclick = closeModal; $('#aRepo').onclick = () => api.openRepo();
}
const panelHtml = p => `<aside class="lb-panel"><h4>Detalhes</h4>
  <label>Legenda</label><textarea id="pCap" rows="3" maxlength="200">${esc(p.caption)}</textarea>
  <label>Tags (separadas por vírgula)</label><input id="pTags" type="text" value="${esc((p.tags || []).join(', '))}">
  <div id="pInfo" class="pinfo">Carregando…</div></aside>`;

/* ---------- Render ---------- */
function renderSide() {
  const q = query.toLowerCase();
  const list = sorted().filter(a => hay(a).includes(q));
  $('#sideList').innerHTML = list.length ? list.map(a => `
    <button class="side-item ${a.id === currentId ? 'active' : ''}" data-id="${a.id}">
      ${a.cover ? `<img src="${url('covers', a.cover)}">` : '<div class="ph">🖼</div>'}
      <div><b>${esc(a.name)}</b><small>${plural(a.photos.length)}</small></div></button>`).join('')
    : `<div class="empty-side">${albums.length ? 'Nenhum álbum encontrado' : 'Seus álbuns aparecerão aqui'}</div>`;
  document.querySelectorAll('.side-item').forEach(b => b.onclick = () => go(b.dataset.id));
}

function renderHome() {
  const q = query.toLowerCase();
  const list = sorted().filter(a => hay(a).includes(q));
  $('#view').innerHTML = `<h2 class="page-title">Seus álbuns</h2>${statsHtml()}<div class="head-row"><p class="sub">${active().length} álbum(ns) na coleção</p>
    <select class="btn" id="sortSel" title="Ordenar">${[['recent', 'Mais recentes'], ['name', 'Nome (A–Z)'], ['count', 'Mais fotos']].map(([v, t]) => `<option value="${v}" ${v === sortBy ? 'selected' : ''}>${t}</option>`).join('')}</select></div>` +
    (list.length ? `<div class="grid">${list.map(a => `
      <button class="card" data-id="${a.id}">
        ${a.cover ? `<img class="cover" src="${url('covers', a.cover)}">` : '<div class="cover ph">🖼</div>'}
        <div class="info"><b>${esc(a.name)}</b><small>${plural(a.photos.length)}</small></div></button>`).join('')}</div>`
    : `<div class="empty"><div class="big">📷</div><p>${albums.length ? 'Nenhum álbum com esse nome.' : 'Você ainda não tem álbuns. Clique em “Criar álbum” para começar.'}</p></div>`);
  document.querySelectorAll('.card').forEach(c => c.onclick = () => go(c.dataset.id));
  $('#sortSel').onchange = e => { sortBy = e.target.value; render(); };
  api.info().then(i => { const el = $('#stSize'); if (el) el.textContent = fmtSize(i.size); });
}

function renderAlbum() {
  const a = current();
  $('#view').innerHTML = `
    <div class="toolbar"><button class="btn" id="bBack">‹ Voltar</button><span class="spacer"></span>
      <button class="btn" id="bExp">⤓ Exportar</button><button class="btn" id="bEdit">Editar</button><button class="btn danger" id="bDel">Excluir álbum</button></div>
    <div class="album-head">
      ${a.cover ? `<img src="${url('covers', a.cover)}">` : '<div class="ph">🖼</div>'}
      <div><h2>${esc(a.name)}</h2><p>${esc(a.desc) || 'Sem descrição.'}</p>
        <div class="meta">${plural(a.photos.length)} · criado em ${new Date(a.created).toLocaleDateString('pt-BR')}</div></div></div>
    <div class="toolbar">
      <button class="btn primary" id="bAdd">+ Adicionar fotos</button>
      <button class="btn" id="bFav">${onlyFav ? '♥ Mostrar todas' : '♡ Só favoritas'}</button>
      <button class="btn" id="bShow" ${a.photos.length ? '' : 'disabled'}>▶ Apresentar</button>
      <select class="btn" id="ssSec" title="Intervalo do slideshow">${[3, 5, 10].map(s => `<option value="${s}" ${s === ssSec ? 'selected' : ''}>${s}s</option>`).join('')}</select>
      <button class="btn" id="bSel" ${a.photos.length ? '' : 'disabled'}>${selectMode ? 'Cancelar seleção' : 'Selecionar'}</button>
      ${selectMode ? `<button class="btn" id="bAll">Selecionar todas</button>
        <button class="btn" id="bMove" ${selected.size ? '' : 'disabled'}>Mover…</button>
        <button class="btn" id="bCopy" ${selected.size ? '' : 'disabled'}>Copiar…</button>
        <button class="btn danger" id="bDelSel" ${selected.size ? '' : 'disabled'}>Excluir selecionadas (${selected.size})</button>` : ''}
    </div>
    ${a.photos.length ? `<div class="photos">${a.photos.map((p, i) => `
      <div class="photo ${selected.has(p.id) ? 'sel' : ''}${onlyFav && !p.fav ? ' hide' : ''}" data-id="${p.id}" data-i="${i}" ${selectMode ? '' : 'draggable="true"'}>
        <img src="${thumbUrl(p)}" loading="lazy">
        ${selectMode ? `<span class="chk">${selected.has(p.id) ? '✓' : ''}</span>` : `<button class="fv ${p.fav ? 'on' : ''}" title="Favoritar" aria-label="Favoritar">${p.fav ? '♥' : '♡'}</button><button class="cv" title="Definir como capa" aria-label="Definir como capa">▣</button><button class="x" title="Excluir foto" aria-label="Excluir foto">✕</button>`}
      </div>`).join('')}</div>`
    : '<div class="empty"><div class="big">🖼</div><p>Álbum vazio. Adicione suas primeiras fotos.</p></div>'}`;
  $('#bBack').onclick = () => go(null);
  $('#bEdit').onclick = () => albumForm(a);
  $('#bExp').onclick = async () => { const n = await api.exportAlbum(a); if (n !== null) toast(`${plural(n)} exportada(s)`); };
  $('#bDel').onclick = deleteAlbum;
  $('#bAdd').onclick = addPhotos;
  $('#bShow').onclick = startShow;
  $('#bFav').onclick = () => { onlyFav = !onlyFav; render(); };
  $('#ssSec').onchange = e => ssSec = +e.target.value;
  $('#bSel').onclick = () => { selectMode = !selectMode; selected.clear(); render(); };
  if (selectMode) {
    $('#bAll').onclick = () => { selected = new Set(a.photos.map(p => p.id)); render(); };
    $('#bMove').onclick = () => pickTarget('move');
    $('#bCopy').onclick = () => pickTarget('copy');
    $('#bDelSel').onclick = async () => {
      if (await confirmBox('Excluir fotos?', `${plural(selected.size)} será(ão) removida(s) permanentemente.`, 'Excluir')) { const ids = [...selected]; selectMode = false; removePhotos(ids); }
    };
  }
  document.querySelectorAll('.photo').forEach(el => {
    el.onclick = e => {
      if (selectMode) {
        const i = +el.dataset.i;
        if (e.shiftKey && lastSel >= 0) { const [s, t] = [lastSel, i].sort((x, y) => x - y); a.photos.slice(s, t + 1).forEach(p => selected.add(p.id)); }
        else { const id = el.dataset.id; selected.has(id) ? selected.delete(id) : selected.add(id); }
        lastSel = i; render();
      }
      else openLightbox(+el.dataset.i);
    };
    const fv = el.querySelector('.fv');
    if (fv) fv.onclick = async e => { e.stopPropagation(); const p = a.photos[+el.dataset.i]; p.fav = !p.fav; await persist(); render(); };
    const cv = el.querySelector('.cv');
    if (cv) cv.onclick = e => { e.stopPropagation(); setCover(a.photos[+el.dataset.i]); };
    el.ondragstart = e => { dragId = el.dataset.id; e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', dragId); el.style.opacity = '.4'; };
    el.ondragend = () => { dragId = null; el.style.opacity = ''; };
    el.ondragover = e => { if (dragId) e.preventDefault(); };
    el.ondrop = async e => {
      if (!dragId) return; e.preventDefault(); e.stopPropagation();
      const from = a.photos.findIndex(p => p.id === dragId), to = a.photos.findIndex(p => p.id === el.dataset.id);
      dragId = null; if (from < 0 || to < 0 || from === to) return;
      const [m] = a.photos.splice(from, 1); a.photos.splice(to, 0, m); await persist(); render();
    };
    const x = el.querySelector('.x');
    if (x) x.onclick = async e => { e.stopPropagation(); if (await confirmBox('Excluir foto?', 'Esta foto será removida do álbum.', 'Excluir')) removePhotos([el.dataset.id]); };
  });
}

function render() { renderSide(); trashView ? renderTrash() : currentId && current() ? renderAlbum() : renderHome(); }

$('#logoImg').onerror = e => { e.target.replaceWith(document.createTextNode('◐')); };
$('#year').textContent = new Date().getFullYear();
$('#btnNew').onclick = () => albumForm(null);
$('#btnTrash').onclick = () => { trashView = true; currentId = null; render(); };
$('#btnAbout').onclick = aboutBox;
api.onUpdate(() => toast('Nova versão baixada: será instalada ao fechar o app'));
$('.brand').onclick = () => go(null);
$('#search').oninput = e => { query = e.target.value; renderSide(); if (!currentId) renderHome(); };

$('#btnBackup').onclick = async () => { if (await api.backup()) toast('Backup concluído com sucesso'); };
$('#btnRestore').onclick = async () => {
  if (!await confirmBox('Restaurar backup?', 'Os álbuns atuais serão substituídos pelos do backup.', 'Restaurar')) return;
  if (await api.restore()) { const d = await api.load(); albums = d.albums; currentId = null; render(); toast('Backup restaurado'); }
};
api.onProgress(({ done, total }) => toast(`Importando ${done}/${total}…`));
window.addEventListener('unhandledrejection', e => toast('Erro: ' + (e.reason?.message || 'falha inesperada')));

(async () => { const d = await api.load(); albums = d.albums; dataDir = d.dir;
  const old = albums.filter(a => a.deletedAt && Date.now() - a.deletedAt > 30 * 864e5);   // limpeza automática da lixeira
  if (old.length) { for (const a of old) await purge(a); await persist(); }
  render(); })();
