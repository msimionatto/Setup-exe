# MPhotos

Gerenciador de fotos para Windows, com álbuns no estilo playlist. Desenvolvido por Marcos Simionatto.

## Tecnologia
Electron (JavaScript, HTML e CSS) · sharp · electron-builder

## Como rodar
```bash
npm install
npm start
```

## Testes
```bash
npm test
```

## Gerar o instalador (Windows)
Coloque `imagens/Logo.png` e `imagens/Logo.ico` e rode:
```bash
npm run dist
```
O instalador sai na pasta `dist/`.

Os dados do usuário ficam em `%APPDATA%\meu-album`.
