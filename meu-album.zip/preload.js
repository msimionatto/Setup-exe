const { contextBridge, ipcRenderer, webUtils } = require('electron');
const inv = (c, a) => ipcRenderer.invoke(c, a);
contextBridge.exposeInMainWorld('api', {
  load: () => inv('db:load'),
  save: a => inv('db:save', a),
  pickPhotos: () => inv('photos:pick'),
  importPaths: p => inv('photos:import', p),
  copyPhotos: p => inv('photos:copy', p),
  pickCover: () => inv('cover:pick'),
  coverFromPhoto: f => inv('cover:fromPhoto', f),
  deleteFiles: (kind, files) => inv('files:delete', { kind, files }),
  backup: () => inv('backup:export'),
  restore: () => inv('backup:restore'),
  exportAlbum: a => inv('album:export', a),
  onProgress: cb => ipcRenderer.on('import:progress', (_, d) => cb(d)),
  info: () => inv('app:info'),
  photoInfo: f => inv('photo:info', f),
  openRepo: () => inv('app:repo'),
  onUpdate: cb => ipcRenderer.on('update:ready', () => cb()),
  pathOf: f => webUtils.getPathForFile(f)
});
