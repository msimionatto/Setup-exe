const assert = require('assert');
const s = require('../src/security.js');
const tests = []; const T = (n, f) => tests.push([n, f]);
T('payload é limpo e limitado', () => {
  const p = s.cleanPayload({ rows: Array.from({ length: 6000 }, (_, i) => ({ ts: 'x', mode: 'M'.repeat(100), expr: 'e'.repeat(900), res: i })), current: { expr: 1, res: null }, stamp: '2026-10-10/../x' });
  assert.strictEqual(p.rows.length, 5000); assert.strictEqual(p.rows[0].mode.length, 40); assert.strictEqual(p.rows[0].expr.length, 500); assert.ok(Number.isFinite(p.rows[0].ts));
  assert.strictEqual(p.stamp, '2026-10-10'); assert.throws(() => s.cleanPayload(null)); assert.deepStrictEqual(s.cleanPayload({}).rows, []);
});
T('tipos, nomes e cores', () => {
  assert.strictEqual(s.cleanKind('pdf'), 'pdf'); assert.strictEqual(s.cleanKind('exe'), null); assert.strictEqual(s.safeName('../../a b?.txt'), '.._.._a_b_.txt'); assert.strictEqual(s.safeName(''), 'AllCalculadora');
  assert.ok(s.validColor('#0d0817')); assert.ok(!s.validColor('red; x')); assert.ok(!s.validColor(5)); assert.deepStrictEqual(s.clampSize(99999, NaN), { w: 2000, h: 720 }); assert.strictEqual(s.cleanText('a'.repeat(3e6)).length, 2e6);
});
T('origem confiável', () => {
  const wc = {}; const win = { isDestroyed: () => false, webContents: wc };
  assert.ok(s.isTrusted({ sender: wc, senderFrame: { url: 'file:///app/index.html' } }, win));
  assert.ok(!s.isTrusted({ sender: wc, senderFrame: { url: 'https://evil.com' } }, win));
  assert.ok(!s.isTrusted({ sender: {}, senderFrame: { url: 'file:///x' } }, win)); assert.ok(!s.isTrusted({ sender: wc }, null));
});
let fail = 0; for (const [n, f] of tests) { try { f(); console.log('ok  ', n); } catch (e) { fail++; console.log('FAIL', n, '-', e.message); } }
process.exit(fail ? 1 : 0);
