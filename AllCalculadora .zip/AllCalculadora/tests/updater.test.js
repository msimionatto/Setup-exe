const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { EventEmitter } = require('events');
const { createUpdateCenter, friendlyError, cleanNotes } = require('../src/updater.js');
const { createStore } = require('../src/store.js');
const { createLogger } = require('../src/logger.js');
const { section, latestVersion } = require('../src/changelog.js');

class FakeUpdater extends EventEmitter {
  constructor() { super(); this.calls = []; }
  async checkForUpdates() { this.calls.push('check'); } async downloadUpdate() { this.calls.push('download'); } quitAndInstall(a, b) { this.calls.push(['install', a, b]); }
}
const mkStore = (init = {}) => { let d = { autoCheck: true, channel: 'stable', skipped: '', ...init }; return { get: () => ({ ...d }), set: (p) => { d = { ...d, ...p }; return { ...d }; } }; };
const setup = (o = {}) => { const u = new FakeUpdater(); const sent = []; const c = createUpdateCenter({ updater: u, version: '2.2.0', packaged: o.packaged !== false, store: o.store || mkStore(), send: (s) => sent.push(s.state), timers: o.timers }); c.attach(); return { u, c, sent }; };
const tests = []; const T = (n, f) => tests.push([n, f]);

T('fora do app instalado: não consulta a rede', async () => { const { u, c } = setup({ packaged: false }); await c.check({ manual: true }); assert.strictEqual(c.getState().state, 'dev'); assert.deepStrictEqual(u.calls, []); });
T('fluxo completo: verifica, baixa com progresso e fica pronto', async () => {
  const { u, c, sent } = setup(); await c.check({ manual: true }); assert.deepStrictEqual(u.calls, ['check']);
  u.emit('update-available', { version: '2.3.0', releaseNotes: '<p>Novidades <b>boas</b></p>' }); assert.deepStrictEqual(u.calls, ['check', 'download']);
  u.emit('download-progress', { percent: 42.4 }); assert.strictEqual(c.getState().percent, 42);
  u.emit('update-downloaded', { version: '2.3.0' }); const s = c.getState(); assert.strictEqual(s.state, 'ready'); assert.strictEqual(s.version, '2.3.0'); assert.match(s.notes, /Novidades boas/);
  c.install(); assert.deepStrictEqual(u.calls[u.calls.length - 1], ['install', false, true]); assert.ok(sent.includes('downloading') && sent.includes('ready'));
});
T('sem verificação automática: oferece o botão Baixar', async () => { const { u, c } = setup({ store: mkStore({ autoCheck: false }) }); await c.check({ manual: false }); u.emit('update-available', { version: '2.3.0' }); assert.strictEqual(c.getState().state, 'available'); assert.ok(!u.calls.includes('download')); c.download(); assert.ok(u.calls.includes('download')); });
T('pular versão: ignora no automático e respeita o clique manual', async () => {
  const { u, c } = setup(); await c.check({ manual: false }); u.emit('update-available', { version: '2.3.0' }); u.emit('update-downloaded', { version: '2.3.0' });
  const { u: u2, c: c2 } = setup({ store: mkStore({ skipped: '2.3.0' }) }); await c2.check({ manual: false }); u2.emit('update-available', { version: '2.3.0' }); assert.strictEqual(c2.getState().state, 'skipped'); assert.ok(!u2.calls.includes('download'));
  await c2.check({ manual: true }); u2.emit('update-available', { version: '2.3.0' }); assert.ok(u2.calls.includes('download'));
  const { u: u3, c: c3 } = setup(); await c3.check(); u3.emit('update-available', { version: '2.4.0' }); c3.skip(); assert.strictEqual(c3.getState().state, 'skipped');
});
T('já atualizado', async () => { const { u, c } = setup(); await c.check({ manual: true }); u.emit('update-not-available', {}); assert.strictEqual(c.getState().state, 'none'); assert.ok(c.getState().lastCheck > 0); });
T('erros viram mensagens claras', async () => {
  assert.match(friendlyError(new Error('HttpError: 404 Not Found')), /repositório.*privado/); assert.match(friendlyError({ code: 'ENOTFOUND' }), /Sem conexão/);
  assert.match(friendlyError(new Error('New version is not signed by the application owner (publisherName)')), /assinatura/); assert.match(friendlyError(new Error('sha512 checksum mismatch')), /corrompido/); assert.match(friendlyError(new Error('algo estranho\noutra linha')), /^Falha ao atualizar: algo estranho$/);
  const { u, c } = setup(); u.emit('error', new Error('getaddrinfo ENOTFOUND github.com')); assert.strictEqual(c.getState().state, 'error'); assert.match(c.getState().error, /Sem conexão/);
});
T('falha ao consultar vira estado de erro', async () => { const { u, c } = setup(); u.checkForUpdates = async () => { throw new Error('404'); }; await c.check({ manual: true }); assert.strictEqual(c.getState().state, 'error'); });
T('canal e configurações validados', () => {
  const { u, c } = setup(); assert.deepStrictEqual(c.setSettings({ channel: 'beta', autoCheck: false, lixo: 1 }), { autoCheck: false, channel: 'beta', skipped: '' });
  assert.strictEqual(c.setSettings({ channel: 'hack', autoCheck: 'sim' }).channel, 'beta'); assert.strictEqual(u.autoDownload, false);
  return c.check().then(() => assert.strictEqual(u.allowPrerelease, true));
});
T('agenda verificação ao abrir e a cada 4 horas', async () => {
  const jobs = []; const timers = { setTimeout: (f, ms) => (jobs.push(['t', ms, f]), {}), setInterval: (f, ms) => (jobs.push(['i', ms, f]), {}) };
  const { u, c } = setup({ timers }); c.start(); assert.strictEqual(jobs[0][1], 20000); assert.strictEqual(jobs[1][1], 4 * 3600e3);
  jobs[0][2](); await new Promise((r) => setImmediate(r)); assert.ok(u.calls.includes('check'));
  const off = setup({ timers, store: mkStore({ autoCheck: false }) }); jobs.length = 0; off.c.start(); jobs[1][2](); await new Promise((r) => setImmediate(r)); assert.ok(!off.u.calls.includes('check'));
});
T('notas da release são limpas', () => assert.strictEqual(cleanNotes('<h2>Título</h2><ul><li>um &amp; dois</li></ul>'), 'Título\num & dois'));
T('configurações em arquivo e log com rotação', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ld-')); const f = path.join(dir, 'sub', 's.json'); const s = createStore(f, { a: 1 }); s.set({ b: 2 });
  assert.deepStrictEqual(createStore(f, { a: 1 }).get(), { a: 1, b: 2 }); fs.writeFileSync(f, '{quebrado'); assert.deepStrictEqual(createStore(f, { a: 1 }).get(), { a: 1 });
  const l = createLogger(path.join(dir, 'logs'), { max: 200 }); for (let i = 0; i < 20; i++) l.info('linha', i, new Error('x').message, { k: i });
  assert.ok(fs.existsSync(l.file) && fs.existsSync(l.file + '.old')); assert.match(fs.readFileSync(l.file, 'utf8'), /\[INFO\] linha/);
});
T('changelog por versão', () => {
  const t = '# Changelog\n\n## 2.2.0\n**Atualizações**\n- A\n\n## 2.1.0\n- B\n\n## 1.0.0\n- C';
  assert.strictEqual(section(t, '2.2.0'), '**Atualizações**\n- A'); assert.strictEqual(section(t, '2.1.0'), '- B'); assert.strictEqual(section(t, '9.9.9'), ''); assert.strictEqual(latestVersion(t), '2.2.0');
});
(async () => { let fail = 0; for (const [n, f] of tests) { try { await f(); console.log('ok  ', n); } catch (e) { fail++; console.log('FAIL', n, '-', e.message); } } process.exit(fail ? 1 : 0); })();
