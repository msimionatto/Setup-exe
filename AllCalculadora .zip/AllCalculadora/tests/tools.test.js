const assert = require('assert');
const path = require('path');
const R = path.join(__dirname, '..', 'src', 'renderer');
const Tools = require(R + '/tools-core.js');
['tool-finance', 'tool-convert', 'tool-dates', 'tool-business', 'tool-math'].forEach((f) => require(`${R}/${f}.js`));
const E = require(R + '/engine.js');
const close = (a, b, e = 0.01) => assert.ok(Math.abs(a - b) <= e, `${a} != ${b}`);
const sec = (t, s) => Tools.get(t).sections.find((x) => x.id === s);
const calc = (t, s, v) => sec(t, s).calc(v);
const get = (res, k) => res.results.find((r) => r.k === k);
const tests = [];
const T = (n, f) => tests.push([n, f]);

T('registro', () => assert.deepStrictEqual(Tools.list().map((t) => t.id), ['finance', 'convert', 'currency', 'dates', 'business', 'math']));
T('juros compostos', () => { const r = calc('finance', 'compound', { vp: 1000, pmt: 0, rate: 1, rper: 'mes', time: 12, tper: 'meses' }); close(get(r, 'fv').raw, 1126.83); close(get(r, 'gain').raw, 126.83); });
T('juros compostos com aporte', () => { const r = calc('finance', 'compound', { vp: 0, pmt: 100, rate: 1, rper: 'mes', time: 12, tper: 'meses' }); close(get(r, 'fv').raw, 1268.25); });
T('taxa anual -> mensal', () => { const r = calc('finance', 'compound', { vp: 1000, pmt: 0, rate: 12.6825, rper: 'ano', time: 1, tper: 'anos' }); close(get(r, 'fv').raw, 1126.825, 0.05); });
T('juros simples', () => close(get(calc('finance', 'simple', { c: 1000, rate: 2, rper: 'mes', time: 6, tper: 'meses' }), 'm').raw, 1120));
T('Price e SAC', () => { const r = calc('finance', 'price', { pv: 10000, rate: 1, rper: 'mes', n: 12, sys: 'price' }); close(get(r, 'pmtP').raw, 888.49); close(get(r, 'sac1').raw, 933.33); close(get(r, 'sacN').raw, 841.67); assert.ok(get(r, 'diff').raw > 0); assert.strictEqual(r.table.rows.length, 12); });
T('VP/VF e taxa', () => { close(calc('finance', 'pvfv', { solve: 'fv', vp: 1000, i: 10, n: 2 }).results[0].raw, 1210); close(calc('finance', 'pvfv', { solve: 'rate', vp: 1000, vf: 1210, n: 2 }).results[0].raw, 10); close(calc('finance', 'pvfv', { solve: 'n', vp: 1000, vf: 1210, i: 10 }).results[0].raw, 2); });
T('taxas equivalentes', () => { const r = calc('finance', 'rates', { rate: 1, from: '12', infl: NaN }); close(get(r, 'ano').raw, 12.6825, 0.001); assert.strictEqual(get(r, 'real'), undefined); close(get(calc('finance', 'rates', { rate: 10, from: '1', infl: 5 }), 'real').raw, 4.7619, 0.001); });
T('VPL/TIR/payback', () => { const r = calc('finance', 'npv', { rate: 10, cf: '-100\n110' }); close(get(r, 'vpl').raw, 0); close(get(r, 'tir').raw, 10, 0.001); const r2 = calc('finance', 'npv', { rate: 10, cf: '-1000\n300\n400\n500\n600' }); assert.ok(get(r2, 'vpl').raw > 0); close(get(r2, 'pb').text === undefined ? 0 : 1, 1); assert.throws(() => calc('finance', 'npv', { rate: 10, cf: '1\nabc' }), /inválidos/); });
T('meta de poupança', () => { const r = calc('finance', 'goal', { goal: 12000, vp: 0, rate: 0, rper: 'mes', time: 12, tper: 'meses' }); close(get(r, 'pmt').raw, 1000); });

T('conversor', () => { const c = Tools.get('convert').convert; close(c('length', 1, 'km', 'm'), 1000); close(c('temp', 100, '°C', '°F'), 212); close(c('temp', 0, '°C', 'K'), 273.15); close(c('data', 1, 'GiB', 'MB'), 1073.741824, 1e-6); close(c('mass', 1, 'lb', 'kg'), 0.45359237, 1e-8); });
T('moedas', () => close(Tools.get('currency').rateConvert(100, 'USD', 'BRL', { USD: 1, BRL: 5 }), 500));

const D = () => Tools.get('dates').util;
T('Páscoa e feriados', () => { const u = D(); assert.strictEqual(new Date(u.easter(2025)).toISOString().slice(0, 10), '2025-04-20'); assert.ok(u.holidays(2025).has(Date.UTC(2025, 3, 18))); assert.ok(u.holidays(2024).has(Date.UTC(2024, 10, 20))); assert.ok(!u.holidays(2023).has(Date.UTC(2023, 10, 20))); });
T('diferença entre datas', () => { const r = calc('dates', 'diff', { d1: '2024-01-31', d2: '2024-03-01', hol: false }); assert.match(get(r, 'ymd').text, /0 anos, 1 mês e 1 dia/); assert.strictEqual(get(r, 'days').raw, 30); const r2 = calc('dates', 'diff', { d1: '2025-01-01', d2: '2025-01-31', hol: true }); assert.strictEqual(get(r2, 'biz').raw, 22); });
T('somar dias úteis', () => { const r = calc('dates', 'add', { d: '2025-04-16', op: '+', n: 2, u: 'bd', hol: true }); assert.match(get(r, 'res').text, /22\/04\/2025/); const m = calc('dates', 'add', { d: '2024-01-31', op: '+', n: 1, u: 'm' }); assert.match(get(m, 'res').text, /29\/02\/2024/); });
T('idade', () => { const r = calc('dates', 'age', { b: '2000-06-15', r: '2025-06-14' }); assert.match(get(r, 'age').text, /24 anos, 11 meses e 30 dias/); });
T('horas', () => { const r = calc('dates', 'hours', { in: '08:00', out: '17:30', brk: 60, days: 5, rate: 20 }); assert.strictEqual(get(r, 'day').text, '08:30 h'); close(get(r, 'dec').raw, 42.5); close(get(r, 'pay').raw, 850); const n = calc('dates', 'hours', { in: '22:00', out: '06:00', brk: 0, days: 1, rate: NaN }); assert.strictEqual(get(n, 'day').text, '08:00 h'); });

T('porcentagem', () => { close(calc('business', 'percent', { kind: 'of', a: 15, b: 200 }).results[0].raw, 30); close(calc('business', 'percent', { kind: 'var', a: 80, b: 100 }).results[0].raw, 25); close(calc('business', 'percent', { kind: 'dec', a: 20, b: 50 }).results[0].raw, 40); });
T('preço de venda', () => { const r = calc('business', 'markup', { cost: 60, margin: 25, exp: 10 }); close(get(r, 'price').raw, 92.31); close(get(r, 'profit').raw, 23.08); });
T('impostos e descontos', () => { const r = calc('business', 'tax', { val: 1000, mode: 'in', icms: 18, ipi: 0, pis: 0.65, cofins: 3, iss: 0 }); close(get(r, 'total').raw, 216.5); close(get(r, 'net').raw, 783.5); close(get(calc('business', 'discount', { p: 100, d1: 10, d2: 10 }), 'final').raw, 81); close(get(calc('business', 'split', { total: 100, n: 4, tip: 10 }), 'pp').raw, 27.5); });
T('margem', () => { const r = calc('business', 'margin', { price: 100, cost: 65, qty: 2 }); close(get(r, 'profit').raw, 70); close(get(r, 'margin').raw, 35); });

T('equações', () => { close(calc('math', 'linear', { a: 2, b: 3, c: 11 }).results[0].raw, 4); const q = calc('math', 'quad', { a: 1, b: -5, c: 6 }); close(get(q, 'x1').raw, 3); close(get(q, 'x2').raw, 2); const c = calc('math', 'quad', { a: 1, b: 2, c: 5 }); assert.match(get(c, 'x1').text, /i$/); assert.throws(() => calc('math', 'quad', { a: 0, b: 1, c: 1 }), /2º grau/); });
T('sistemas', () => { const r = calc('math', 'system', { m: '2 1 5\n1 -1 1' }); close(get(r, 'x').raw, 2); close(get(r, 'y').raw, 1); assert.match(calc('math', 'system', { m: '1 1 2\n1 1 3' }).results[0].text, /impossível/); assert.match(calc('math', 'system', { m: '1 1 2\n2 2 4' }).results[0].text, /infinitas/); const r3 = calc('math', 'system', { m: '1 1 1 6\n0 2 5 -4\n2 5 -1 27' }); close(get(r3, 'x').raw, 5); close(get(r3, 'y').raw, 3); close(get(r3, 'z').raw, -2); });
T('matrizes', () => { assert.strictEqual(get(calc('math', 'matrix', { op: 'det', a: '1 2\n3 4' }), 'det').raw, -2); assert.deepStrictEqual(calc('math', 'matrix', { op: 'mul', a: '1 2\n3 4', b: '0 1\n1 0' }).matrices[0].m.map((r) => r.map((x) => x.replace(',', '.'))), [['2', '1'], ['4', '3']]); const inv = calc('math', 'matrix', { op: 'inv', a: '1 2\n3 4' }).matrices[0].m; close(parseFloat(inv[0][0].replace(',', '.')), -2); assert.throws(() => calc('math', 'matrix', { op: 'inv', a: '1 2\n2 4' }), /singular/); assert.throws(() => calc('math', 'matrix', { op: 'add', a: '1 2', b: '1' }), /mesmo/); });
T('estatística', () => { const r = calc('math', 'stats', { d: '1 2 3 4 5' }); close(get(r, 'mean').raw, 3); close(get(r, 'med').raw, 3); close(get(r, 'sds').raw, 1.5811, 1e-3); close(get(r, 'sdp').raw, 1.4142, 1e-3); assert.strictEqual(get(r, 'mode').text, 'não há'); assert.strictEqual(get(calc('math', 'stats', { d: '2 2 3' }), 'mode').text, '2'); });
T('regressão', () => { const r = calc('math', 'regress', { p: '1 2\n2 4\n3 6', x0: 4 }); close(get(r, 'a').raw, 2); close(get(r, 'b').raw, 0); close(get(r, 'r2').raw, 1); close(get(r, 'pred').raw, 8); });
T('frações', () => { assert.strictEqual(calc('math', 'fraction', { n1: 1, d1: 2, op: '+', n2: 1, d2: 3 }).results[0].text, '5/6'); assert.strictEqual(calc('math', 'fraction', { n1: 3, d1: 4, op: '/', n2: 3, d2: 8 }).results[0].text, '2'); assert.strictEqual(calc('math', 'fromdec', { x: 0.375 }).results[0].text, '3/8'); assert.strictEqual(calc('math', 'fromdec', { x: 0.3333333333 }).results[0].text, '1/3'); });
T('números', () => { const r = calc('math', 'numbers', { a: 360, b: 84 }); assert.match(get(r, 'f').text, /2³ × 3² × 5/); assert.strictEqual(get(r, 'cnt').raw, 24); assert.strictEqual(get(r, 'gcd').raw, 12); assert.strictEqual(get(r, 'lcm').raw, 2520); assert.match(calc('math', 'numbers', { a: 97, b: NaN }).results[0].text, /primo/); });

T('variáveis no motor', () => { assert.strictEqual(E.evaluate('preco*2+x', { vars: { preco: 10, x: 1 } }), 21); assert.strictEqual(E.compile('x^2', {})({ x: 3 }), 9); assert.throws(() => E.evaluate('abc+1'), /desconhecida/); assert.throws(() => E.evaluate('constructor+1'), /desconhecida/); });
T('formato BR e casas', () => { assert.strictEqual(E.pretty('1234567.891'), '1.234.567,891'); assert.strictEqual(E.pretty('12×3,5'.replace(',', '.')), '12×3,5'); assert.strictEqual(E.pretty('1234.', {}), '1.234,'); assert.strictEqual(E.pretty('1234.5', { group: false }), '1234,5'); assert.strictEqual(E.format(1 / 3, { dec: 2 }), '0.33'); assert.strictEqual(E.format(2, { dec: 'auto' }), '2'); });

T('Price traz barras e rótulos do gráfico', () => { const r = calc('finance', 'price', { pv: 10000, rate: 1, rper: 'mes', n: 12, sys: 'price' }); assert.ok(r.bars.items.length >= 3); assert.ok(r.bars.items[0].a > r.bars.items[r.bars.items.length - 1].a); assert.strictEqual(r.chart.xs.length, r.chart.series[0].values.length); const c = calc('finance', 'compound', { vp: 1000, pmt: 0, rate: 1, rper: 'mes', time: 120, tper: 'meses' }); assert.strictEqual(c.chart.xs.length, c.chart.series[0].values.length); });
T('entradas salvas (recall/keep)', () => { const m = {}; globalThis.localStorage = { getItem: (k) => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = String(v); } }; Tools.keep('x', { sec: 'a', raw: { a: { n: '5' } } }); assert.deepStrictEqual(Tools.recall('x'), { sec: 'a', raw: { a: { n: '5' } } }); assert.strictEqual(Tools.recall('nada'), null); delete globalThis.localStorage; assert.strictEqual(Tools.recall('x'), null); Tools.keep('x', {}); });

let fail = 0;
for (const [n, f] of tests) { try { f(); console.log('ok  ', n); } catch (e) { fail++; console.log('FAIL', n, '-', e.message); } }
process.exit(fail ? 1 : 0);
