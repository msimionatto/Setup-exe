const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { prepare, icoMax, pngSize } = require('../scripts/prepare-icon.js');

const ico = (...sizes) => { const b = Buffer.alloc(6 + 16 * sizes.length); b.writeUInt16LE(1, 2); b.writeUInt16LE(sizes.length, 4); sizes.forEach((s, i) => { b[6 + i * 16] = s >= 256 ? 0 : s; b[7 + i * 16] = s >= 256 ? 0 : s; }); return b; };
const png = (w, h) => { const b = Buffer.alloc(33); Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]).copy(b); b.writeUInt32BE(13, 8); b.write('IHDR', 12); b.writeUInt32BE(w, 16); b.writeUInt32BE(h, 20); return b; };
const mk = (files) => { const d = fs.mkdtempSync(path.join(os.tmpdir(), 'ic-')); fs.mkdirSync(path.join(d, 'imagens')); for (const [n, b] of Object.entries(files)) fs.writeFileSync(path.join(d, 'imagens', n), b); return d; };
const tests = []; const T = (n, f) => tests.push([n, f]);

T('leitura de tamanhos', () => { assert.strictEqual(icoMax(ico(16, 32, 256)), 256); assert.strictEqual(icoMax(ico(32)), 32); assert.strictEqual(icoMax(Buffer.from('xx')), null); assert.deepStrictEqual(pngSize(png(512, 512)), { w: 512, h: 512 }); assert.strictEqual(pngSize(Buffer.alloc(30)), null); });
T('Logo.ico válido é usado', () => { const d = mk({ 'Logo.ico': ico(16, 48, 256) }); const r = prepare(d); assert.strictEqual(r.source, 'Logo.ico'); assert.ok(fs.existsSync(path.join(d, 'build', 'icon.ico'))); assert.deepStrictEqual(r.warnings, []); });
T('Logo.ico pequeno (causa do instalador sumir): usa o PNG', () => { const d = mk({ 'Logo.ico': ico(32), 'Logo.png': png(512, 512) }); const r = prepare(d); assert.strictEqual(r.source, 'Logo.png'); assert.ok(fs.existsSync(path.join(d, 'build', 'icon.png')) && !fs.existsSync(path.join(d, 'build', 'icon.ico'))); assert.match(r.warnings[0], /só 32x32/); });
T('sem fonte válida: segue com o ícone padrão, sem travar', () => { const d = mk({ 'Logo.ico': ico(32), 'Logo.png': png(128, 128) }); const r = prepare(d); assert.strictEqual(r.source, null); assert.strictEqual(fs.readdirSync(path.join(d, 'build')).length, 0); assert.ok(r.warnings.length === 2); const e = prepare(mk({})); assert.strictEqual(e.source, null); assert.match(e.warnings.join(' '), /não encontrado/); });
T('limpa ícone antigo e avisa PNG não quadrado', () => { const d = mk({ 'Logo.png': png(600, 300) }); fs.mkdirSync(path.join(d, 'build')); fs.writeFileSync(path.join(d, 'build', 'icon.ico'), 'velho'); const r = prepare(d); assert.ok(!fs.existsSync(path.join(d, 'build', 'icon.ico'))); assert.ok(r.warnings.some((w) => /quadrado/.test(w))); });
let fail = 0; for (const [n, f] of tests) { try { f(); console.log('ok  ', n); } catch (e) { fail++; console.log('FAIL', n, '-', e.message); } }
process.exit(fail ? 1 : 0);
