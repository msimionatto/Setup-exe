// Validações usadas pelo processo principal (sem dependência do Electron: testável)
const KINDS = new Set(['pdf', 'xlsx', 'tape']);
const str = (s, n = 300) => String(s ?? '').slice(0, n);
const num = (n, lo, hi, d) => { const x = Number(n); return Number.isFinite(x) ? Math.min(hi, Math.max(lo, x)) : d; };

function cleanPayload(p) {
  if (!p || typeof p !== 'object') throw new Error('Dados inválidos');
  const rows = Array.isArray(p.rows) ? p.rows.slice(0, 5000).map((r) => ({ ts: num(r && r.ts, 0, 4102444800000, Date.now()), mode: str(r && r.mode, 40), expr: str(r && r.expr, 500), res: str(r && r.res, 300) })) : [];
  const c = p.current && typeof p.current === 'object' ? { expr: str(p.current.expr, 500), res: str(p.current.res, 300) } : null;
  return { rows, current: c, modeName: str(p.modeName, 40), angle: str(p.angle, 8), stamp: str(p.stamp, 32).replace(/[^0-9-]/g, '') || 'relatorio' };
}
const cleanKind = (k) => (KINDS.has(k) ? k : null);
const cleanText = (t) => str(t, 2e6);
const safeName = (s) => str(s, 80).replace(/[^\w.-]/g, '_') || 'AllCalculadora';
const validColor = (c) => typeof c === 'string' && /^#[0-9a-fA-F]{3,8}$/.test(c.trim());
const clampSize = (w, h) => ({ w: num(w, 300, 2000, 420), h: num(h, 400, 1600, 720) });
// só aceita mensagens vindas da janela principal carregada de arquivo local
function isTrusted(e, win) {
  return !!(win && !win.isDestroyed() && e && e.sender === win.webContents && e.senderFrame && typeof e.senderFrame.url === 'string' && e.senderFrame.url.startsWith('file://'));
}
module.exports = { cleanPayload, cleanKind, cleanText, safeName, validColor, clampSize, isTrusted };
