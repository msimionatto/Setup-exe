// Lê uma versão específica do CHANGELOG.md (usado em "O que mudou" e nas notas da release)
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
function section(text, version) {
  const m = new RegExp('^##\\s+' + esc(String(version)) + '\\b.*$', 'm').exec(String(text));
  if (!m) return '';
  const rest = String(text).slice(m.index + m[0].length); const n = rest.search(/^##\s+/m);
  return (n < 0 ? rest : rest.slice(0, n)).trim();
}
const latestVersion = (text) => { const m = /^##\s+([0-9][^\s]*)/m.exec(String(text)); return m ? m[1] : ''; };
module.exports = { section, latestVersion };
