// Geração de relatórios (HTML para PDF/fita) e planilha Excel — sem dependências do Electron
const fs = require('fs');
const { pathToFileURL } = require('url');

const e = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const when = (ts) => new Date(ts).toLocaleString('pt-BR');

function reportHTML(p, { tape = false, logo } = {}) {
  const logoUrl = logo && fs.existsSync(logo) ? pathToFileURL(logo).href : '';
  const now = when(Date.now());
  if (tape) {
    const lines = p.rows.map((r) => `<div class="ex">${e(r.expr)}</div><div class="rs">${e(r.res)}</div>`).join('');
    const cur = p.current ? `<div class="sep"></div><div class="ex">${e(p.current.expr)}</div><div class="rs">= ${e(p.current.res)}</div>` : '';
    return `<!doctype html><html><head><meta charset="utf-8"><style>
      @page{margin:6mm}body{width:68mm;margin:0 auto;font-family:"Courier New",monospace;font-size:12px;color:#000}
      .c{text-align:center}.ex{color:#444;text-align:right;word-break:break-all}.rs{text-align:right;font-weight:bold;margin-bottom:4px;word-break:break-all}
      .sep{border-top:1px dashed #000;margin:8px 0}img{width:34px;height:34px;object-fit:contain}</style></head><body>
      <div class="c">${logoUrl ? `<img src="${logoUrl}">` : ''}<div><b>AllCalculadora</b></div><div>${e(now)}</div></div><div class="sep"></div>
      ${lines || '<div class="c">(sem histórico)</div>'}${cur}<div class="sep"></div><div class="c">Desenvolvido por Marcos Simionatto</div></body></html>`;
  }
  const rows = p.rows.map((r) => `<tr><td>${e(when(r.ts))}</td><td>${e(r.mode)}</td><td>${e(r.expr)}</td><td class="n">${e(r.res)}</td></tr>`).join('');
  return `<!doctype html><html><head><meta charset="utf-8"><style>
    *{box-sizing:border-box}body{font-family:"Segoe UI",Arial,sans-serif;color:#1e1433;margin:0;font-size:12px}
    header{display:flex;align-items:center;gap:14px;padding:0 0 12px;border-bottom:3px solid #7c4ddb;margin-bottom:14px}
    header img{width:54px;height:54px;object-fit:contain}h1{margin:0;font-size:22px;color:#5a2fc2}.m{color:#6b5a8f;font-size:12px;margin-top:3px}
    table{width:100%;border-collapse:collapse}th{background:#7c4ddb;color:#fff;text-align:left;padding:7px 8px;font-size:11.5px}
    td{padding:6px 8px;border-bottom:1px solid #e6dcf8;vertical-align:top}td:first-child{white-space:nowrap}tr:nth-child(even) td{background:#f7f2ff}.n{text-align:right;font-weight:600;color:#5a2fc2}
    .cur{margin:0 0 14px;padding:10px 12px;border:1px solid #d9ccf2;border-radius:8px;background:#f7f2ff}
    footer{position:fixed;bottom:0;left:0;right:0;text-align:center;color:#6b5a8f;font-size:10.5px;border-top:1px solid #e6dcf8;padding-top:6px}
  </style></head><body>
    <header>${logoUrl ? `<img src="${logoUrl}">` : ''}<div><h1>AllCalculadora</h1><div class="m">Relatório gerado em ${e(now)} · Modo ${e(p.modeName)}${p.angle ? ' (' + e(p.angle) + ')' : ''}</div></div></header>
    ${p.current ? `<div class="cur"><b>Cálculo atual:</b> ${e(p.current.expr)} ${p.current.res ? '= <b>' + e(p.current.res) + '</b>' : ''}</div>` : ''}
    <table><thead><tr><th style="width:22%">Data/hora</th><th style="width:16%">Modo</th><th>Operação</th><th style="width:22%;text-align:right">Resultado</th></tr></thead><tbody>${rows || '<tr><td colspan="4">Sem itens no histórico.</td></tr>'}</tbody></table>
    <footer>© ${new Date().getFullYear()} AllCalculadora • Desenvolvido por Marcos Simionatto</footer></body></html>`;
}

async function buildXlsx(p, file, logo) {
  const ExcelJS = require('exceljs');
  const wb = new ExcelJS.Workbook(); wb.creator = 'AllCalculadora'; wb.created = new Date();
  const ws = wb.addWorksheet('Histórico', { views: [{ state: 'frozen', ySplit: 4 }] });
  ws.columns = [{ width: 20 }, { width: 18 }, { width: 46 }, { width: 24 }];
  ws.getRow(1).height = 34;
  ws.getCell('B1').value = 'AllCalculadora'; ws.getCell('B1').font = { size: 18, bold: true, color: { argb: 'FF5A2FC2' } };
  ws.getCell('B2').value = `Gerado em ${when(Date.now())} · Modo ${p.modeName}${p.angle ? ' (' + p.angle + ')' : ''}`; ws.getCell('B2').font = { color: { argb: 'FF6B5A8F' } };
  if (logo && fs.existsSync(logo)) { try { const id = wb.addImage({ filename: logo, extension: 'png' }); ws.addImage(id, { tl: { col: 0.1, row: 0.05 }, ext: { width: 40, height: 40 } }); } catch (_) { /* logo opcional */ } }
  const h = ws.getRow(4); h.values = ['Data/hora', 'Modo', 'Operação', 'Resultado'];
  h.eachCell((c) => { c.font = { bold: true, color: { argb: 'FFFFFFFF' } }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF7C4DDB' } }; c.alignment = { vertical: 'middle' }; });
  p.rows.forEach((r) => { const row = ws.addRow([new Date(r.ts), r.mode, r.expr, r.res]); row.getCell(1).numFmt = 'dd/mm/yyyy hh:mm'; row.getCell(4).alignment = { horizontal: 'right' }; row.getCell(4).font = { bold: true, color: { argb: 'FF5A2FC2' } }; });
  ws.addRow([]); const f = ws.addRow(['Desenvolvido por Marcos Simionatto']); f.getCell(1).font = { italic: true, color: { argb: 'FF6B5A8F' } };
  ws.autoFilter = { from: 'A4', to: 'D4' };
  await wb.xlsx.writeFile(file);
}
module.exports = { reportHTML, buildXlsx };
