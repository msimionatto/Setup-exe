// Central de Atualizações: máquina de estados em volta do electron-updater (testável com um updater falso)
const CHANNELS = ['stable', 'beta'];
const HOURS = 4;
const RELEASES = 'https://github.com/msimionatto/CalculadoraLilasDark/releases/latest';

function friendlyError(e) {
  const m = String((e && (e.message || e.code)) || e || '');
  if (/\b(404|401|403)\b|not found|private|latest\.yml/i.test(m)) return 'Não foi possível consultar as versões. Se o repositório do GitHub for privado, ele precisa ser público para o app atualizar.';
  if (/ENOTFOUND|ENETUNREACH|ETIMEDOUT|ECONNREFUSED|ECONNRESET|EAI_AGAIN|ERR_INTERNET|ERR_NETWORK|net::|offline/i.test(m)) return 'Sem conexão com a internet. Tente novamente mais tarde.';
  if (/sign|signature|publisher|certificate/i.test(m)) return 'A assinatura da atualização não confere. Baixe o instalador manualmente no site oficial.';
  if (/checksum|sha512|hash/i.test(m)) return 'O arquivo baixado está corrompido. Tente novamente.';
  return 'Falha ao atualizar: ' + m.split('\n')[0].slice(0, 160);
}
function cleanNotes(n) {
  const t = Array.isArray(n) ? n.map((x) => (x && x.note) || x).join('\n') : String(n || '');
  return t.replace(/<br\s*\/?>|<\/(p|li|h\d)>/gi, '\n').replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\n{3,}/g, '\n\n').trim().slice(0, 4000);
}
const nullLogger = { info() {}, warn() {}, error() {}, debug() {} };

function createUpdateCenter({ updater, version, packaged, store, logger = nullLogger, send = () => {}, timers = { setTimeout, setInterval } }) {
  let st = { state: packaged ? 'idle' : 'dev', current: version, version: '', percent: 0, notes: '', error: '', manualUrl: RELEASES, lastCheck: 0, manual: false };
  const emit = (patch) => { st = { ...st, ...patch }; send({ ...st }); return st; };
  const settings = () => ({ autoCheck: true, channel: 'stable', skipped: '', ...store.get() });
  const busy = () => st.state === 'checking' || st.state === 'downloading';

  function onError(e) {
    logger.error('Atualização falhou:', e);
    emit({ state: 'error', error: friendlyError(e), percent: 0 });
  }
  function download() {
    if (!packaged) return st;
    store.set({ skipped: '' }); emit({ state: 'downloading', percent: 0, error: '' });
    Promise.resolve(updater.downloadUpdate()).catch(onError);
    return st;
  }
  function onAvailable(info) {
    const s = settings(); const v = info && info.version;
    logger.info('Atualização disponível:', v);
    emit({ version: v, notes: cleanNotes(info && info.releaseNotes), lastCheck: Date.now(), error: '' });
    if (s.skipped === v && !st.manual) return emit({ state: 'skipped' });
    if (s.autoCheck) return download();
    return emit({ state: 'available' });
  }
  function attach() {
    updater.autoDownload = false; updater.autoInstallOnAppQuit = true; updater.allowDowngrade = false; updater.logger = logger;
    updater.on('checking-for-update', () => emit({ state: 'checking', error: '' }));
    updater.on('update-available', onAvailable);
    updater.on('update-not-available', () => { logger.info('Já está na versão mais recente'); emit({ state: 'none', lastCheck: Date.now(), version: '', percent: 0 }); });
    updater.on('download-progress', (p) => emit({ state: 'downloading', percent: Math.round((p && p.percent) || 0) }));
    updater.on('update-downloaded', (info) => { logger.info('Atualização baixada:', info && info.version); emit({ state: 'ready', percent: 100, version: (info && info.version) || st.version, notes: cleanNotes(info && info.releaseNotes) || st.notes }); });
    updater.on('error', onError);
  }
  async function check({ manual = false } = {}) {
    if (!packaged) return emit({ state: 'dev', manual });
    if (busy() || st.state === 'ready') { emit({ manual }); return st; }
    const s = settings(); updater.allowPrerelease = s.channel === 'beta';
    emit({ state: 'checking', manual, error: '' });
    try { await updater.checkForUpdates(); } catch (e) { onError(e); }
    return st;
  }
  function setSettings(patch = {}) {
    const next = {};
    if (typeof patch.autoCheck === 'boolean') next.autoCheck = patch.autoCheck;
    if (CHANNELS.includes(patch.channel)) next.channel = patch.channel;
    store.set(next); logger.info('Configurações de atualização:', next);
    return settings();
  }
  function skip() { if (st.version) store.set({ skipped: st.version }); return emit({ state: 'skipped' }); }
  function install() { if (st.state === 'ready') { logger.info('Reiniciando para instalar', st.version); updater.quitAndInstall(false, true); } return st; }
  function start() {
    if (!packaged) return;
    const tick = () => { if (settings().autoCheck) check({ manual: false }); };
    const a = timers.setTimeout(tick, 20000); const b = timers.setInterval(tick, HOURS * 3600e3);
    [a, b].forEach((t) => t && t.unref && t.unref());
  }
  return { attach, start, check, download, install, skip, setSettings, getSettings: settings, getState: () => ({ ...st }) };
}
module.exports = { createUpdateCenter, friendlyError, cleanNotes, CHANNELS };
