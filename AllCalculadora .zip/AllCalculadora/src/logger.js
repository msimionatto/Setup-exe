// Log em arquivo com rotação (userData/logs/allcalc.log). Compatível com o "logger" do electron-updater.
const fs = require('fs');
const path = require('path');

const fmt = (a) => (a instanceof Error ? (a.stack || a.message) : typeof a === 'object' && a !== null ? (() => { try { return JSON.stringify(a); } catch (_) { return String(a); } })() : String(a));

function createLogger(dir, { max = 1e6 } = {}) {
  const file = path.join(dir, 'allcalc.log'); let ready = false;
  const write = (level, args) => {
    try {
      if (!ready) { fs.mkdirSync(dir, { recursive: true }); ready = true; }
      if (fs.existsSync(file) && fs.statSync(file).size > max) fs.renameSync(file, file + '.old');
      fs.appendFileSync(file, `${new Date().toISOString()} [${level}] ${args.map(fmt).join(' ')}\n`);
    } catch (_) { /* log nunca pode derrubar o app */ }
  };
  return { dir, file, info: (...a) => write('INFO', a), warn: (...a) => write('WARN', a), error: (...a) => write('ERROR', a), debug: (...a) => write('DEBUG', a) };
}
module.exports = { createLogger };
