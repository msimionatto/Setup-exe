/* AllCalculadora - Gráficos de funções (canvas): zoom com roda, arrastar para mover */
(function (root) {
  'use strict';
  const { define, F, esc, recall, keep } = root.Tools;
  const EXAMPLES = ['sin(x)', 'x^2-4', 'x^3-3x', '1/x', 'ln(x)', 'abs(x)', 'e^x', 'cos(x)*x'];
  define({
    id: 'graph', name: 'Gráficos', glyph: 'ƒx', desc: 'Desenhe funções, encontre raízes e explore com zoom',
    render(host, ctx) {
      const g = (this._g = this._g || (() => {
        const d = { fns: ['sin(x)', 'x^2-4', ''], view: { cx: 0, cy: 0, s: 40 } }; const m = recall('graph');
        if (m && Array.isArray(m.fns) && m.view) { d.fns = m.fns.slice(0, 3).map(String); while (d.fns.length < 3) d.fns.push(''); Object.assign(d.view, m.view); }
        return d;
      })());
      const view = g.view;
      host.innerHTML = `<div class="thead"><div class="tg">ƒx</div><div><h2>Gráficos</h2><p>Digite funções de <b>x</b>. Arraste para mover, use a roda para o zoom.</p></div></div>
        <div class="sbody enter">
        <div class="gfns">${g.fns.map((f, i) => `<div class="gfn"><i class="gdot" data-c="${i}"></i><span class="gl">f${i + 1}(x) =</span><input data-i="${i}" value="${esc(f)}" placeholder="${i ? 'opcional' : 'ex.: x^2 - 4'}" spellcheck="false" autocomplete="off"></div><small class="gerr" data-e="${i}"></small>`).join('')}</div>
        <div class="gex">${EXAMPLES.map((e) => `<button class="chip" data-ex="${esc(e)}">${esc(e)}</button>`).join('')}</div>
        <div class="gwrap"><canvas></canvas><div class="gread">Passe o mouse sobre o gráfico</div></div>
        <div class="gbar"><button class="mini" data-z="in">＋ Zoom</button><button class="mini" data-z="out">－ Zoom</button><button class="mini" data-z="reset">Redefinir</button></div>
        <div class="groots" id="gRoots"></div>
        <details class="learn"><summary>Como usar</summary><div>Use <code>x</code> como variável: <code>x^2</code>, <code>sin(x)</code>, <code>sqrt(x)</code>, <code>ln(x)</code>, <code>abs(x)</code>, <code>e^x</code>. Ângulos são em <b>radianos</b>. Suas variáveis salvas também funcionam.<br>As <b>raízes</b> são onde a curva cruza o eixo x (f(x)=0). Clique numa raiz para centralizar nela. Dê duplo clique no gráfico para voltar ao início.</div></details></div>`;
      const cv = host.querySelector('canvas'), c2 = cv.getContext('2d'), wrap = host.querySelector('.gwrap'), read = host.querySelector('.gread'), rootsEl = host.querySelector('#gRoots');
      const E = root.Engine; let W = 300, H = 260, mouse = null, reveal = 1, raf = 0; let fns = [];
      const css = () => { const s = getComputedStyle(document.body); const v = (n) => s.getPropertyValue(n).trim(); return { line: v('--line'), muted: v('--muted'), text: v('--text'), cols: [v('--lilac'), v('--accent'), v('--ok')], bg: v('--surface') }; };
      const cols = css().cols; host.querySelectorAll('.gdot').forEach((d, i) => { d.style.background = cols[i]; });

      function compileAll() {
        const vars = ctx.vars ? ctx.vars() : {};
        fns = g.fns.map((src, i) => {
          const el = host.querySelector(`[data-e="${i}"]`); el.textContent = '';
          if (!src.trim()) return null;
          try { const run = E.compile(src.replace(/,/g, '.'), { angle: 'RAD', vars }); run({ x: 1 }); return { run, i }; } catch (e) { if (e.user && !/domín|zero|grande|indefinido/i.test(e.message)) { el.textContent = e.message; return null; } try { return { run: E.compile(src.replace(/,/g, '.'), { angle: 'RAD', vars }), i }; } catch (_) { return null; } }
        }).filter(Boolean);
      }
      const val = (f, x) => { try { return f.run({ x }); } catch (_) { return NaN; } };
      const sx = (x) => W / 2 + (x - view.cx) * view.s; const sy = (y) => H / 2 - (y - view.cy) * view.s;
      const niceStep = () => { const raw = 70 / view.s; const p = Math.pow(10, Math.floor(Math.log10(raw))); const m = raw / p; return (m < 1.5 ? 1 : m < 3.5 ? 2 : m < 7.5 ? 5 : 10) * p; };
      const lab = (n) => { const a = Math.abs(n); return (a !== 0 && (a >= 1e6 || a < 1e-4)) ? n.toExponential(1) : String(Number(n.toPrecision(6))); };

      function draw() {
        const C = css(); c2.setTransform(devicePixelRatio || 1, 0, 0, devicePixelRatio || 1, 0, 0); c2.clearRect(0, 0, W, H);
        const st = niceStep(); const x0 = view.cx - W / 2 / view.s, x1 = view.cx + W / 2 / view.s, y0 = view.cy - H / 2 / view.s, y1 = view.cy + H / 2 / view.s;
        c2.lineWidth = 1; c2.font = '11px "Segoe UI", sans-serif'; c2.fillStyle = C.muted;
        for (let x = Math.ceil(x0 / st) * st; x <= x1; x += st) { const px = Math.round(sx(x)) + 0.5; c2.strokeStyle = Math.abs(x) < st / 1e6 ? C.muted : C.line; c2.globalAlpha = Math.abs(x) < st / 1e6 ? 0.9 : 0.55; c2.beginPath(); c2.moveTo(px, 0); c2.lineTo(px, H); c2.stroke(); }
        for (let y = Math.ceil(y0 / st) * st; y <= y1; y += st) { const py = Math.round(sy(y)) + 0.5; c2.strokeStyle = Math.abs(y) < st / 1e6 ? C.muted : C.line; c2.globalAlpha = Math.abs(y) < st / 1e6 ? 0.9 : 0.55; c2.beginPath(); c2.moveTo(0, py); c2.lineTo(W, py); c2.stroke(); }
        c2.globalAlpha = 1;
        const ax = Math.min(Math.max(sx(0), 4), W - 30), ay = Math.min(Math.max(sy(0), 12), H - 4);
        for (let x = Math.ceil(x0 / st) * st; x <= x1; x += st) if (Math.abs(x) > st / 1e6) c2.fillText(lab(x), sx(x) + 3, ay - 3 > H - 14 ? H - 14 : ay + 12);
        for (let y = Math.ceil(y0 / st) * st; y <= y1; y += st) if (Math.abs(y) > st / 1e6) c2.fillText(lab(y), ax + 4, sy(y) - 3);
        c2.save(); c2.beginPath(); c2.rect(0, 0, W * reveal, H); c2.clip();
        fns.forEach((f) => {
          c2.strokeStyle = C.cols[f.i]; c2.lineWidth = 2.2; c2.lineJoin = 'round'; c2.beginPath(); let pen = false, prev = 0;
          for (let px = 0; px <= W; px++) {
            const y = val(f, view.cx + (px - W / 2) / view.s); const py = sy(y);
            if (!Number.isFinite(y) || Math.abs(py) > 1e5) { pen = false; continue; }
            if (pen && Math.abs(py - prev) > H * 1.2) pen = false;
            if (pen) c2.lineTo(px, py); else { c2.moveTo(px, py); pen = true; } prev = py;
          }
          c2.stroke();
        });
        c2.restore();
        if (mouse) {
          const x = view.cx + (mouse.x - W / 2) / view.s; c2.setLineDash([4, 4]); c2.strokeStyle = C.muted; c2.beginPath(); c2.moveTo(mouse.x + 0.5, 0); c2.lineTo(mouse.x + 0.5, H); c2.stroke(); c2.setLineDash([]);
          const parts = [`x = ${lab(Number(x.toPrecision(5)))}`];
          fns.forEach((f) => { const y = val(f, x); if (Number.isFinite(y)) { c2.fillStyle = C.cols[f.i]; c2.beginPath(); c2.arc(mouse.x, sy(y), 4.5, 0, 6.3); c2.fill(); parts.push(`f${f.i + 1} = ${lab(Number(y.toPrecision(5)))}`); } });
          read.textContent = parts.join('   ·   ');
        }
      }
      function roots() {
        const f = fns[0]; if (!f) { rootsEl.innerHTML = ''; return; }
        const a = view.cx - W / 2 / view.s, b = view.cx + W / 2 / view.s, N = 700, out = [];
        let px = a, py = val(f, a);
        for (let i = 1; i <= N && out.length < 6; i++) {
          const x = a + ((b - a) * i) / N, y = val(f, x);
          if (y === 0 && py !== 0) out.push(x); // raiz exatamente sobre uma amostra (ex.: sin(x) em x = 0)
          else if (Number.isFinite(py) && Number.isFinite(y) && py !== 0 && py * y < 0) {
            let lo = px, hi = x, flo = py; for (let k = 0; k < 50; k++) { const m = (lo + hi) / 2, fm = val(f, m); if (flo * fm <= 0) hi = m; else { lo = m; flo = fm; } }
            const r = (lo + hi) / 2; if (Math.abs(val(f, r)) < 1e-4) out.push(r);
          }
          px = x; py = y;
        }
        const y0 = val(f, 0);
        rootsEl.innerHTML = `<span class="cap">Raízes de f1 na tela</span>` + (out.length ? out.map((r) => `<button class="chip" data-r="${r}">x ≈ ${F.max(r, 4)}</button>`).join('') : '<span class="muted">nenhuma visível</span>') + (Number.isFinite(y0) ? `<span class="muted">f1(0) = ${F.max(y0, 4)}</span>` : '');
      }
      const persistG = (() => { let t; return () => { clearTimeout(t); t = setTimeout(() => keep('graph', { fns: g.fns, view }), 400); }; })();
      const redraw = () => { draw(); roots(); persistG(); };
      function resize() { const r = wrap.getBoundingClientRect(); const d = devicePixelRatio || 1; W = Math.max(200, r.width); H = Math.max(200, r.height); cv.width = W * d; cv.height = H * d; redraw(); }
      function play() {
        cancelAnimationFrame(raf); if (document.body.dataset.anim === 'off') { reveal = 1; return redraw(); }
        const t0 = performance.now(); reveal = 0;
        const tick = (t) => { reveal = Math.min(1, (t - t0) / 650); reveal = 1 - Math.pow(1 - reveal, 3); redraw(); if (reveal < 1) raf = requestAnimationFrame(tick); };
        raf = requestAnimationFrame(tick);
      }
      // zoom suave: aproxima a escala do alvo mantendo o ponto sob o cursor fixo
      let zt = null, zraf = 0;
      const stepZoom = () => {
        zraf = 0; if (!zt) return;
        const k = document.body.dataset.anim === 'off' ? 1 : 0.28; view.s += (zt.s - view.s) * k;
        if (Math.abs(zt.s - view.s) < zt.s * 0.002) view.s = zt.s;
        view.cx = zt.wx - (zt.px - W / 2) / view.s; view.cy = zt.wy + (zt.py - H / 2) / view.s; redraw();
        if (view.s !== zt.s) zraf = requestAnimationFrame(stepZoom); else zt = null;
      };
      const zoom = (f, px = W / 2, py = H / 2) => {
        const base = zt ? zt.s : view.s;
        zt = { s: Math.min(1e6, Math.max(1e-3, base * f)), px, py, wx: view.cx + (px - W / 2) / view.s, wy: view.cy - (py - H / 2) / view.s };
        if (!zraf) zraf = requestAnimationFrame(stepZoom);
      };

      host.querySelector('.gfns').addEventListener('input', (e) => { const i = e.target.dataset.i; if (i === undefined) return; g.fns[i] = e.target.value; compileAll(); play(); });
      host.querySelector('.gex').addEventListener('click', (e) => { const b = e.target.closest('[data-ex]'); if (!b) return; const slot = g.fns.findIndex((f) => !f.trim()); const i = slot < 0 ? 0 : slot; g.fns[i] = b.dataset.ex; host.querySelector(`input[data-i="${i}"]`).value = b.dataset.ex; compileAll(); play(); });
      host.querySelector('.gbar').addEventListener('click', (e) => { const z = e.target.closest('[data-z]'); if (!z) return; if (z.dataset.z === 'reset') { Object.assign(view, { cx: 0, cy: 0, s: 40 }); redraw(); } else zoom(z.dataset.z === 'in' ? 1.4 : 1 / 1.4); });
      rootsEl.addEventListener('click', (e) => { const b = e.target.closest('[data-r]'); if (b) { view.cx = Number(b.dataset.r); view.cy = 0; redraw(); } });
      let drag = null;
      cv.addEventListener('pointerdown', (e) => { drag = { x: e.clientX, y: e.clientY }; cv.setPointerCapture(e.pointerId); cv.classList.add('grab'); });
      cv.addEventListener('pointermove', (e) => { const r = cv.getBoundingClientRect(); mouse = { x: e.clientX - r.left, y: e.clientY - r.top }; if (drag) { view.cx -= (e.clientX - drag.x) / view.s; view.cy += (e.clientY - drag.y) / view.s; drag = { x: e.clientX, y: e.clientY }; } redraw(); });
      cv.addEventListener('pointerup', () => { drag = null; cv.classList.remove('grab'); });
      cv.addEventListener('pointerleave', () => { mouse = null; read.textContent = 'Passe o mouse sobre o gráfico'; redraw(); });
      cv.addEventListener('wheel', (e) => { e.preventDefault(); const r = cv.getBoundingClientRect(); zoom(Math.pow(1.0017, -e.deltaY), e.clientX - r.left, e.clientY - r.top); }, { passive: false });
      cv.addEventListener('dblclick', () => { Object.assign(view, { cx: 0, cy: 0, s: 40 }); redraw(); });
      if (window.ResizeObserver) new ResizeObserver(() => resize()).observe(wrap);
      compileAll(); resize(); play();
    },
  });
})(typeof window !== 'undefined' ? window : globalThis);
