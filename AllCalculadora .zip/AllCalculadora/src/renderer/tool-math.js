/* AllCalculadora - Matemática avançada */
(function (root) {
  'use strict';
  const { define, F, uerr } = root.Tools;
  const gcd = (a, b) => { a = Math.abs(a); b = Math.abs(b); while (b) [a, b] = [b, a % b]; return a; };
  const lcm = (a, b) => (a / gcd(a, b)) * b;
  const frac = (n, d) => { if (d === 0) throw uerr('O denominador não pode ser zero.'); if (d < 0) { n = -n; d = -d; } const g = gcd(n, d) || 1; return [n / g, d / g]; };
  const fs = (n, d) => (d === 1 ? String(n) : `${n}/${d}`);
  const mixed = (n, d) => { if (d === 1 || Math.abs(n) < d) return fs(n, d); const w = Math.trunc(n / d), r = Math.abs(n % d); return r === 0 ? String(w) : `${w} ${r}/${d}`; };
  const R = (k, label, raw, fmt, main) => ({ k, label, raw, fmt, main });
  const N4 = (x) => F.max(x, 6);
  const SUP = { 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
  const sup = (n) => String(n).split('').map((c) => SUP[c]).join('');
  const int = (x, name) => { if (!Number.isInteger(x)) throw uerr(`${name} deve ser um número inteiro.`); return x; };

  function parseMat(txt) {
    const rows = String(txt).split(/\n/).map((l) => l.replace(/\|/g, ' ').trim()).filter(Boolean).map((l) => l.split(/[\s;]+/).filter(Boolean).map(F.parse));
    if (!rows.length) throw uerr('Digite a matriz.');
    if (rows.some((r) => r.some((x) => Number.isNaN(x)))) throw uerr('Há valores inválidos na matriz.');
    const c = rows[0].length; if (rows.some((r) => r.length !== c)) throw uerr('Todas as linhas precisam ter o mesmo número de colunas.');
    return rows;
  }
  const mfmt = (m) => m.map((r) => r.map((x) => F.max(Math.round(x * 1e9) / 1e9, 4)));
  const mmul = (A, B) => { if (A[0].length !== B.length) throw uerr('Para A×B, colunas de A devem ser iguais às linhas de B.'); return A.map((r) => B[0].map((_, j) => r.reduce((s, x, k) => s + x * B[k][j], 0))); };
  const eye = (n) => Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => (i === j ? 1 : 0)));
  function det(A) {
    const n = A.length; const M = A.map((r) => r.slice()); let d = 1;
    for (let c = 0; c < n; c++) {
      let p = c; for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
      if (Math.abs(M[p][c]) < 1e-12) return 0; if (p !== c) { [M[p], M[c]] = [M[c], M[p]]; d = -d; }
      d *= M[c][c]; for (let r = c + 1; r < n; r++) { const f = M[r][c] / M[c][c]; for (let k = c; k < n; k++) M[r][k] -= f * M[c][k]; }
    }
    return Math.round(d * 1e9) / 1e9;
  }
  function inverse(A) {
    const n = A.length; const M = A.map((r, i) => [...r, ...eye(n)[i]]);
    for (let c = 0; c < n; c++) {
      let p = c; for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
      if (Math.abs(M[p][c]) < 1e-12) throw uerr('A matriz é singular (determinante 0) e não tem inversa.');
      [M[p], M[c]] = [M[c], M[p]]; const pv = M[c][c]; M[c] = M[c].map((x) => x / pv);
      for (let r = 0; r < n; r++) if (r !== c) { const f = M[r][c]; M[r] = M[r].map((x, k) => x - f * M[c][k]); }
    }
    return M.map((r) => r.slice(n));
  }
  // Gauss-Jordan com registro de passos
  function solveSystem(A) {
    const n = A.length; if (A[0].length !== n + 1) throw uerr(`Use ${n} equações com ${n} incógnitas + 1 coluna de termos independentes.`);
    const M = A.map((r) => r.slice()); const steps = [];
    const show = () => '<pre class="mxp">' + M.map((r) => r.map((x, j) => (j === n ? ' │' : '') + F.max(Math.round(x * 1e9) / 1e9, 3).padStart(9)).join('')).join('\n') + '</pre>';
    steps.push('Matriz aumentada inicial:' + show());
    let row = 0; const piv = [];
    for (let c = 0; c < n && row < n; c++) {
      let p = row; for (let r = row + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
      if (Math.abs(M[p][c]) < 1e-12) continue;
      if (p !== row) { [M[p], M[row]] = [M[row], M[p]]; }
      const pv = M[row][c]; M[row] = M[row].map((x) => x / pv);
      for (let r = 0; r < n; r++) if (r !== row) { const f = M[r][c]; M[r] = M[r].map((x, k) => x - f * M[row][k]); }
      steps.push(`Coluna ${c + 1}: pivô em L${row + 1} (dividimos a linha pelo pivô e zeramos a coluna nas outras linhas):` + show()); piv.push(c); row++;
    }
    for (let r = 0; r < n; r++) if (M[r].slice(0, n).every((x) => Math.abs(x) < 1e-9) && Math.abs(M[r][n]) > 1e-9) return { kind: 'none', steps };
    if (piv.length < n) return { kind: 'many', steps };
    return { kind: 'one', x: M.map((r) => r[n]), steps };
  }
  function primeFactors(n) { const f = []; let m = n; for (let p = 2; p * p <= m; p += p === 2 ? 1 : 2) { let c = 0; while (m % p === 0) { m /= p; c++; } if (c) f.push([p, c]); } if (m > 1) f.push([m, 1]); return f; }
  const nums = (s) => { const a = String(s).split(/[\s;]+/).filter(Boolean).map(F.parse); if (a.some((x) => Number.isNaN(x))) throw uerr('Há valores inválidos na lista.'); return a; };
  const quant = (s, q) => { const n = s.length; const half = (arr) => { const m = arr.length; return m % 2 ? arr[(m - 1) / 2] : (arr[m / 2 - 1] + arr[m / 2]) / 2; }; const lo = s.slice(0, Math.floor(n / 2)), hi = s.slice(Math.ceil(n / 2)); return q === 2 ? half(s) : q === 1 ? (lo.length ? half(lo) : s[0]) : (hi.length ? half(hi) : s[n - 1]); };
  const dec = (x) => F.max(x, 4);

  const sections = [
    { id: 'linear', name: '1º grau',
      learn: 'Resolve <code>a·x + b = c</code> isolando x: <code>x = (c − b) / a</code>.',
      fields: [{ k: 'a', label: 'a (multiplica x)', type: 'number', def: '2' }, { k: 'b', label: 'b', type: 'number', def: '3' }, { k: 'c', label: 'c (lado direito)', type: 'number', def: '11' }],
      calc(v) {
        if (v.a === 0) throw uerr(v.b === v.c ? 'Infinitas soluções (0 = 0).' : 'Sem solução: com a = 0 a equação vira ' + dec(v.b) + ' = ' + dec(v.c) + '.');
        const x = (v.c - v.b) / v.a; return { results: [R('x', 'x', x, N4, true)], steps: [`${dec(v.a)}x + ${dec(v.b)} = ${dec(v.c)}`, `${dec(v.a)}x = ${dec(v.c)} − ${dec(v.b)} = ${dec(v.c - v.b)}`, `x = ${dec(v.c - v.b)} ÷ ${dec(v.a)} = <code>${N4(x)}</code>`] };
      } },
    { id: 'quad', name: '2º grau',
      learn: 'Fórmula de Bhaskara para <code>ax² + bx + c = 0</code>: <code>Δ = b² − 4ac</code> e <code>x = (−b ± √Δ) / 2a</code>.<br>Δ &gt; 0: duas raízes reais · Δ = 0: uma raiz · Δ &lt; 0: raízes complexas. O vértice da parábola está em <code>x = −b/2a</code>.',
      fields: [{ k: 'a', label: 'a', type: 'number', def: '1' }, { k: 'b', label: 'b', type: 'number', def: '-5', zero: true }, { k: 'c', label: 'c', type: 'number', def: '6', zero: true }],
      calc(v) {
        if (v.a === 0) throw uerr('Com a = 0 não é equação do 2º grau. Use a aba "1º grau".');
        const D = v.b * v.b - 4 * v.a * v.c; const xv = -v.b / (2 * v.a), yv = -D / (4 * v.a);
        const res = [R('d', 'Discriminante Δ', D, N4)];
        const st = [`Δ = b² − 4ac = (${dec(v.b)})² − 4·${dec(v.a)}·${dec(v.c)} = <code>${dec(D)}</code>`];
        if (D > 0) { const s = Math.sqrt(D); const x1 = (-v.b + s) / (2 * v.a), x2 = (-v.b - s) / (2 * v.a); res.unshift(R('x1', 'x₁', x1, N4, true), R('x2', 'x₂', x2, N4, true)); st.push(`√Δ = ${N4(s)}`, `x = (−b ± √Δ) / 2a → x₁ = <code>${N4(x1)}</code>, x₂ = <code>${N4(x2)}</code>`); }
        else if (D === 0) { res.unshift(R('x1', 'x (raiz dupla)', xv, N4, true)); st.push(`Δ = 0 → x = −b/2a = <code>${N4(xv)}</code>`); }
        else { const im = Math.sqrt(-D) / (2 * Math.abs(v.a)); res.unshift({ k: 'x1', label: 'x₁', text: `${N4(xv)} + ${N4(im)}i`, main: true }, { k: 'x2', label: 'x₂', text: `${N4(xv)} − ${N4(im)}i`, main: true }); st.push('Δ < 0: não há raízes reais; as raízes são números complexos conjugados.'); }
        res.push(R('xv', 'Vértice x', xv, N4), R('yv', 'Vértice y', yv, N4), { k: 'cc', label: 'Concavidade', text: v.a > 0 ? 'para cima' : 'para baixo' }, R('sum', 'Soma das raízes (−b/a)', -v.b / v.a, N4), R('prod', 'Produto das raízes (c/a)', v.c / v.a, N4));
        return { results: res, steps: st };
      } },
    { id: 'system', name: 'Sistemas lineares',
      learn: 'Digite a <b>matriz aumentada</b>: uma equação por linha, com os coeficientes e, no fim, o termo independente. Ex.: <code>2x + y = 5</code> e <code>x − y = 1</code> viram <code>2 1 5</code> e <code>1 -1 1</code>. Usamos o método de Gauss-Jordan e mostramos cada etapa.',
      fields: [{ k: 'm', label: 'Matriz aumentada (n equações, n incógnitas + 1)', type: 'textarea', rows: 4, def: '2 1 5\n1 -1 1', ph: '2 1 | 5\n1 -1 | 1' }],
      calc(v) {
        const A = parseMat(v.m); const r = solveSystem(A); const names = ['x', 'y', 'z', 'w', 'v', 'u'];
        if (r.kind === 'none') return { results: [{ k: 's', label: 'Resultado', text: 'Sistema impossível (sem solução)', main: true }], steps: r.steps };
        if (r.kind === 'many') return { results: [{ k: 's', label: 'Resultado', text: 'Sistema indeterminado (infinitas soluções)', main: true }], steps: r.steps };
        return { results: r.x.map((x, i) => R(names[i] || 'x' + (i + 1), names[i] || 'x' + (i + 1), Math.round(x * 1e10) / 1e10, N4, true)), steps: r.steps.concat(['Lendo a última coluna, temos a solução.']) };
      } },
    { id: 'matrix', name: 'Matrizes',
      learn: 'Digite cada matriz com uma linha por linha e números separados por espaço. Operações: soma, subtração, produto, determinante, inversa, transposta e potência (A elevada a um inteiro).',
      fields: [
        { k: 'op', label: 'Operação', type: 'select', def: 'mul', options: [['add', 'A + B'], ['sub', 'A − B'], ['mul', 'A × B'], ['det', 'Determinante de A'], ['inv', 'Inversa de A'], ['tr', 'Transposta de A'], ['pow', 'A elevada a n']] },
        { k: 'a', label: 'Matriz A', type: 'textarea', rows: 3, def: '1 2\n3 4' },
        { k: 'b', label: 'Matriz B', type: 'textarea', rows: 3, def: '0 1\n1 0', show: (r) => ['add', 'sub', 'mul'].includes(r.op) },
        { k: 'n', label: 'Expoente n (inteiro ≥ 0)', type: 'number', def: '2', show: (r) => r.op === 'pow' },
      ],
      calc(v) {
        const A = parseMat(v.a); const sq = () => { if (A.length !== A[0].length) throw uerr('Esta operação exige matriz quadrada.'); };
        const res = { results: [], matrices: [], steps: [] };
        if (['add', 'sub'].includes(v.op)) { const B = parseMat(v.b); if (A.length !== B.length || A[0].length !== B[0].length) throw uerr('As matrizes precisam ter o mesmo tamanho.'); const s = v.op === 'add' ? 1 : -1; res.matrices.push({ label: v.op === 'add' ? 'A + B' : 'A − B', m: mfmt(A.map((r, i) => r.map((x, j) => x + s * B[i][j]))) }); res.steps.push('Operamos elemento a elemento: cada posição (i, j) de A com a mesma posição de B.'); }
        else if (v.op === 'mul') { const B = parseMat(v.b); res.matrices.push({ label: 'A × B', m: mfmt(mmul(A, B)) }); res.steps.push('Cada elemento (i, j) é a soma dos produtos da linha i de A pela coluna j de B.'); }
        else if (v.op === 'det') { sq(); const d = det(A); res.results.push(R('det', 'det(A)', d, N4, true)); res.steps.push(A.length === 2 ? `2×2: <code>ad − bc = ${dec(A[0][0])}·${dec(A[1][1])} − ${dec(A[0][1])}·${dec(A[1][0])} = ${dec(d)}</code>` : 'Calculado por eliminação de Gauss: produto dos pivôs, com sinal trocado a cada troca de linhas.'); }
        else if (v.op === 'inv') { sq(); res.matrices.push({ label: 'A⁻¹', m: mfmt(inverse(A)) }); res.steps.push('Aplicamos Gauss-Jordan em [A | I] até obter [I | A⁻¹].'); }
        else if (v.op === 'tr') { res.matrices.push({ label: 'Aᵀ', m: mfmt(A[0].map((_, j) => A.map((r) => r[j]))) }); res.steps.push('Linhas viram colunas.'); }
        else { sq(); const n = int(v.n, 'O expoente'); if (n < 0 || n > 30) throw uerr('Use n entre 0 e 30.'); let P = eye(A.length); for (let i = 0; i < n; i++) P = mmul(P, A); res.matrices.push({ label: `A^${n}`, m: mfmt(P) }); res.steps.push(`Multiplicamos A por ela mesma ${n} vez(es), partindo da identidade.`); }
        if (!res.results.length) res.results.push({ k: 'ok', label: 'Resultado', text: 'veja a matriz abaixo', main: true });
        return res;
      } },
    { id: 'stats', name: 'Estatística',
      learn: 'Digite os números separados por espaço, vírgula-decimal ou linha. <b>Média</b> = soma/n. <b>Mediana</b> = valor central. <b>Desvio padrão</b> mede o quanto os dados se afastam da média (amostral usa n−1).',
      fields: [{ k: 'd', label: 'Dados', type: 'textarea', rows: 4, def: '4 8 15 16 23 42', ph: '4 8 15 16 23 42' }],
      calc(v) {
        const a = nums(v.d); if (a.length < 1) throw uerr('Digite ao menos um número.'); const n = a.length; const s = a.slice().sort((x, y) => x - y);
        const sum = a.reduce((x, y) => x + y, 0), mean = sum / n; const ss = a.reduce((x, y) => x + (y - mean) ** 2, 0);
        const cnt = {}; a.forEach((x) => { cnt[x] = (cnt[x] || 0) + 1; }); const mx = Math.max(...Object.values(cnt));
        const modes = mx > 1 ? Object.keys(cnt).filter((k) => cnt[k] === mx).map(Number).sort((x, y) => x - y) : [];
        const varP = ss / n, varS = n > 1 ? ss / (n - 1) : NaN;
        return { results: [R('mean', 'Média', mean, N4, true), R('med', 'Mediana', quant(s, 2), N4), { k: 'mode', label: 'Moda', text: modes.length ? modes.map(N4).join(', ') : 'não há' }, R('n', 'Quantidade (n)', n, F.int), R('sum', 'Soma', sum, N4),
          R('min', 'Mínimo', s[0], N4), R('max', 'Máximo', s[n - 1], N4), R('rng', 'Amplitude', s[n - 1] - s[0], N4), R('q1', 'Q1', quant(s, 1), N4), R('q3', 'Q3', quant(s, 3), N4),
          R('varp', 'Variância (populacional)', varP, N4), R('sdp', 'Desvio padrão (populacional)', Math.sqrt(varP), N4), R('vars', 'Variância (amostral)', varS, N4), R('sds', 'Desvio padrão (amostral)', Math.sqrt(varS), N4), R('cv', 'Coef. de variação', mean ? (Math.sqrt(varP) / Math.abs(mean)) * 100 : NaN, (x) => F.num(x, 2) + '%')],
          steps: [`Média = ${N4(sum)} ÷ ${n} = <code>${N4(mean)}</code>`, `Soma dos quadrados dos desvios = <code>${N4(ss)}</code>`, `Variância populacional = ${N4(ss)} ÷ ${n} = <code>${N4(varP)}</code>; amostral usa n−1.`] };
      } },
    { id: 'regress', name: 'Regressão linear',
      learn: 'Digite um par <code>x y</code> por linha. A reta de mínimos quadrados <code>y = a·x + b</code> minimiza a soma dos erros ao quadrado. <b>r</b> mede a correlação (−1 a 1) e <b>r²</b> a parte da variação de y explicada por x.',
      fields: [{ k: 'p', label: 'Pontos (x y por linha)', type: 'textarea', rows: 5, def: '1 2\n2 4.1\n3 5.9\n4 8.2\n5 9.9' }, { k: 'x0', label: 'Prever y para x = (opcional)', type: 'number', opt: true, def: '6' }],
      calc(v) {
        const pts = parseMat(v.p); if (pts.some((r) => r.length !== 2)) throw uerr('Cada linha deve ter exatamente 2 números (x y).'); const n = pts.length; if (n < 2) throw uerr('Informe ao menos 2 pontos.');
        const sx = pts.reduce((a, p) => a + p[0], 0), sy = pts.reduce((a, p) => a + p[1], 0), mx = sx / n, my = sy / n;
        const sxx = pts.reduce((a, p) => a + (p[0] - mx) ** 2, 0), syy = pts.reduce((a, p) => a + (p[1] - my) ** 2, 0), sxy = pts.reduce((a, p) => a + (p[0] - mx) * (p[1] - my), 0);
        if (sxx === 0) throw uerr('Todos os x são iguais: não há reta de regressão.');
        const a = sxy / sxx, b = my - a * mx; const r = syy === 0 ? 1 : sxy / Math.sqrt(sxx * syy);
        const res = [{ k: 'eq', label: 'Equação', text: `y = ${N4(a)}x ${b < 0 ? '−' : '+'} ${N4(Math.abs(b))}`, main: true }, R('a', 'Inclinação (a)', a, N4), R('b', 'Intercepto (b)', b, N4), R('r', 'Correlação (r)', r, (x) => F.num(x, 4)), R('r2', 'Determinação (r²)', r * r, (x) => F.num(x, 4))];
        if (!Number.isNaN(v.x0)) res.push(R('pred', `Previsão ŷ(${N4(v.x0)})`, a * v.x0 + b, N4));
        return { results: res, steps: [`x̄ = ${N4(mx)}, ȳ = ${N4(my)}`, `a = Σ(x−x̄)(y−ȳ) / Σ(x−x̄)² = ${N4(sxy)} / ${N4(sxx)} = <code>${N4(a)}</code>`, `b = ȳ − a·x̄ = <code>${N4(b)}</code>`] };
      } },
    { id: 'fraction', name: 'Frações',
      learn: 'Somar/subtrair exige <b>denominador comum</b> (MMC). Multiplicar: numerador×numerador, denominador×denominador. Dividir: multiplique pelo inverso. Sempre simplificamos pelo <b>MDC</b>. Também convertemos decimal em fração.',
      fields: [{ k: 'n1', label: 'Numerador 1', type: 'number', def: '1' }, { k: 'd1', label: 'Denominador 1', type: 'number', def: '2' }, { k: 'op', label: 'Operação', type: 'select', def: '+', options: [['+', 'Somar (+)'], ['-', 'Subtrair (−)'], ['*', 'Multiplicar (×)'], ['/', 'Dividir (÷)']] },
        { k: 'n2', label: 'Numerador 2', type: 'number', def: '1' }, { k: 'd2', label: 'Denominador 2', type: 'number', def: '3' }],
      calc(v) {
        const [n1, d1, n2, d2] = [int(v.n1, 'Numerador 1'), int(v.d1, 'Denominador 1'), int(v.n2, 'Numerador 2'), int(v.d2, 'Denominador 2')];
        if (d1 === 0 || d2 === 0) throw uerr('Denominadores não podem ser zero.'); const st = []; let n, d;
        if (v.op === '+' || v.op === '-') { const L = lcm(Math.abs(d1), Math.abs(d2)); const a = n1 * (L / d1), b = n2 * (L / d2); n = v.op === '+' ? a + b : a - b; d = L; st.push(`MMC(${Math.abs(d1)}, ${Math.abs(d2)}) = <code>${L}</code>`, `${fs(n1, d1)} = ${a}/${L} e ${fs(n2, d2)} = ${b}/${L}`, `${a}/${L} ${v.op === '+' ? '+' : '−'} ${b}/${L} = ${n}/${L}`); }
        else if (v.op === '*') { n = n1 * n2; d = d1 * d2; st.push(`(${n1} × ${n2}) / (${d1} × ${d2}) = ${n}/${d}`); }
        else { if (n2 === 0) throw uerr('Não é possível dividir por zero.'); n = n1 * d2; d = d1 * n2; st.push(`Multiplicamos pelo inverso: ${fs(n1, d1)} × ${d2}/${n2} = ${n}/${d}`); }
        const g = gcd(n, d) || 1; const [sn, sd] = frac(n, d); st.push(`MDC(${Math.abs(n)}, ${Math.abs(d)}) = ${g} → <code>${fs(sn, sd)}</code>`);
        return { results: [{ k: 'f', label: 'Fração simplificada', text: fs(sn, sd), main: true }, { k: 'mixed', label: 'Número misto', text: mixed(sn, sd) }, R('dec', 'Decimal', sn / sd, N4), R('pct', 'Porcentagem', (sn / sd) * 100, (x) => F.num(x, 2) + '%')], steps: st };
      } },
    { id: 'fromdec', name: 'Decimal → fração',
      learn: 'Usamos <b>frações contínuas</b> para achar a fração mais simples que representa o decimal. Dízimas como 0,333… viram 1/3.',
      fields: [{ k: 'x', label: 'Número decimal', type: 'number', def: '0,375' }],
      calc(v) {
        const x = v.x; const neg = x < 0; let a = Math.abs(x); let [h1, h0, k1, k0] = [1, 0, 0, 1]; let b = a;
        for (let i = 0; i < 40; i++) { const ai = Math.floor(b); [h1, h0] = [ai * h1 + h0, h1]; [k1, k0] = [ai * k1 + k0, k1]; if (Math.abs(a - h1 / k1) < 1e-9 * Math.max(1, a) || k1 > 1e6) break; const fr = b - ai; if (fr < 1e-12) break; b = 1 / fr; }
        const [n, d] = frac((neg ? -1 : 1) * h1, k1);
        return { results: [{ k: 'f', label: 'Fração', text: fs(n, d), main: true }, { k: 'mixed', label: 'Número misto', text: mixed(n, d) }, R('err', 'Diferença para o decimal', Math.abs(x - n / d), (e) => (e < 1e-12 ? '0' : F.sci(e)))], steps: ['Separamos a parte inteira, invertemos a parte fracionária e repetimos (fração contínua).', `Convergente final: <code>${fs(n, d)}</code>`] };
      } },
    { id: 'numbers', name: 'Divisores, MDC e MMC',
      learn: 'A <b>fatoração prima</b> decompõe um número em primos. O <b>MDC</b> é o maior divisor comum e o <b>MMC</b> o menor múltiplo comum: <code>MMC·MDC = a·b</code>. Aceita inteiros até 10¹².',
      fields: [{ k: 'a', label: 'Número inteiro', type: 'number', def: '360' }, { k: 'b', label: 'Segundo número (opcional)', type: 'number', opt: true, def: '84' }],
      calc(v) {
        const a = int(v.a, 'O número'); if (a < 2 || a > 1e12) throw uerr('Use um inteiro entre 2 e 1.000.000.000.000.');
        const f = primeFactors(a); const ftxt = f.map(([p, c]) => (c > 1 ? p + sup(c) : String(p))).join(' × '); const isP = f.length === 1 && f[0][1] === 1;
        let divs = [1]; f.forEach(([p, c]) => { const nd = []; for (const d of divs) for (let k = 0; k <= c; k++) nd.push(d * Math.pow(p, k)); divs = nd; }); divs.sort((x, y) => x - y);
        const res = [{ k: 'f', label: 'Fatoração prima', text: isP ? `${a} é primo` : ftxt, main: true }, R('cnt', 'Quantidade de divisores', divs.length, F.int), { k: 'divs', label: 'Divisores', text: divs.length > 40 ? divs.slice(0, 40).join(', ') + '…' : divs.join(', ') }];
        const st = [`Dividimos por primos crescentes: <code>${ftxt}</code>`, `Nº de divisores = produto de (expoente + 1) = <code>${divs.length}</code>`];
        if (!Number.isNaN(v.b)) { const b = int(v.b, 'O segundo número'); if (b < 1) throw uerr('O segundo número deve ser positivo.'); res.push(R('gcd', `MDC(${a}, ${b})`, gcd(a, b), F.int), R('lcm', `MMC(${a}, ${b})`, lcm(a, b), F.int)); st.push(`MDC por Euclides: <code>${gcd(a, b)}</code> · MMC = a·b/MDC = <code>${lcm(a, b)}</code>`); }
        return { results: res, steps: st };
      } },
  ];
  define({ id: 'math', name: 'Matemática', glyph: 'Σ', desc: 'Equações, sistemas, matrizes, estatística e frações', sections, util: { solveSystem, det, inverse, gcd, lcm, primeFactors } });
})(typeof window !== 'undefined' ? window : globalThis);
