/* AllCalculadora - química: massa molar, composição e constantes */
(function (root) {
  'use strict';
  const err = (m) => Object.assign(new Error(m), { user: true });
  const W = {H:1.008,He:4.0026,Li:6.94,Be:9.0122,B:10.81,C:12.011,N:14.007,O:15.999,F:18.998,Ne:20.18,Na:22.99,Mg:24.305,Al:26.982,Si:28.085,P:30.974,S:32.06,Cl:35.45,Ar:39.948,K:39.098,Ca:40.078,Sc:44.956,Ti:47.867,V:50.942,Cr:51.996,Mn:54.938,Fe:55.845,Co:58.933,Ni:58.693,Cu:63.546,Zn:65.38,Ga:69.723,Ge:72.63,As:74.922,Se:78.971,Br:79.904,Kr:83.798,Rb:85.468,Sr:87.62,Y:88.906,Zr:91.224,Nb:92.906,Mo:95.95,Tc:98,Ru:101.07,Rh:102.91,Pd:106.42,Ag:107.87,Cd:112.41,In:114.82,Sn:118.71,Sb:121.76,Te:127.6,I:126.9,Xe:131.29,Cs:132.91,Ba:137.33,La:138.91,Ce:140.12,Pr:140.91,Nd:144.24,Pm:145,Sm:150.36,Eu:151.96,Gd:157.25,Tb:158.93,Dy:162.5,Ho:164.93,Er:167.26,Tm:168.93,Yb:173.05,Lu:174.97,Hf:178.49,Ta:180.95,W:183.84,Re:186.21,Os:190.23,Ir:192.22,Pt:195.08,Au:196.97,Hg:200.59,Tl:204.38,Pb:207.2,Bi:208.98,Po:209,At:210,Rn:222,Fr:223,Ra:226,Ac:227,Th:232.04,Pa:231.04,U:238.03};

  function parseGroup(s) {
    const stack = [{}]; let i = 0;
    const num = () => { const j = i; while (i < s.length && /\d/.test(s[i])) i++; return i > j ? parseInt(s.slice(j, i), 10) : 1; };
    while (i < s.length) {
      const c = s[i];
      if ('([{'.includes(c)) { stack.push({}); i++; }
      else if (')]}'.includes(c)) {
        if (stack.length < 2) throw err('Parênteses desbalanceados');
        i++; const n = num(); const g = stack.pop(); const top = stack[stack.length - 1];
        for (const k in g) top[k] = (top[k] || 0) + g[k] * n;
      } else if (/[A-Z]/.test(c)) {
        let sym = c; i++;
        if (i < s.length && /[a-z]/.test(s[i])) { sym += s[i]; i++; }
        if (!(sym in W)) throw err('Elemento desconhecido: ' + sym);
        const n = num(); const top = stack[stack.length - 1]; top[sym] = (top[sym] || 0) + n;
      } else throw err('Caractere inválido: ' + c);
    }
    if (stack.length !== 1) throw err('Parênteses desbalanceados');
    return stack[0];
  }

  function molarMass(formula) {
    const s = String(formula).replace(/\s+/g, '');
    if (!s) throw err('Digite uma fórmula');
    const total = {};
    for (const part of s.split(/[·.*•]/)) {
      const m = part.match(/^(\d+)?(.+)$/);
      if (!m) throw err('Fórmula inválida');
      const coef = m[1] ? parseInt(m[1], 10) : 1;
      const g = parseGroup(m[2]);
      for (const k in g) total[k] = (total[k] || 0) + g[k] * coef;
    }
    const mass = Object.keys(total).reduce((a, k) => a + W[k] * total[k], 0);
    const parts = Object.keys(total).map((el) => ({ el, n: total[el], mass: W[el] * total[el], pct: (W[el] * total[el] * 100) / mass }));
    return { formula: s, mass, parts };
  }

  const CONSTS = [
    { sym: 'NA', name: 'Constante de Avogadro (mol⁻¹)', v: '6.02214076E23' },
    { sym: 'R', name: 'Constante dos gases (J/mol·K)', v: '8.314462618' },
    { sym: 'R(atm)', name: 'Constante dos gases (L·atm/mol·K)', v: '0.082057366' },
    { sym: 'F', name: 'Constante de Faraday (C/mol)', v: '96485.33212' },
    { sym: 'kB', name: 'Constante de Boltzmann (J/K)', v: '1.380649E-23' },
    { sym: 'h', name: 'Constante de Planck (J·s)', v: '6.62607015E-34' },
    { sym: 'c', name: 'Velocidade da luz (m/s)', v: '299792458' },
    { sym: 'qe', name: 'Carga elementar (C)', v: '1.602176634E-19' },
    { sym: 'Vm', name: 'Volume molar CNTP, 0 °C / 1 atm (L/mol)', v: '22.414' },
    { sym: 'Kw', name: 'Produto iônico da água a 25 °C', v: '1E-14' },
  ];

  const api = { molarMass, CONSTS, WEIGHTS: W };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.Chem = api;
})(typeof window !== 'undefined' ? window : globalThis);
