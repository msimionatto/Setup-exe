/* AllCalculadora - motor de cálculo (parser próprio, sem eval) */
(function (root) {
  'use strict';
  const err = (m) => Object.assign(new Error(m), { user: true });
  const PI = Math.PI;
  const NORM = { '-': '−', '*': '×', '/': '÷' };
  const own = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
  const NAMES = ['sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'sinh', 'cosh', 'tanh', 'asinh', 'acosh', 'atanh', 'ln', 'log', 'sqrt', 'cbrt', 'abs', 'exp', 'floor', 'ceil', 'round', 'pH', 'hconc', 'e', 'pi', 'mod', 'nPr', 'nCr', 'Ans', 'E'];

  const fact = (n) => {
    if (!Number.isInteger(n) || n < 0) throw err('Fatorial exige inteiro ≥ 0');
    if (n > 170) throw err('Resultado muito grande');
    let r = 1; for (let i = 2; i <= n; i++) r *= i; return r;
  };
  const chkNR = (n, r) => {
    if (!Number.isInteger(n) || !Number.isInteger(r) || n < 0 || r < 0 || r > n) throw err('nPr/nCr exige inteiros 0 ≤ r ≤ n');
  };
  const perm = (n, r) => { chkNR(n, r); let x = 1; for (let i = 0; i < r; i++) x *= n - i; return x; };
  const comb = (n, r) => { chkNR(n, r); r = Math.min(r, n - r); let x = 1; for (let i = 1; i <= r; i++) x = (x * (n - r + i)) / i; return Math.round(x); };
  const wrap = (b) => BigInt.asIntN(64, b); // modo programador: inteiros de 64 bits, exatos

  function tokenize(src, prog, base) {
    const s = src.replace(/\s+/g, ''); const out = []; let i = 0;
    const numRe = prog ? /^[0-9A-Fa-f]+/ : /^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/;
    while (i < s.length) {
      const r = s.slice(i); let m;
      if ((m = r.match(numRe))) {
        if (prog) {
          if (![...m[0]].every((c) => parseInt(c, 16) < base)) throw err('Dígito inválido para a base ' + base);
          let n = 0n; const bb = BigInt(base);
          for (const c of m[0]) n = n * bb + BigInt(parseInt(c, 16));
          out.push({ t: 'n', v: wrap(n) });
        } else out.push({ t: 'n', v: parseFloat(m[0]) });
      } else if (prog && (m = r.match(/^(<<|>>)/))) out.push({ t: 'op', v: m[1] });
      else if (!prog && (m = r.match(/^[A-Za-z]+/))) out.push({ t: 'id', v: m[0] });
      else if (!prog && r[0] === 'π') { m = ['π']; out.push({ t: 'id', v: 'π' }); }
      else if ((m = r.match(/^[+\-−×÷*/^!%()√|&~]/))) out.push({ t: 'op', v: NORM[m[0]] || m[0] });
      else throw err('Caractere inválido: ' + r[0]);
      i += m[0].length;
    }
    return out;
  }

  // compile: analisa a expressão uma vez e devolve run(vars) — usado pelos gráficos
  function compile(src, o = {}) {
    const prog = !!o.prog, base = o.base || 10, ang = o.angle || 'DEG';
    const tk = tokenize(src, prog, base);
    if (!tk.length) throw err('Expressão vazia');
    let depth = 0;
    for (const t of tk) if (t.t === 'op') { if (t.v === '(') depth++; else if (t.v === ')') depth--; }
    if (depth < 0) throw err('Parênteses desbalanceados');
    while (depth-- > 0) tk.push({ t: 'op', v: ')' });

    const toRad = (x) => (ang === 'DEG' ? (x * PI) / 180 : ang === 'GRAD' ? (x * PI) / 200 : x);
    const fromRad = (x) => (ang === 'DEG' ? (x * 180) / PI : ang === 'GRAD' ? (x * 200) / PI : x);
    const dom = (c) => { if (!c) throw err('Entrada fora do domínio'); };
    const snap = (r) => (Math.abs(r) < 1e-15 ? 0 : r);
    const FN = {
      sin: (x) => snap(Math.sin(toRad(x))), cos: (x) => snap(Math.cos(toRad(x))),
      tan: (x) => { const r = toRad(x); dom(Math.abs(Math.cos(r)) > 1e-12); return snap(Math.tan(r)); },
      asin: (x) => { dom(Math.abs(x) <= 1); return fromRad(Math.asin(x)); },
      acos: (x) => { dom(Math.abs(x) <= 1); return fromRad(Math.acos(x)); },
      atan: (x) => fromRad(Math.atan(x)),
      sinh: Math.sinh, cosh: Math.cosh, tanh: Math.tanh, asinh: Math.asinh,
      acosh: (x) => { dom(x >= 1); return Math.acosh(x); }, atanh: (x) => { dom(Math.abs(x) < 1); return Math.atanh(x); },
      ln: (x) => { dom(x > 0); return Math.log(x); }, log: (x) => { dom(x > 0); return Math.log10(x); },
      sqrt: (x) => { dom(x >= 0); return Math.sqrt(x); }, cbrt: Math.cbrt, abs: Math.abs, exp: Math.exp,
      floor: Math.floor, ceil: Math.ceil, round: Math.round,
      pH: (x) => { dom(x > 0); return -Math.log10(x); }, hconc: (x) => Math.pow(10, -x),
    };
    const CONST = { 'π': PI, pi: PI, e: Math.E };
    const zero = (b) => { if (Number(b) === 0) throw err('Divisão por zero'); };
    const sh = (b) => { if (b < 0n || b > 63n) throw err('Deslocamento deve estar entre 0 e 63'); return b; };
    const BIN = prog
      ? { '+': (a, b) => wrap(a + b), '−': (a, b) => wrap(a - b), '×': (a, b) => wrap(a * b),
          '÷': (a, b) => { zero(b); return wrap(a / b); }, '%': (a, b) => { zero(b); return a % b; },
          '|': (a, b) => a | b, '^': (a, b) => a ^ b, '&': (a, b) => a & b,
          '<<': (a, b) => wrap(a << sh(b)), '>>': (a, b) => a >> sh(b) }
      : { '+': (a, b) => a + b, '−': (a, b) => a - b, '×': (a, b) => a * b,
          '÷': (a, b) => { zero(b); return a / b; }, mod: (a, b) => { zero(b); return a % b; }, nPr: perm, nCr: comb };
    const levels = prog
      ? [['|'], ['^'], ['&'], ['<<', '>>'], ['+', '−'], ['×', '÷', '%']]
      : [['+', '−'], ['×', '÷', 'mod', 'nPr', 'nCr']];

    let p = 0; let vars = o.vars || {};
    const isOp = (v) => tk[p] && tk[p].t === 'op' && tk[p].v === v;
    const startsPrimary = () => {
      const t = tk[p]; if (!t) return false;
      if (t.t === 'n') return true;
      if (t.t === 'id') return !['mod', 'nPr', 'nCr'].includes(t.v);
      return t.v === '(' || t.v === '√';
    };
    const close = () => { if (!isOp(')')) throw err('Parêntese ausente'); p++; };

    function level(l) {
      if (l === levels.length) return unary();
      let v = level(l + 1);
      for (;;) {
        const t = tk[p];
        if (t && t.t !== 'n' && levels[l].includes(t.v)) {
          p++; const start = p; let b = level(l + 1);
          if (!prog && (t.v === '+' || t.v === '−') && p - start === 2 && tk[p - 1].v === '%') b = v * b; // 200+10% = 220
          v = BIN[t.v](v, b);
        } else if (!prog && l === levels.length - 1 && startsPrimary()) v = v * level(l + 1);
        else return v;
      }
    }
    function unary() {
      if (isOp('−')) { p++; const v = -unary(); return prog ? wrap(v) : v; }
      if (isOp('+')) { p++; return unary(); }
      if (prog && isOp('~')) { p++; return wrap(~unary()); }
      return power();
    }
    function power() {
      const v = postfix();
      if (!prog && isOp('^')) { p++; return Math.pow(v, unary()); }
      return v;
    }
    function postfix() {
      let v = primary();
      while (!prog) {
        if (isOp('!')) { p++; v = fact(v); } else if (isOp('%')) { p++; v /= 100; } else break;
      }
      return v;
    }
    function primary() {
      const t = tk[p++];
      if (!t) throw err('Expressão incompleta');
      if (t.t === 'n') return t.v;
      if (t.t === 'op' && t.v === '(') { const v = level(0); close(); return v; }
      if (t.t === 'op' && t.v === '√') return FN.sqrt(postfix());
      if (t.t === 'id') {
        if (t.v === 'Ans') return o.ans || 0;
        if (own(CONST, t.v)) return CONST[t.v];
        if (own(vars, t.v)) return vars[t.v];
        if (!own(FN, t.v)) throw err('Variável ou função desconhecida: ' + t.v);
        if (!isOp('(')) throw err('Use ' + t.v + '( )');
        p++; const a = level(0); close(); return FN[t.v](a);
      }
      throw err('Expressão inválida');
    }

    return function run(extra) {
      vars = extra ? Object.assign({}, o.vars, extra) : (o.vars || {});
      p = 0; let v;
      try { v = level(0); } catch (e) { if (e instanceof RangeError || e instanceof SyntaxError) throw err('Operação inválida'); throw e; }
      if (p < tk.length) throw err('Expressão inválida');
      if (prog) return v;
      if (Number.isNaN(v)) throw err('Resultado indefinido');
      if (!Number.isFinite(v)) throw err('Resultado muito grande');
      return Number(v.toPrecision(14));
    };
  }
  const evaluate = (src, o = {}) => compile(src, o)();

  function format(v, o = {}) {
    if (typeof v === 'bigint') return v.toString(o.base || 10).toUpperCase();
    if (!Number.isFinite(v)) return 'Erro';
    if (o.prog) return Math.trunc(v).toString(o.base || 10).toUpperCase();
    const a = Math.abs(v);
    const dec = o.dec === undefined || o.dec === null || o.dec === 'auto' ? null : Number(o.dec);
    if (dec !== null && Number.isInteger(dec) && a < 1e15) return v.toFixed(dec);
    if (v === 0) return '0';
    if (a >= 1e15 || a < 1e-6) return v.toExponential(10).replace(/\.?0+e/, 'e').replace('e+', 'E').replace('e', 'E');
    return String(Number(v.toPrecision(14)));
  }
  // complemento de dois (64 bits) para exibir negativos em HEX/OCT/BIN
  function toBase(v, b) {
    const n = typeof v === 'bigint' ? v : BigInt(Math.trunc(v));
    return (b === 10 ? n : BigInt.asUintN(64, n)).toString(b).toUpperCase();
  }
  // formato brasileiro (exibição): 1234.5 -> 1.234,5
  function pretty(s, o = {}) {
    const group = o.group !== false;
    return String(s).replace(/\d+(?:\.\d*)?(?:E[+-]?\d+)?|\.\d+/g, (m) => {
      const [mant, exp] = m.split('E'); const [i, d] = mant.split('.');
      const ig = group ? i.replace(/\B(?=(\d{3})+(?!\d))/g, '.') : i;
      return ig + (d !== undefined ? ',' + d : '') + (exp !== undefined ? 'E' + exp : '');
    });
  }

  const api = { evaluate, compile, format, toBase, pretty, NAMES };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.Engine = api;
})(typeof window !== 'undefined' ? window : globalThis);
