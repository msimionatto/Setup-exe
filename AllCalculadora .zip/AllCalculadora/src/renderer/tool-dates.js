/* AllCalculadora - Datas e horas */
(function (root) {
  'use strict';
  const { define, F, uerr } = root.Tools;
  const DAY = 864e5; const pad = (n) => String(n).padStart(2, '0');
  const WD = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
  const parse = (s) => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || ''); if (!m) throw uerr('Data inválida.'); return Date.UTC(+m[1], +m[2] - 1, +m[3]); };
  const parts = (t) => { const d = new Date(t); return { y: d.getUTCFullYear(), m: d.getUTCMonth() + 1, d: d.getUTCDate() }; };
  const fd = (t) => { const p = parts(t); return `${pad(p.d)}/${pad(p.m)}/${p.y}`; };
  const fdw = (t) => `${fd(t)} (${WD[new Date(t).getUTCDay()]})`;
  const dim = (y, m) => new Date(Date.UTC(y, m, 0)).getUTCDate();
  const today = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
  const addMonths = (t, n) => { const p = parts(t); const idx = p.y * 12 + (p.m - 1) + n; const y = Math.floor(idx / 12), m = idx % 12 + 1; return Date.UTC(y, m - 1, Math.min(p.d, dim(y, m))); };
  function easter(y) {
    const a = y % 19, b = Math.floor(y / 100), c = y % 100, d = Math.floor(b / 4), e = b % 4, f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3);
    const h = (19 * a + b - d - g + 15) % 30, i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451);
    const month = Math.floor((h + l - 7 * m + 114) / 31), day = ((h + l - 7 * m + 114) % 31) + 1;
    return Date.UTC(y, month - 1, day);
  }
  const hcache = {};
  function holidays(y) {
    if (hcache[y]) return hcache[y];
    const s = new Set([[1, 1], [4, 21], [5, 1], [9, 7], [10, 12], [11, 2], [11, 15], [12, 25]].map(([m, d]) => Date.UTC(y, m - 1, d)));
    if (y >= 2024) s.add(Date.UTC(y, 10, 20)); s.add(easter(y) - 2 * DAY);
    return (hcache[y] = s);
  }
  const isBiz = (t, hol) => { const w = new Date(t).getUTCDay(); return w !== 0 && w !== 6 && !(hol && holidays(parts(t).y).has(t)); };
  function addBiz(t, n, hol) { const s = n < 0 ? -1 : 1; let left = Math.abs(n); while (left > 0) { t += s * DAY; if (isBiz(t, hol)) left--; } return t; }
  function countBiz(a, b, hol) { let c = 0; for (let t = a; t <= b; t += DAY) if (isBiz(t, hol)) c++; return c; }
  function ymd(a, b) { // a <= b
    let months = (parts(b).y - parts(a).y) * 12 + parts(b).m - parts(a).m;
    if (addMonths(a, months) > b) months--;
    return { y: Math.floor(months / 12), m: months % 12, d: Math.round((b - addMonths(a, months)) / DAY), months };
  }
  const R = (k, label, raw, fmt, main) => ({ k, label, raw, fmt, main });
  const ymdText = (r) => `${r.y} ano${r.y === 1 ? '' : 's'}, ${r.m} ${r.m === 1 ? 'mês' : 'meses'} e ${r.d} dia${r.d === 1 ? '' : 's'}`;
  const hm = (min) => `${pad(Math.floor(min / 60))}:${pad(Math.round(min % 60))}`;
  const tmin = (s) => { const m = /^(\d{1,2}):(\d{2})$/.exec(s || ''); if (!m) throw uerr('Horário inválido.'); return +m[1] * 60 + +m[2]; };

  const sections = [
    { id: 'diff', name: 'Entre datas',
      learn: 'Mostra a diferença em anos, meses e dias <b>de calendário</b>, o total de dias e quantos <b>dias úteis</b> (seg–sex) existem no intervalo, contando início e fim. Marque a opção para descontar feriados nacionais (incluindo Sexta-feira Santa).',
      fields: [
        { k: 'd1', label: 'Data inicial', type: 'date', def: today }, { k: 'd2', label: 'Data final', type: 'date', def: () => { const d = new Date(); d.setDate(d.getDate() + 30); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; } },
        { k: 'hol', label: 'Descontar feriados nacionais nos dias úteis', type: 'check', def: true },
      ],
      calc(v) {
        let a = parse(v.d1), b = parse(v.d2); let swapped = false; if (a > b) { [a, b] = [b, a]; swapped = true; }
        const r = ymd(a, b); const days = Math.round((b - a) / DAY);
        return { results: [{ k: 'ymd', label: 'Diferença', text: ymdText(r), main: true }, R('days', 'Total de dias', days, F.int), { k: 'weeks', label: 'Semanas', text: `${Math.floor(days / 7)} sem. e ${days % 7} d` }, R('biz', 'Dias úteis (inclui início e fim)', countBiz(a, b, v.hol), F.int), R('hours', 'Horas', days * 24, F.int)],
          note: swapped ? 'As datas estavam invertidas; usamos a mais antiga como início.' : undefined,
          steps: [`De <code>${fdw(a)}</code> a <code>${fdw(b)}</code>.`, `Meses completos: <code>${r.months}</code>; dias restantes: <code>${r.d}</code>.`, `Total de dias = diferença em milissegundos ÷ 86.400.000 = <code>${days}</code>.`] };
      } },
    { id: 'add', name: 'Somar/subtrair',
      learn: 'Some ou subtraia dias, semanas, meses, anos ou <b>dias úteis</b> de uma data. Ao somar meses, se o dia não existir (ex.: 31 em fevereiro) usamos o último dia do mês.',
      fields: [
        { k: 'd', label: 'Data de partida', type: 'date', def: today },
        { k: 'op', label: 'Operação', type: 'select', options: [['+', 'Somar'], ['-', 'Subtrair']], def: '+' },
        { k: 'n', label: 'Quantidade', type: 'number', def: '10' },
        { k: 'u', label: 'Unidade', type: 'select', options: [['d', 'dias'], ['bd', 'dias úteis'], ['w', 'semanas'], ['m', 'meses'], ['y', 'anos']], def: 'd' },
        { k: 'hol', label: 'Considerar feriados nacionais (dias úteis)', type: 'check', def: true, show: (r) => r.u === 'bd' },
      ],
      calc(v) {
        const t = parse(v.d); const n = Math.trunc(v.n) * (v.op === '-' ? -1 : 1); let r;
        if (v.u === 'd') r = t + n * DAY; else if (v.u === 'w') r = t + n * 7 * DAY; else if (v.u === 'bd') r = addBiz(t, n, v.hol); else if (v.u === 'm') r = addMonths(t, n); else r = addMonths(t, n * 12);
        return { results: [{ k: 'res', label: 'Data resultante', text: fdw(r), main: true }, R('diff', 'Dias de diferença', Math.round((r - t) / DAY), F.int)], steps: [`Partindo de <code>${fdw(t)}</code>, ${v.op === '-' ? 'subtraímos' : 'somamos'} ${Math.abs(n)} ${v.u === 'bd' ? 'dias úteis (pulando fins de semana' + (v.hol ? ' e feriados' : '') + ')' : { d: 'dia(s)', w: 'semana(s)', m: 'mês(es)', y: 'ano(s)' }[v.u]}.`] };
      } },
    { id: 'age', name: 'Idade',
      learn: 'Calcula a idade exata e quanto falta para o próximo aniversário. A data de referência é hoje, mas você pode mudar.',
      fields: [{ k: 'b', label: 'Data de nascimento', type: 'date', def: '2000-01-01' }, { k: 'r', label: 'Data de referência', type: 'date', def: today }],
      calc(v) {
        const b = parse(v.b), r = parse(v.r); if (b > r) throw uerr('O nascimento deve ser anterior à data de referência.');
        const a = ymd(b, r); let nb = addMonths(b, 12 * (parts(r).y - parts(b).y)); if (nb < r) nb = addMonths(b, 12 * (parts(r).y - parts(b).y + 1));
        const days = Math.round((r - b) / DAY);
        return { results: [{ k: 'age', label: 'Idade', text: ymdText(a), main: true }, R('days', 'Dias vividos', days, F.int), R('months', 'Meses completos', a.months, F.int), { k: 'next', label: 'Próximo aniversário', text: `${fdw(nb)} · em ${Math.round((nb - r) / DAY)} dia(s)` }],
          steps: [`Meses completos entre as datas: <code>${a.months}</code> (${a.y} anos e ${a.m} meses).`, `Dias que sobram depois dos meses completos: <code>${a.d}</code>.`] };
      } },
    { id: 'hours', name: 'Horas trabalhadas',
      learn: 'Informe entrada, saída e intervalo. Se a saída for menor que a entrada, entendemos que o turno passou da meia-noite. O resultado também sai em <b>horas decimais</b> (ex.: 7h30 = 7,5) para cálculo de pagamento.',
      fields: [{ k: 'in', label: 'Entrada', type: 'time', def: '08:00' }, { k: 'out', label: 'Saída', type: 'time', def: '17:30' },
        { k: 'brk', label: 'Intervalo (minutos)', type: 'number', def: '60', zero: true }, { k: 'days', label: 'Quantidade de dias', type: 'number', def: '1', zero: true },
        { k: 'rate', label: 'Valor da hora (opcional)', type: 'number', pre: 'R$', opt: true, def: '' }],
      calc(v) {
        let m = tmin(v.out) - tmin(v.in); if (m <= 0) m += 1440; m -= v.brk; if (m < 0) throw uerr('O intervalo é maior que o turno.');
        const nd = v.days || 1; const tot = m * nd; const res = [{ k: 'day', label: 'Por dia', text: hm(m) + ' h', main: true }, { k: 'tot', label: `Total (${nd} dia${nd === 1 ? '' : 's'})`, text: `${Math.floor(tot / 60)}h${pad(Math.round(tot % 60))}` }, R('dec', 'Horas decimais (total)', tot / 60, (x) => F.num(x, 2))];
        if (!Number.isNaN(v.rate)) res.push(R('pay', 'Valor a receber', (tot / 60) * v.rate, F.money));
        return { results: res, steps: [`Turno: <code>${v.in}</code> → <code>${v.out}</code> menos <code>${v.brk} min</code> de intervalo = <code>${hm(m)}</code>.`, `Em decimal: <code>${F.num(m / 60, 2)} h</code>.`] };
      } },
  ];
  define({ id: 'dates', name: 'Datas e horas', glyph: '31', desc: 'Diferença entre datas, dias úteis, idade e horas', sections, util: { easter, holidays, addBiz, countBiz, ymd, addMonths, parse, fd } });
})(typeof window !== 'undefined' ? window : globalThis);
