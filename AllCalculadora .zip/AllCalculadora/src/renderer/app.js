/* AllCalculadora - interface principal */
(() => {
  'use strict';
  const $ = (s) => document.querySelector(s);
  const { evaluate, format, toBase, pretty } = window.Engine;
  const Chem = window.Chem, Tools = window.Tools;
  const api = window.lilas || {};
  const KEY = 'allcalc.v2';
  const esc = Tools.esc;

  const CALC = [
    { id: 'normal', name: 'Normal', glyph: '÷', desc: 'Operações do dia a dia, porcentagem e memória' },
    { id: 'scientific', name: 'Científica', glyph: 'π', desc: 'Trigonometria, logaritmos, potências e fatorial' },
    { id: 'chemistry', name: 'Química', glyph: 'H₂O', desc: 'Massa molar, mol, pH e constantes' },
    { id: 'programmer', name: 'Programador', glyph: '</>', desc: 'HEX, DEC, OCT, BIN e operações de bits' },
  ];
  const allModes = () => [...CALC, ...Tools.list().map((t) => ({ id: t.id, name: t.name, glyph: t.glyph, desc: t.desc }))];
  const meta = (id) => allModes().find((m) => m.id === id);
  const MODE_NAME = new Proxy({}, { get: (_, k) => (meta(k) || {}).name });
  const FIT = { normal: [380, 620], scientific: [480, 780], chemistry: [520, 840], programmer: [480, 780], graph: [560, 780], _tool: [480, 720] };
  const THEMES = [['lilas-dark', 'Lilás Escuro', '#0d0817', '#9b6bff'], ['lilas-light', 'Lilás Claro', '#f4effc', '#8b4cf0'], ['midnight', 'Meia-noite', '#060c1a', '#3b82f6'], ['graphite', 'Grafite', '#111113', '#7a6cff'], ['emerald', 'Esmeralda', '#06120e', '#10b981']];

  /* ---------- estado ---------- */
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(KEY)) || {}; } catch (_) {}
  const S = {
    mode: saved.mode, angle: saved.angle || 'DEG', inv: false, expr: '', res: '', done: false, mem: saved.mem || 0, ans: saved.ans || 0, base: 10,
    hist: saved.hist || [], trash: saved.trash || [], vars: saved.vars || [], panel: false, tab: 'hist', pin: false,
    cfg: Object.assign({ theme: 'lilas-dark', br: true, dec: 'auto', anim: !(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches), sound: false, gshort: false, tour: false }, saved.cfg),
  };
  if (!meta(S.mode)) S.mode = 'normal';
  if (S.mode === 'programmer') S.ans = BigInt(Math.trunc(Number(S.ans) || 0)); // programador usa inteiros de 64 bits
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify({ mode: S.mode, angle: S.angle, mem: S.mem, ans: Number(S.ans), hist: S.hist, trash: S.trash, vars: S.vars, cfg: S.cfg })); } catch (_) {} };

  const prog = () => S.mode === 'programmer';
  const varMap = () => { const m = {}; for (const it of S.vars) if (it.kind === 'var') { try { m[it.name] = evaluate(it.expr, { angle: S.angle, vars: { ...m } }); } catch (_) {} } return m; };
  const opts = () => ({ angle: S.angle, prog: prog(), base: S.base, ans: S.ans, vars: prog() ? {} : varMap() });
  const fmt = (v) => format(v, { prog: prog(), base: S.base, dec: S.cfg.dec });
  const fmtExpr = (v) => format(v, { prog: prog(), base: S.base }).replace(/^-/, '−');
  const P = (s) => (S.cfg.br && !prog() ? pretty(s) : s);
  const tryEval = () => { try { return evaluate(S.expr, opts()); } catch (_) { return null; } };
  const val = () => (S.done || !S.expr ? S.ans : (tryEval() ?? S.ans));
  const anim = () => S.cfg.anim;

  /* ---------- teclados ---------- */
  const TIPS = { 'floor(': 'Arredonda para baixo (⌊3,7⌋ = 3)', 'ceil(': 'Arredonda para cima (⌈3,2⌉ = 4)', 'round(': 'Arredonda para o inteiro mais próximo', 'sin(': 'Seno do ângulo', 'cos(': 'Cosseno do ângulo', 'tan(': 'Tangente do ângulo', 'asin(': 'Arco-seno (inverso do seno)', 'acos(': 'Arco-cosseno', 'atan(': 'Arco-tangente', 'sinh(': 'Seno hiperbólico', 'cosh(': 'Cosseno hiperbólico', 'tanh(': 'Tangente hiperbólica', 'asinh(': 'Inverso do seno hiperbólico', 'acosh(': 'Inverso do cosseno hiperbólico', 'atanh(': 'Inverso da tangente hiperbólica', 'ln(': 'Logaritmo natural (base e)', 'log(': 'Logaritmo base 10', 'exp(': 'e elevado a x', '10^(': '10 elevado a x', '^2': 'Elevar ao quadrado', '^3': 'Elevar ao cubo', 'cbrt(': 'Raiz cúbica', '^': 'x elevado a y', '√(': 'Raiz quadrada', '^(−1)': 'Inverso (1/x)', '!': 'Fatorial: 5! = 5·4·3·2·1', 'abs(': 'Valor absoluto (módulo)', ' mod ': 'Resto da divisão', 'E': 'Notação científica: 2E3 = 2000', 'Ans': 'Último resultado', ' nPr ': 'Permutações: n!/(n−r)!', ' nCr ': 'Combinações: n!/(r!(n−r)!)', 'π': 'Pi ≈ 3,14159', 'e': 'Número de Euler ≈ 2,71828', 'pH(': 'pH = −log[H⁺]', 'hconc(': '[H⁺] = 10⁻ᵖᴴ', '%': 'Porcentagem (200+10% = 220)', '&': 'E bit a bit', '|': 'OU bit a bit', '~': 'NÃO bit a bit', '<<': 'Desloca bits à esquerda', '>>': 'Desloca bits à direita', mc: 'Limpar memória', mr: 'Recuperar memória', mp: 'Somar à memória', mm: 'Subtrair da memória', ms: 'Guardar na memória', inv: 'Funções inversas', ce: 'Limpar o número atual', clear: 'Limpar tudo (Esc)', back: 'Apagar (Backspace)', neg: 'Trocar sinal', eq: 'Calcular (Enter)' };
  const B = (l, v, c = '') => ({ l, v, c, k: 'i' });
  const A = (l, v, c = '') => ({ l, v, c, k: 'a' });
  const N = (n) => B(n, n, 'num');
  const memRow = [A('MC', 'mc', 'fn'), A('MR', 'mr', 'fn'), A('M+', 'mp', 'fn'), A('M−', 'mm', 'fn'), A('MS', 'ms', 'fn')];
  const basicRows = (sci) => [
    [B('%', '%', 'fn'), A('CE', 'ce', 'fn'), A('C', 'clear', 'fn'), A('⌫', 'back', 'fn')],
    sci ? [B('⌊x⌋', 'floor(', 'fn'), B('⌈x⌉', 'ceil(', 'fn'), B('round', 'round(', 'fn'), B('÷', '÷', 'op')] // sem repetir x², √ e 1/x da área científica
        : [B('1/x', '^(−1)', 'fn'), B('x²', '^2', 'fn'), B('√', '√(', 'fn'), B('÷', '÷', 'op')],
    [N('7'), N('8'), N('9'), B('×', '×', 'op')], [N('4'), N('5'), N('6'), B('−', '−', 'op')], [N('1'), N('2'), N('3'), B('+', '+', 'op')],
    [A('±', 'neg', 'fn'), N('0'), B('.', '.', 'num'), A('=', 'eq', 'eq')],
  ];
  const sciRows = (inv) => [
    [A('INV', 'inv', inv ? 'on' : 'fn'), B('π', 'π', 'fn'), B('e', 'e', 'fn'), B('(', '(', 'fn'), B(')', ')', 'fn')],
    [B(inv ? 'sin⁻¹' : 'sin', inv ? 'asin(' : 'sin(', 'fn'), B(inv ? 'cos⁻¹' : 'cos', inv ? 'acos(' : 'cos(', 'fn'), B(inv ? 'tan⁻¹' : 'tan', inv ? 'atan(' : 'tan(', 'fn'), B(inv ? 'eˣ' : 'ln', inv ? 'exp(' : 'ln(', 'fn'), B(inv ? '10ˣ' : 'log', inv ? '10^(' : 'log(', 'fn')],
    [B('x²', '^2', 'fn'), B(inv ? '∛' : 'x³', inv ? 'cbrt(' : '^3', 'fn'), B('xʸ', '^', 'fn'), B('√', '√(', 'fn'), B('1/x', '^(−1)', 'fn')],
    [B('n!', '!', 'fn'), B('|x|', 'abs(', 'fn'), B('mod', ' mod ', 'fn'), B('EXP', 'E', 'fn'), B('Ans', 'Ans', 'fn')],
    [B(inv ? 'sinh⁻¹' : 'sinh', inv ? 'asinh(' : 'sinh(', 'fn'), B(inv ? 'cosh⁻¹' : 'cosh', inv ? 'acosh(' : 'cosh(', 'fn'), B(inv ? 'tanh⁻¹' : 'tanh', inv ? 'atanh(' : 'tanh(', 'fn'), B('nPr', ' nPr ', 'fn'), B('nCr', ' nCr ', 'fn')],
  ];
  const chemRows = [
    [B('(', '(', 'fn'), B(')', ')', 'fn'), B('EXP', 'E', 'fn'), B('xʸ', '^', 'fn'), B('Ans', 'Ans', 'fn')],
    [B('log', 'log(', 'fn'), B('ln', 'ln(', 'fn'), B('pH', 'pH(', 'fn'), B('[H⁺]', 'hconc(', 'fn'), B('π', 'π', 'fn')],
  ];
  const progRows = [
    [B('(', '(', 'fn'), B(')', ')', 'fn'), A('C', 'clear', 'fn'), A('⌫', 'back', 'fn')],
    [N('7'), N('8'), N('9'), B('÷', '÷', 'op')], [N('4'), N('5'), N('6'), B('×', '×', 'op')], [N('1'), N('2'), N('3'), B('−', '−', 'op')],
    [B('mod', '%', 'fn'), N('0'), A('CE', 'ce', 'fn'), B('+', '+', 'op')], [A('±', 'neg', 'fn'), A('=', 'eq', 'eq')],
  ];
  const hexRow = ['A', 'B', 'C', 'D', 'E', 'F'].map((h) => N(h));
  const bitRow = [B('AND', '&', 'op'), B('OR', '|', 'op'), B('XOR', '^', 'op'), B('NOT', '~', 'op'), B('<<', '<<', 'op'), B('>>', '>>', 'op')];

  function buildKeys(enter) {
    const m = S.mode; const blocks = [];
    if (m !== 'programmer') blocks.push({ rows: [memRow], w: 0.6 });
    if (m === 'scientific') blocks.push({ rows: sciRows(S.inv) });
    if (m === 'chemistry') blocks.push({ rows: chemRows });
    if (m === 'programmer') blocks.push({ rows: [hexRow] }, { rows: [bitRow] });
    blocks.push({ rows: m === 'programmer' ? progRows : basicRows(m === 'scientific') });
    const host = $('#keys'); host.innerHTML = ''; let idx = 0;
    for (const b of blocks) {
      const g = document.createElement('div'); g.className = 'grid';
      const cols = Math.max(...b.rows.map((r) => r.length)); g.style.setProperty('--cols', cols); g.style.flex = `${b.w || b.rows.length} 1 0`;
      g.innerHTML = b.rows.map((r) => r.map((btn, i) => {
        const span = r.length < cols && i === r.length - 1 ? `grid-column:span ${cols - r.length + 1};` : '';
        const label = btn.v === '.' ? (S.cfg.br ? ',' : '.') : btn.l;
        return `<button class="key ${btn.c}${enter && anim() ? ' enter' : ''}" style="${span}--i:${idx++}" data-k="${btn.k}" data-v="${esc(btn.v)}" title="${esc(TIPS[btn.v] || '')}">${esc(label)}</button>`;
      }).join('')).join('');
      host.appendChild(g);
    }
    applyBase();
  }
  function applyBase() {
    document.querySelectorAll('#keys .key.num').forEach((b) => {
      const d = parseInt(b.dataset.v, 16);
      b.disabled = prog() ? (Number.isNaN(d) || d >= S.base) : /^[A-F]$/.test(b.dataset.v);
    });
  }

  /* ---------- entrada ---------- */
  const CONT = /^([+−×÷^%!&|]|<<|>>|\s(mod|nPr|nCr)\s)/;
  function press(ins) {
    if (S.done) { S.done = false; S.expr = CONT.test(ins) ? fmtExpr(S.ans) : ''; }
    if (!S.expr && CONT.test(ins) && ins !== '−' && !/^\s(mod|nPr|nCr)/.test(ins)) S.expr = fmtExpr(S.ans);
    if (/^[+−×÷]$/.test(ins) && /[+−×÷]$/.test(S.expr)) {
      if (!(ins === '−' && /[×÷]$/.test(S.expr))) { S.expr = S.expr.slice(0, -1) + ins; return refresh(); }
    }
    if (ins === '.') {
      const tail = (S.expr.match(/[0-9A-F.]+$/) || [''])[0];
      if (tail.includes('.')) return; if (!tail) ins = '0.';
    }
    S.expr += ins; refresh();
  }
  const TOK = /(asinh\(|acosh\(|atanh\(|asin\(|acos\(|atan\(|sinh\(|cosh\(|tanh\(|sin\(|cos\(|tan\(|log\(|ln\(|sqrt\(|cbrt\(|abs\(|exp\(|pH\(|hconc\(|\s(?:mod|nPr|nCr)\s|Ans|<<|>>|.)$/;
  function act(name) {
    switch (name) {
      case 'clear': S.expr = ''; S.res = ''; S.done = false; break;
      case 'ce': if (S.done) { S.expr = ''; S.res = ''; S.done = false; } else if (/[0-9A-F.]$/.test(S.expr)) S.expr = S.expr.replace(/[0-9A-F.]+$/, ''); else S.expr = ''; break;
      case 'back': S.done = false; S.expr = S.expr.replace(TOK, ''); break;
      case 'eq': return equals();
      case 'neg': return neg();
      case 'inv': S.inv = !S.inv; buildKeys(false); break;
      case 'mc': S.mem = 0; save(); break;
      case 'mr': return press(fmtExpr(S.mem));
      case 'mp': S.mem += val(); save(); break;
      case 'mm': S.mem -= val(); save(); break;
      case 'ms': S.mem = val(); save(); break;
    }
    refresh();
  }
  function neg() {
    if (S.done) { S.done = false; S.expr = fmtExpr(-S.ans); S.res = ''; }
    else {
      let m;
      if ((m = S.expr.match(/\(−([0-9A-F.]+(?:E[+-]?\d+)?)\)$/))) S.expr = S.expr.slice(0, -m[0].length) + m[1];
      else if ((m = S.expr.match(/([0-9A-F.]+(?:E[+-]?\d+)?)$/))) S.expr = S.expr.slice(0, -m[1].length) + '(−' + m[1] + ')';
      else if (!S.expr) S.expr = '−';
    }
    refresh();
  }
  const PLAIN = /^[−+]?[0-9A-F.]+(E[+-]?\d+)?$/;
  function equals() {
    if (!S.expr || S.done) return;
    try {
      const v = evaluate(S.expr, opts()); const res = fmt(v);
      if (!PLAIN.test(S.expr)) addHist({ expr: S.expr, res, v, mode: S.mode, base: S.base });
      S.ans = v; S.res = res; S.done = true; save(); draw(true);
    } catch (e) { showError(e.user ? e.message : 'Expressão inválida'); }
  }
  function showError(msg) { const el = $('#res'); el.textContent = msg; el.classList.add('err'); setTimeout(draw, 1700); }
  function refresh() {
    if (!S.done) { const v = S.expr ? tryEval() : null; S.res = v !== null && !PLAIN.test(S.expr) ? fmt(v) : ''; }
    draw();
  }
  function draw(pop) {
    const ex = $('#expr'); ex.innerHTML = colorExpr(P(S.expr)) + (S.done ? ' =' : '<span class="caret"></span>'); ex.scrollLeft = ex.scrollWidth;
    const big = P(S.res || (S.expr.match(/[0-9A-F.]+$/) || ['0'])[0]);
    const el = $('#res'); el.classList.remove('err'); el.style.fontSize = '';
    if (pop === true && anim()) el.innerHTML = [...big].map((c, i) => `<span class="dg" style="--i:${i}">${esc(c)}</span>`).join(''); // dígitos "rolando"
    else el.textContent = big;
    let fs = parseFloat(getComputedStyle(el).fontSize);
    while (el.scrollWidth > el.clientWidth && fs > 14) { fs -= 2; el.style.fontSize = fs + 'px'; }
    if (pop === true && anim()) { el.classList.remove('pop'); void el.offsetWidth; el.classList.add('pop'); }
    const a = $('#bAng'); a.textContent = S.mode === 'scientific' ? S.angle : prog() ? 'BASE ' + S.base : ''; a.disabled = prog();
    $('#bMem').textContent = S.mem !== 0 ? 'M ' + P(format(S.mem)) : '';
    if (prog()) drawBases();
  }
  function drawBases() {
    const v = S.done ? S.ans : (tryEval() ?? 0);
    $('#bases').innerHTML = [[16, 'HEX'], [10, 'DEC'], [8, 'OCT'], [2, 'BIN']].map(([b, n]) => `<button data-base="${b}" class="${S.base === b ? 'on' : ''}" title="Usar base ${n}"><b>${n}</b><span>${esc(toBase(v, b))}</span></button>`).join('');
  }
  function setBase(b) {
    const v = val(); const had = S.expr; S.base = b; S.done = false; S.expr = had ? fmtExpr(v) : ''; S.res = ''; applyBase(); refresh();
  }

  /* ---------- modos ---------- */
  let prevIdx = 0;
  const toolCtx = { api, toast: (m, a) => toast(m, a), vars: () => varMap(), save: (e) => { addHist(e); save(); toast('Salvo no histórico'); } };
  function setMode(m, force) {
    if (m === S.mode && !force) return;
    const wasProg = prog(); S.mode = m;
    if (wasProg || m === 'programmer') { S.expr = ''; S.res = ''; S.done = false; }
    if (wasProg && typeof S.ans === 'bigint') S.ans = Number(S.ans);
    if (m === 'programmer' && typeof S.ans !== 'bigint') S.ans = BigInt(Math.trunc(Number(S.ans) || 0));
    S.base = 10; S.inv = false; renderMode(true); save();
  }
  function renderMode(enter) {
    const m = meta(S.mode); const tool = Tools.get(S.mode);
    $('#modeG').textContent = m.glyph; $('#modeN').textContent = m.name;
    $('#calcView').hidden = !!tool; $('#toolView').hidden = !tool; $('#chem').hidden = S.mode !== 'chemistry'; $('#bases').hidden = !prog();
    const view = tool ? $('#toolView') : $('#calcView');
    const idx = allModes().findIndex((x) => x.id === S.mode);
    if (enter) { view.style.setProperty('--dir', idx >= prevIdx ? 1 : -1); view.style.animation = 'none'; void view.offsetWidth; view.style.animation = ''; }
    prevIdx = idx;
    if (tool) { Tools.F.loc = S.cfg.br ? 'pt-BR' : 'en-US'; Tools.mount(tool, $('#toolView'), toolCtx); }
    else { buildKeys(enter); refresh(); }
    if (api.fit) { const [w, h] = FIT[S.mode] || (tool ? FIT._tool : FIT.normal); api.fit({ w, h }); }
  }
  function openModeMenu() {
    const menu = $('#modeMenu');
    menu.innerHTML = allModes().map((m, i) => `<button class="mcard${m.id === S.mode ? ' on' : ''}" style="--i:${i}" data-mode="${m.id}"><span class="mg">${esc(m.glyph)}</span><span><b>${esc(m.name)}</b><small>${esc(m.desc)}</small></span></button>`).join('');
    closeMenus('modeMenu'); menu.hidden = false; $('#modeBtn').setAttribute('aria-expanded', 'true');
  }
  function closeMenus(except) {
    ['modeMenu', 'expMenu'].forEach((id) => { if (id !== except) $('#' + id).hidden = true; });
    if (except !== 'modeMenu') $('#modeBtn').setAttribute('aria-expanded', 'false');
  }

  /* ---------- histórico / lixeira / variáveis ---------- */
  const time = (ts) => new Date(ts).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  const isCalc = (it) => !Tools.get(it.mode) && it.mode !== 'programmer';
  const disp = (it) => (isCalc(it) && S.cfg.br ? { ex: pretty(it.expr), rs: pretty(it.res) } : { ex: it.expr, rs: it.res });
  function addHist(e) { if (typeof e.v === 'bigint') e = { ...e, v: e.v.toString() }; S.hist.unshift({ id: crypto.randomUUID(), ts: Date.now(), ...e }); S.hist = S.hist.slice(0, 500); renderPanel(); }
  const RESERVED = new Set(window.Engine.NAMES);
  function renderPanel() {
    const tab = S.tab; const hist = tab === 'hist';
    $('#cntH').textContent = S.hist.length; $('#cntT').textContent = S.trash.length; $('#cntV').textContent = S.vars.length; $('#dotTrash').hidden = !S.trash.length;
    ['Hist', 'Trash', 'Vars'].forEach((n) => $('#tab' + n).classList.toggle('on', n.toLowerCase() === tab));
    $('.pfoot').hidden = tab === 'vars';
    if (tab === 'vars') return renderVars();
    const list = hist ? S.hist : S.trash;
    $('#plist').innerHTML = list.length ? list.map((it) => {
      const d = disp(it);
      return `<div class="item${it.ts > Date.now() - 1500 ? ' new' : ''}" data-id="${it.id}"><div class="ex">${esc(d.ex)}</div><div class="rs">${Tools.get(it.mode) ? '' : '= '}${esc(d.rs)}</div>
        <div class="meta"><span>${esc(MODE_NAME[it.mode] || '')} · ${time(it.ts)}</span><span class="acts">
        ${hist ? '<button class="mini" data-a="expr">Reusar</button><button class="mini" data-a="del">Excluir</button>' : '<button class="mini" data-a="restore">Restaurar</button><button class="mini" data-a="purge">Apagar</button>'}</span></div></div>`;
    }).join('') : `<div class="empty">${hist ? 'Nenhum cálculo ainda.<br>Faça uma conta e pressione =.' : 'A lixeira está vazia.<br>Itens excluídos do histórico aparecem aqui e podem ser restaurados.'}</div>`;
    const bulk = $('#pbulk'); bulk.textContent = hist ? 'Mover tudo para a lixeira' : 'Esvaziar lixeira'; bulk.disabled = !list.length;
  }
  function renderVars() {
    const vm = varMap();
    const vars = S.vars.filter((x) => x.kind === 'var'), fx = S.vars.filter((x) => x.kind === 'fx');
    const li = (it, extra) => `<div class="item" data-id="${it.id}"><div class="ex">${esc(it.name)}${extra}</div><div class="rs">${esc(P(it.expr))}</div><div class="meta"><span></span><span class="acts"><button class="mini" data-va="ins">Inserir</button><button class="mini" data-va="del">Excluir</button></span></div></div>`;
    $('#plist').innerHTML = `<div class="vform"><b>Variáveis</b><small>Guarde valores e use o nome nas contas. Ex.: <code>preco*1,12</code></small>
      <div class="vrow"><input id="vN" placeholder="nome" maxlength="16"><span>=</span><input id="vV" placeholder="valor ou conta"><button class="mini" data-va="addvar">+</button></div>
      ${vars.map((it) => li(it, ` = ${esc(P(format(vm[it.name] ?? NaN)))}`)).join('') || '<small>Nenhuma variável ainda.</small>'}</div>
      <div class="vform"><b>Fórmulas salvas</b><small>Salve uma conta pronta e insira com um clique. Ex.: <code>preco*(1+imposto/100)</code></small>
      <div class="vrow"><input id="fN" placeholder="nome" maxlength="24"><input id="fE" placeholder="expressão"><button class="mini" data-va="addfx">+</button></div>
      <button class="mini" data-va="usecur" style="margin-bottom:8px">Usar a conta do visor</button>
      ${fx.map((it) => li(it, '')).join('') || '<small>Nenhuma fórmula ainda.</small>'}</div>`;
  }
  function togglePanel(tab) {
    const same = S.panel && (!tab || tab === S.tab);
    S.panel = !same; if (tab) S.tab = tab;
    $('#panel').classList.toggle('show', S.panel); $('#scrim').classList.toggle('show', S.panel); renderPanel();
  }
  function insertValue(it) {
    S.done = false; const raw = it.v;
    if (prog()) press(fmtExpr(raw !== undefined && /^-?\d+$/.test(String(raw)) ? BigInt(String(raw)) : 0n));
    else press(fmtExpr(raw !== undefined && !Number.isNaN(Number(raw)) ? Number(raw) : parseFloat(it.res) || 0));
  }
  $('#plist').addEventListener('click', (e) => {
    const va = e.target.closest('[data-va]');
    if (va) return varAction(va.dataset.va, e.target.closest('.item'));
    const row = e.target.closest('.item'); if (!row || S.tab === 'vars') return;
    const id = row.dataset.id; const a = e.target.closest('[data-a]')?.dataset.a;
    const from = S.tab === 'hist' ? S.hist : S.trash; const it = from.find((x) => x.id === id); if (!it) return;
    const done = () => { save(); renderPanel(); };
    if (a === 'del') return fly(row, '#btnTrash', () => { S.hist = S.hist.filter((x) => x !== it); S.trash.unshift(it); S.trash = S.trash.slice(0, 300); bump('#btnTrash'); done(); });
    if (a === 'restore') return fly(row, '#btnHist', () => { S.trash = S.trash.filter((x) => x !== it); S.hist.unshift(it); toast('Item restaurado'); bump('#btnHist'); done(); });
    if (a === 'purge') return collapse(row, () => { S.trash = S.trash.filter((x) => x !== it); done(); });
    if (a === 'expr') {
      if (Tools.get(it.mode)) { Tools.restore(it.mode, it.data); S.mode === it.mode ? renderMode(true) : setMode(it.mode); }
      else { setMode(it.mode); if (it.base) { S.base = it.base; applyBase(); } S.done = false; S.expr = it.expr; refresh(); }
      if (innerWidth < 760) togglePanel();
    } else if (S.tab === 'hist' && !Tools.get(it.mode)) { insertValue(it); if (innerWidth < 760) togglePanel(); }
    done();
  });
  function varAction(a, row) {
    const id = row && row.dataset.id; const it = S.vars.find((x) => x.id === id);
    if (a === 'ins' && it) { if (Tools.get(S.mode)) setMode('normal'); press(it.kind === 'var' ? it.name : it.expr); if (innerWidth < 760) togglePanel(); return; }
    if (a === 'del' && it) { S.vars = S.vars.filter((x) => x !== it); save(); return renderPanel(); }
    if (a === 'usecur') { if (!S.expr) return toast('O visor está vazio'); $('#fE').value = S.expr; return $('#fN').focus(); }
    const dot = (s) => s.trim().replace(/,/g, '.');
    if (a === 'addvar') {
      const name = $('#vN').value.trim(), ex = dot($('#vV').value);
      if (!/^[A-Za-z]+$/.test(name)) return toast('O nome deve ter só letras (sem números ou espaços)');
      if (RESERVED.has(name)) return toast(`"${name}" é reservado (função ou constante)`);
      try { evaluate(ex, { angle: S.angle, vars: varMap() }); } catch (e) { return toast('Valor inválido: ' + (e.user ? e.message : 'confira a conta')); }
      S.vars = S.vars.filter((x) => !(x.kind === 'var' && x.name === name)); S.vars.push({ id: crypto.randomUUID(), kind: 'var', name, expr: ex });
      save(); renderPanel(); refresh(); toast(`Variável ${name} salva`);
    } else if (a === 'addfx') {
      const name = $('#fN').value.trim(), ex = dot($('#fE').value);
      if (!name || !ex) return toast('Informe o nome e a expressão');
      S.vars.push({ id: crypto.randomUUID(), kind: 'fx', name, expr: ex }); save(); renderPanel(); toast('Fórmula salva');
    }
  }
  $('#pbulk').addEventListener('click', () => {
    if (S.tab === 'hist') { S.trash = [...S.hist, ...S.trash].slice(0, 300); S.hist = []; toast('Histórico movido para a lixeira'); }
    else if (confirm('Apagar definitivamente todos os itens da lixeira?')) S.trash = [];
    save(); renderPanel();
  });

  /* ---------- química ---------- */
  let cm = 0, cf = '';
  function initChem() {
    const host = $('#chem');
    host.innerHTML = `
      <div class="row"><input id="cF" placeholder="Fórmula: Ca(OH)2, CuSO4·5H2O" spellcheck="false" autocomplete="off" title="Digite uma fórmula química; use ( ) e · para hidratos"></div>
      <div class="row"><span class="m" id="cM">Massa molar: —</span><button class="mini" id="cUse" title="Insere a massa molar na conta">Inserir M</button><button class="mini" id="cSave">Salvar</button></div>
      <div class="comp" id="cComp"></div>
      <div class="row" style="margin-top:8px"><input id="cG" placeholder="massa (g)" inputmode="decimal"><input id="cN" placeholder="mols" inputmode="decimal"><input id="cP" placeholder="partículas" inputmode="decimal"></div>
      <div class="consts">${Chem.CONSTS.map((c) => `<button class="chip" data-v="${c.v}" title="${esc(c.name)}">${esc(c.sym)}</button>`).join('')}</div>`;
    const num = (id) => parseFloat(String($(id).value).replace(',', '.'));
    const NA = 6.02214076e23; const put = (id, v) => { $(id).value = Number.isFinite(v) ? format(v) : ''; };
    const conv = (from) => {
      if (!cm) return; const x = num('#c' + from); const n = from === 'G' ? x / cm : from === 'N' ? x : x / NA;
      if (!Number.isFinite(n)) return;
      if (from !== 'G') put('#cG', n * cm); if (from !== 'N') put('#cN', n); if (from !== 'P') put('#cP', n * NA);
    };
    $('#cF').addEventListener('input', () => {
      const out = $('#cM'); cf = $('#cF').value;
      try {
        const r = Chem.molarMass(cf); cm = r.mass; out.className = 'm'; out.textContent = `M = ${P(r.mass.toFixed(3))} g/mol`;
        $('#cComp').innerHTML = r.parts.map((p) => `<div><span>${esc(p.el)}${p.n > 1 ? '<sub>' + p.n + '</sub>' : ''}</span><span class="bar2"><i style="width:${p.pct.toFixed(1)}%"></i></span><em>${P(p.pct.toFixed(1))}%</em></div>`).join('');
        if ($('#cG').value) conv('G');
      } catch (e) { cm = 0; out.className = 'm bad'; out.textContent = cf.trim() ? e.message : 'Massa molar: —'; $('#cComp').innerHTML = ''; }
    });
    ['G', 'N', 'P'].forEach((k) => $('#c' + k).addEventListener('input', () => conv(k)));
    $('#cUse').addEventListener('click', () => { if (cm) press(String(Number(cm.toFixed(4)))); });
    $('#cSave').addEventListener('click', () => { if (cm) { addHist({ expr: `M(${cf.replace(/\s+/g, '')})`, res: `${cm.toFixed(3)} g/mol`, v: cm, mode: 'chemistry', base: 10 }); save(); toast('Massa molar salva no histórico'); } });
    host.addEventListener('click', (e) => { const c = e.target.closest('.chip'); if (c) press(c.dataset.v); });
  }

  /* ---------- toast / exportar / copiar ---------- */
  let toastT;
  function toast(msg, action) {
    const t = $('#toast'); const okk = /^(Copiad|Salv|Item restaur|Vari[áa]vel .* salva|Fórmula salva|Arquivo salvo|Conta salva|Massa molar salva|Resultados? copiado)/.test(msg);
    t.innerHTML = (okk ? '<svg class="tick" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7" pathLength="1"/></svg>' : '') + `<span>${esc(msg)}</span>`;
    if (action) { const b = document.createElement('button'); b.textContent = action.label; b.onclick = action.fn; t.appendChild(b); }
    t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), action ? 7000 : 2300);
  }
  const stampNow = () => { const d = new Date(); const p = (n) => String(n).padStart(2, '0'); return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`; };
  function payload() {
    const rows = S.hist.slice().reverse().map((h) => { const d = disp(h); return { ts: h.ts, mode: MODE_NAME[h.mode] || '', expr: d.ex, res: Tools.get(h.mode) ? d.rs : '= ' + d.rs }; });
    const cur = !Tools.get(S.mode) && S.expr ? { expr: P(S.expr), res: P(S.res) } : null;
    return { rows, current: cur, modeName: MODE_NAME[S.mode], angle: S.mode === 'scientific' ? S.angle : '', stamp: stampNow() };
  }
  async function exportCalc(kind) {
    closeMenus();
    if (!api.exportCalc) return toast('Exportação disponível apenas no app desktop');
    const p = payload();
    if (!p.rows.length && !p.current) return toast('Faça alguns cálculos antes de exportar');
    document.body.classList.add('capturing');
    try {
      let r;
      if (kind === 'txt') {
        const L = ['AllCalculadora', '='.repeat(44), `Data: ${new Date().toLocaleString('pt-BR')}`, `Modo: ${p.modeName}${p.angle ? ' (' + p.angle + ')' : ''}`, ''];
        if (p.current) L.push('CÁLCULO ATUAL', `  ${p.current.expr}${p.current.res ? ' = ' + p.current.res : ''}`, '');
        if (S.mode === 'chemistry' && cm) L.push('QUÍMICA', `  M(${cf}) = ${P(cm.toFixed(3))} g/mol`, '');
        L.push(`HISTÓRICO (${p.rows.length})`); p.rows.forEach((h) => L.push(`  [${time(h.ts)}] ${h.mode}: ${h.expr} ${h.res}`));
        if (!p.rows.length) L.push('  (vazio)'); L.push('', '-'.repeat(44), 'Desenvolvido por Marcos Simionatto');
        r = await api.exportCalc({ text: L.join('\r\n'), baseName: `AllCalculadora_conta_${p.stamp}` });
        if (r && r.ok) toast('Conta salva (.txt + .png)', { label: 'Mostrar na pasta', fn: () => api.showInFolder(r.txt) });
      } else {
        r = await api.exportFile({ kind, payload: p });
        if (r && r.ok) toast(kind === 'tape' ? 'Enviado para impressão' : 'Arquivo salvo', r.file ? { label: 'Mostrar na pasta', fn: () => api.showInFolder(r.file) } : undefined);
        else if (r && r.error) toast('Não foi possível gerar o arquivo');
      }
    } catch (_) { toast('Não foi possível salvar o arquivo'); }
    document.body.classList.remove('capturing');
  }
  async function copyResult() {
    let t = S.res || (S.expr.match(/[0-9A-F.]+$/) || [''])[0]; if (!t) return;
    if (S.cfg.br && !prog()) t = pretty(t, { group: false });
    try { await navigator.clipboard.writeText(t); toast('Copiado: ' + t); } catch (_) { toast('Não foi possível copiar'); }
  }

  /* ---------- configurações, ajuda e tutorial ---------- */
  function applyTheme() {
    document.body.dataset.theme = S.cfg.theme; document.body.dataset.anim = S.cfg.anim ? 'on' : 'off';
    const cs = getComputedStyle(document.body);
    if (api.setTheme) api.setTheme({ color: cs.getPropertyValue('--bg').trim(), symbol: cs.getPropertyValue('--lilac').trim() });
  }
  function openSettings() {
    const c = S.cfg; const sw = (k) => `<button class="sw${c[k] ? ' on' : ''}" data-tog="${k}" role="switch" aria-checked="${!!c[k]}"></button>`;
    $('#modal').innerHTML = `<div class="mbox" role="dialog" aria-label="Configurações"><div class="mhead"><h3>Configurações</h3><button class="icon" data-close aria-label="Fechar">✕</button></div>
      <h4>Aparência</h4><div class="themes">${THEMES.map(([id, n, a, b]) => `<button class="theme${c.theme === id ? ' on' : ''}" data-theme-set="${id}"><i style="background:linear-gradient(135deg,${a} 50%,${b} 50%)"></i>${n}</button>`).join('')}</div>
      <div class="set"><span>Animações<small>Efeitos de entrada, brilho e contagem de valores (respeita a opção "reduzir animações" do Windows)</small></span>${sw('anim')}</div>
      <div class="set"><span>Som das teclas<small>Um clique discreto ao digitar</small></span>${sw('sound')}</div>
      <h4>Números</h4>
      <div class="set"><span>Formato brasileiro<small>1.234,56 (milhar com ponto, decimal com vírgula)</small></span>${sw('br')}</div>
      <div class="set"><span>Casas decimais<small>Aplica ao resultado da calculadora</small></span><select data-dec>${['auto', 0, 1, 2, 3, 4, 5, 6, 8, 10].map((d) => `<option value="${d}"${String(c.dec) === String(d) ? ' selected' : ''}>${d === 'auto' ? 'Automático' : d}</option>`).join('')}</select></div>
      <h4>Sistema</h4>
      <div class="set"><span>Atalho global Ctrl+Alt+L<small>Mostra ou esconde a calculadora de qualquer lugar</small></span>${sw('gshort')}</div>
      <div class="set"><span>Tutorial guiado<small>Reveja o passeio pelos recursos</small></span><button class="mini" data-tour>Rever</button></div>
      <div class="set"><span>Central de atualizações<small>Verificação automática, canal e progresso do download</small></span><button class="mini" data-open-upd>Abrir</button></div>
      <div class="set"><span>Sobre o AllCalculadora<small>Versão, licença, privacidade e novidades</small></span><button class="mini" data-open-about>Abrir</button></div>
      <h4>Atalhos de teclado</h4>
      <div class="kbd"><kbd>Enter</kbd><span>Calcular</span><kbd>Esc</kbd><span>Limpar tudo</span><kbd>Backspace / Del</kbd><span>Apagar / limpar número</span><kbd>Ctrl+H</kbd><span>Histórico</span><kbd>Ctrl+S</kbd><span>Baixar conta</span><kbd>Ctrl+C</kbd><span>Copiar resultado</span><kbd>P</kbd><span>Insere π</span><kbd>Duplo clique (gráfico)</kbd><span>Reinicia a visão</span></div>
      <h4>Dicas</h4><div class="kbd" style="grid-template-columns:1fr"><span>• Passe o mouse sobre as teclas para ver o que cada uma faz.</span><span>• Em cada ferramenta, abra <b>Como funciona</b> para aprender a fórmula e <b>Passo a passo</b> para ver a conta.</span><span>• Salve variáveis (ex.: <code>preco</code>) na aba <b>Variáveis</b> do painel lateral e use nas contas.</span></div></div>`;
    $('#modal').hidden = false;
  }
  const closeModal = () => { $('#modal').hidden = true; };
  $('#modal').addEventListener('click', async (e) => {
    if (e.target.id === 'modal' || e.target.closest('[data-close]')) return closeModal();
    const th = e.target.closest('[data-theme-set]');
    if (th) {
      const apply = () => { S.cfg.theme = th.dataset.themeSet; applyTheme(); save(); openSettings(); };
      if (document.startViewTransition && anim()) { const r = th.getBoundingClientRect(); document.documentElement.style.setProperty('--tx', r.left + r.width / 2 + 'px'); document.documentElement.style.setProperty('--ty', r.top + r.height / 2 + 'px'); document.startViewTransition(apply); } else apply();
      return;
    }
    const tg = e.target.closest('[data-tog]');
    if (tg) {
      const k = tg.dataset.tog; S.cfg[k] = !S.cfg[k]; save();
      if (k === 'anim') applyTheme();
      if (k === 'br') { refresh(); renderPanel(); buildKeys(false); if (Tools.get(S.mode)) renderMode(false); }
      if (k === 'gshort' && api.setShortcut) { const ok = await api.setShortcut(S.cfg.gshort); if (!ok && S.cfg.gshort) { S.cfg.gshort = false; save(); toast('Não foi possível registrar o atalho'); } }
      return openSettings();
    }
    if (e.target.closest('[data-tour]')) { closeModal(); return startTour(); }
    if (e.target.closest('[data-open-upd]')) return window.LilasUpdates && window.LilasUpdates.open();
    if (e.target.closest('[data-open-about]')) return window.LilasUpdates && window.LilasUpdates.about();
  });
  $('#modal').addEventListener('change', (e) => { if (e.target.matches('[data-dec]')) { S.cfg.dec = e.target.value === 'auto' ? 'auto' : Number(e.target.value); save(); refresh(); } });

  const TOUR = [
    { sel: '#modeBtn', t: 'Escolha o modo', p: 'Aqui você alterna entre 11 calculadoras: Normal, Científica, Química, Programador, Financeira, Conversor, Moedas, Datas, Comercial, Gráficos e Matemática.' },
    { sel: '#display', t: 'Visor inteligente', p: 'Mostra a conta e o resultado em tempo real, antes mesmo de apertar =. Se algo estiver errado, ele explica o motivo.' },
    { sel: '#keys', t: 'Teclado', p: 'Funciona com o mouse e com o teclado do computador. Passe o mouse sobre uma tecla para ver o que ela faz.' },
    { sel: '#btnHist', t: 'Histórico e variáveis', p: 'Todos os cálculos ficam salvos. Clique para reutilizar. Na aba Variáveis você guarda valores e fórmulas para usar nas contas.' },
    { sel: '#btnTrash', t: 'Lixeira', p: 'O que você exclui do histórico vai para cá e pode ser restaurado quando quiser.' },
    { sel: '#btnExport', t: 'Baixar conta', p: 'Salve a conta em texto + print da tela, PDF, Excel ou imprima no formato de fita.' },
    { sel: '#btnSettings', t: 'Configurações', p: 'Troque o tema, ative o formato brasileiro, ajuste as casas decimais e consulte a ajuda. Pronto para começar!' },
  ];
  function startTour() {
    if (Tools.get(S.mode)) setMode('normal');
    if (S.panel) togglePanel(); closeMenus();
    const host = $('#tour'); host.hidden = false; host.innerHTML = '<div class="spot"></div><div class="tip"></div>'; let i = 0;
    const end = () => { host.hidden = true; host.innerHTML = ''; S.cfg.tour = true; save(); };
    const show = () => {
      const s = TOUR[i]; const r = $(s.sel).getBoundingClientRect(); const spot = host.querySelector('.spot'); const tip = host.querySelector('.tip');
      Object.assign(spot.style, { left: r.left - 6 + 'px', top: r.top - 6 + 'px', width: r.width + 12 + 'px', height: r.height + 12 + 'px' });
      tip.innerHTML = `<h5>${s.t}</h5><p>${s.p}</p><div class="tf"><div class="dots">${TOUR.map((_, k) => `<i class="${k === i ? 'on' : ''}"></i>`).join('')}</div>${i ? '<button class="mini" data-b>Voltar</button>' : '<button class="mini" data-s>Pular</button>'}<button class="mini" data-n style="background:var(--lilac2);color:#fff;border-color:transparent">${i === TOUR.length - 1 ? 'Concluir' : 'Próximo'}</button></div>`;
      const th = tip.getBoundingClientRect().height; const below = r.bottom + th + 18 < innerHeight;
      tip.style.top = Math.max(8, below ? r.bottom + 14 : r.top - th - 14) + 'px'; tip.style.left = Math.min(Math.max(12, r.left), innerWidth - tip.offsetWidth - 12) + 'px';
    };
    host.onclick = (e) => { if (e.target.closest('[data-n]')) { if (++i >= TOUR.length) return end(); show(); } else if (e.target.closest('[data-b]')) { i--; show(); } else if (e.target.closest('[data-s]')) end(); };
    show();
  }

  /* ---------- efeitos visuais ---------- */
  function colorExpr(s) { // operadores, funções e parênteses coloridos
    let depth = 0;
    return s.replace(/([A-Za-z]+)(?=\()|(<<|>>|[+−×÷^%!&|~√])|(\()|(\))|([\s\S])/g, (m, fn, op, o, c, ch) => {
      if (fn) return `<span class="t-f">${esc(fn)}</span>`;
      if (op) return `<span class="t-o">${esc(op)}</span>`;
      if (o) return `<span class="t-p${depth++ % 3}">(</span>`;
      if (c) return `<span class="t-p${Math.max(0, --depth) % 3}">)</span>`;
      return esc(ch);
    });
  }
  function collapse(row, cb) { if (!anim()) return cb(); row.style.maxHeight = row.offsetHeight + 'px'; void row.offsetWidth; row.classList.add('gone'); setTimeout(cb, 340); }
  function fly(row, target, cb) { // o item "voa" até o ícone de destino
    if (!anim()) return cb();
    const r = row.getBoundingClientRect(), t = $(target).getBoundingClientRect(); const g = row.cloneNode(true);
    g.className = 'item ghost fly'; Object.assign(g.style, { left: r.left + 'px', top: r.top + 'px', width: r.width + 'px' });
    g.style.setProperty('--dx', t.left + t.width / 2 - (r.left + r.width / 2) + 'px'); g.style.setProperty('--dy', t.top + t.height / 2 - (r.top + r.height / 2) + 'px');
    document.body.appendChild(g); row.style.maxHeight = row.offsetHeight + 'px'; void row.offsetWidth; row.classList.add('gone');
    setTimeout(() => { g.remove(); cb(); }, 470);
  }
  function bump(sel) { const b = $(sel); b.classList.remove('bump'); void b.offsetWidth; b.classList.add('bump'); setTimeout(() => b.classList.remove('bump'), 700); }
  let actx;
  function tick() {
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)(); const o = actx.createOscillator(), g = actx.createGain();
      o.frequency.value = 880; g.gain.value = 0.04; o.connect(g); g.connect(actx.destination); o.start(); g.gain.exponentialRampToValueAtTime(0.0001, actx.currentTime + 0.04); o.stop(actx.currentTime + 0.05);
    } catch (_) { /* sem áudio */ }
  }
  const hideBroken = (img) => { const h = () => { img.style.display = 'none'; }; img.addEventListener('error', h); if (img.complete && img.naturalWidth === 0) h(); };

  /* ---------- eventos ---------- */
  $('#keys').addEventListener('click', (e) => {
    const b = e.target.closest('.key'); if (!b) return;
    if (anim()) { const r = b.getBoundingClientRect(); b.style.setProperty('--rx', e.clientX - r.left + 'px'); b.style.setProperty('--ry', e.clientY - r.top + 'px'); b.classList.remove('rip'); void b.offsetWidth; b.classList.add('rip'); }
    if (S.cfg.sound) tick();
    (b.dataset.k === 'i' ? press : act)(b.dataset.v);
  });
  $('#modeBtn').addEventListener('click', (e) => { e.stopPropagation(); $('#modeMenu').hidden ? openModeMenu() : closeMenus(); });
  $('#modeMenu').addEventListener('click', (e) => { const c = e.target.closest('[data-mode]'); if (c) { closeMenus(); setMode(c.dataset.mode); } });
  $('#btnExport').addEventListener('click', (e) => { e.stopPropagation(); const m = $('#expMenu'); const open = m.hidden; closeMenus(); m.hidden = !open; });
  $('#expMenu').addEventListener('click', (e) => { const b = e.target.closest('[data-exp]'); if (b) exportCalc(b.dataset.exp); });
  document.addEventListener('click', (e) => { if (!e.target.closest('.menu') && !e.target.closest('#modeBtn') && !e.target.closest('#btnExport')) closeMenus(); });
  $('#bases').addEventListener('click', (e) => { const t = e.target.closest('[data-base]'); if (t) setBase(+t.dataset.base); });
  $('#bAng').addEventListener('click', () => { S.angle = { DEG: 'RAD', RAD: 'GRAD', GRAD: 'DEG' }[S.angle]; save(); refresh(); });
  $('#btnHist').addEventListener('click', () => togglePanel('hist'));
  $('#btnTrash').addEventListener('click', () => togglePanel('trash'));
  $('#tabHist').addEventListener('click', () => { S.tab = 'hist'; renderPanel(); });
  $('#tabTrash').addEventListener('click', () => { S.tab = 'trash'; renderPanel(); });
  $('#tabVars').addEventListener('click', () => { S.tab = 'vars'; renderPanel(); });
  $('#pclose').addEventListener('click', () => togglePanel());
  $('#scrim').addEventListener('click', () => togglePanel());
  $('#btnCopy').addEventListener('click', copyResult);
  $('#btnSettings').addEventListener('click', openSettings);
  $('#btnPin').addEventListener('click', async () => {
    if (!api.togglePin) return; S.pin = await api.togglePin(!S.pin);
    $('#btnPin').classList.toggle('on', S.pin); toast(S.pin ? 'Sempre no topo: ativado' : 'Sempre no topo: desativado');
  });
  hideBroken($('#logo'));
  window.addEventListener('resize', () => { if (!Tools.get(S.mode)) draw(); });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { if (!$('#tour').hidden) { $('#tour').hidden = true; S.cfg.tour = true; save(); return; } if (!$('#modal').hidden) return closeModal(); if (!$('#modeMenu').hidden || !$('#expMenu').hidden) return closeMenus(); }
    if (e.target.matches && e.target.matches('input,textarea,select')) return;
    if (e.ctrlKey || e.metaKey) {
      const k = e.key.toLowerCase();
      if (k === 'h') { e.preventDefault(); togglePanel('hist'); } else if (k === 's') { e.preventDefault(); exportCalc('txt'); }
      else if (k === 'c' && !String(getSelection()) && !Tools.get(S.mode)) { e.preventDefault(); copyResult(); }
      return;
    }
    if (Tools.get(S.mode) || !$('#modal').hidden || !$('#tour').hidden) return;
    const k = e.key; let handled = true;
    if (/^[0-9]$/.test(k) || (prog() && /^[a-fA-F]$/.test(k))) { if (!prog() || parseInt(k, 16) < S.base) press(k.toUpperCase()); }
    else if (k === '+') press('+'); else if (k === '-') press('−'); else if (k === '*' || k === 'x') press('×'); else if (k === '/') press('÷');
    else if (k === '.' || k === ',') press('.'); else if (k === '(' || k === ')') press(k);
    else if (k === '^') press('^'); else if (k === '!' && !prog()) press('!'); else if (k === '%') press('%');
    else if (prog() && '&|~'.includes(k)) press(k); else if ((k === 'p' || k === 'P') && !prog()) press('π');
    else if (k === 'Enter' || k === '=') equals(); else if (k === 'Backspace') act('back'); else if (k === 'Escape') act('clear'); else if (k === 'Delete') act('ce');
    else handled = false;
    if (handled) e.preventDefault();
  });

  $('#yr').textContent = new Date().getFullYear();
  applyTheme(); Tools.F.loc = S.cfg.br ? 'pt-BR' : 'en-US';
  initChem(); renderMode(false); renderPanel();
  if (S.cfg.gshort && api.setShortcut) api.setShortcut(true);
  const sp = $('#splash');
  if (sp) { hideBroken($('#splashLogo')); if (anim()) setTimeout(() => { sp.classList.add('out'); setTimeout(() => sp.remove(), 650); }, 1000); else sp.remove(); }
  if (!S.cfg.tour) setTimeout(startTour, anim() ? 1700 : 600);
  window.LilasUI = { toast, esc, openModal: (html) => { $('#modal').innerHTML = html; $('#modal').hidden = false; } }; // usado por updates.js
})();
