const { contextBridge, ipcRenderer } = require('electron');
const call = (ch) => (...a) => ipcRenderer.invoke(ch, ...a);
contextBridge.exposeInMainWorld('lilas', {
  exportCalc: call('export:save'),
  exportFile: call('export:file'),
  getRates: call('rates:get'),
  togglePin: call('win:pin'),
  setTheme: call('theme:set'),
  setShortcut: call('shortcut:set'),
  fit: (size) => ipcRenderer.send('win:fit', size),
  showInFolder: (file) => ipcRenderer.send('shell:show', file),
  version: call('app:version'),
  appInfo: call('app:info'),
  whatsNew: call('app:whatsnew'),
  ackWhatsNew: call('app:whatsnew-ack'),
  openLogs: call('logs:open'),
  openLink: call('link:open'),
  upd: {
    state: call('upd:state'), settings: call('upd:settings'), setSettings: call('upd:set'),
    check: call('upd:check'), download: call('upd:download'), install: call('upd:install'), skip: call('upd:skip'),
    onStatus: (cb) => ipcRenderer.on('upd:status', (_e, s) => cb(s)),
  },
});
