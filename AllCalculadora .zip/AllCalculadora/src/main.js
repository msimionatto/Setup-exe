const { app, BrowserWindow, ipcMain, dialog, shell, Menu, globalShortcut, net, session } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { reportHTML, buildXlsx } = require('./export');
const sec = require('./security');
const { createStore } = require('./store');
const { createLogger } = require('./logger');
const { createUpdateCenter } = require('./updater');
const { section } = require('./changelog');

const IMG = path.join(__dirname, '..', 'imagens');
const ICON = path.join(IMG, process.platform === 'win32' ? 'Logo.ico' : 'Logo.png');
const LOGO = path.join(IMG, 'Logo.png');
const ACCEL = 'CommandOrControl+Alt+L';
let mainWin = null;
let center = null; let logger = null; let store = null; let pendingWhatsNew = false;
const LINKS = { // únicos endereços externos que o app abre
  releases: 'https://github.com/msimionatto/CalculadoraLilasDark/releases/latest',
  issues: 'https://github.com/msimionatto/CalculadoraLilasDark/issues/new',
  repo: 'https://github.com/msimionatto/CalculadoraLilasDark',
};
const exported = new Set(); // caminhos gerados pelo app (únicos que podem ser revelados no Explorer)

const handle = (ch, fn) => ipcMain.handle(ch, (e, ...a) => { if (!sec.isTrusted(e, mainWin)) throw new Error('Origem não confiável'); return fn(e, ...a); });
const on = (ch, fn) => ipcMain.on(ch, (e, ...a) => { if (sec.isTrusted(e, mainWin)) fn(e, ...a); });

function createWindow() {
  const win = new BrowserWindow({
    width: 420, height: 720, minWidth: 340, minHeight: 560,
    title: 'AllCalculadora', backgroundColor: '#0d0817',
    icon: fs.existsSync(ICON) ? ICON : undefined, show: false,
    titleBarStyle: 'hidden', titleBarOverlay: { color: '#0d0817', symbolColor: '#d9c2ff', height: 40 },
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, webviewTag: false },
  });
  mainWin = win;
  win.once('ready-to-show', () => win.show());
  win.on('closed', () => { mainWin = null; });
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}

/* ---------- exportação ---------- */
handle('export:save', async (e, args) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const text = sec.cleanText(args && args.text); const base = sec.safeName(args && args.baseName);
  const image = await win.webContents.capturePage();
  const { canceled, filePath } = await dialog.showSaveDialog(win, {
    title: 'Baixar conta', defaultPath: path.join(app.getPath('documents'), `${base}.txt`), filters: [{ name: 'Texto', extensions: ['txt'] }],
  });
  if (canceled || !filePath) return { ok: false };
  const txt = filePath.toLowerCase().endsWith('.txt') ? filePath : filePath + '.txt';
  const png = txt.replace(/\.txt$/i, '.png');
  fs.writeFileSync(txt, '\ufeff' + text, 'utf8'); fs.writeFileSync(png, image.toPNG());
  exported.add(path.resolve(txt)); exported.add(path.resolve(png));
  return { ok: true, txt, png };
});

async function withHidden(html, fn) {
  const tmp = path.join(os.tmpdir(), `allcalc-${Date.now()}.html`);
  fs.writeFileSync(tmp, html, 'utf8');
  const w = new BrowserWindow({ show: false, webPreferences: { sandbox: true, javascript: false } });
  try { await w.loadFile(tmp); return await fn(w); } finally { w.destroy(); fs.unlink(tmp, () => {}); }
}

handle('export:file', async (e, args) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  try {
    const kind = sec.cleanKind(args && args.kind); if (!kind) return { ok: false, error: 'tipo inválido' };
    const payload = sec.cleanPayload(args.payload);
    if (kind === 'tape') {
      await withHidden(reportHTML(payload, { tape: true, logo: LOGO }), (w) => new Promise((res) => w.webContents.print({ silent: false, printBackground: true }, (ok) => res(ok))));
      return { ok: true };
    }
    const ext = kind === 'pdf' ? 'pdf' : 'xlsx';
    const { canceled, filePath } = await dialog.showSaveDialog(win, {
      title: kind === 'pdf' ? 'Salvar relatório em PDF' : 'Salvar planilha Excel',
      defaultPath: path.join(app.getPath('documents'), `AllCalculadora_historico_${payload.stamp}.${ext}`),
      filters: [{ name: kind === 'pdf' ? 'PDF' : 'Excel', extensions: [ext] }],
    });
    if (canceled || !filePath) return { ok: false };
    const file = filePath.toLowerCase().endsWith('.' + ext) ? filePath : `${filePath}.${ext}`;
    if (kind === 'pdf') {
      const buf = await withHidden(reportHTML(payload, { logo: LOGO }), (w) => w.webContents.printToPDF({ pageSize: 'A4', printBackground: true, margins: { top: 0.5, bottom: 0.8, left: 0.5, right: 0.5 } }));
      fs.writeFileSync(file, buf);
    } else await buildXlsx(payload, file, LOGO);
    exported.add(path.resolve(file));
    return { ok: true, file };
  } catch (err) { if (logger) logger.error('Falha na exportação:', err); return { ok: false, error: String(err && err.message) }; }
});

/* ---------- janela e sistema ---------- */
handle('win:pin', (e, flag) => { const w = BrowserWindow.fromWebContents(e.sender); w.setAlwaysOnTop(flag === true, 'floating'); return w.isAlwaysOnTop(); });
on('win:fit', (e, size) => { // só cresce; nunca reduz o que o usuário ajustou
  const win = BrowserWindow.fromWebContents(e.sender); if (!win || win.isMaximized() || win.isFullScreen()) return;
  const { w, h } = sec.clampSize(size && size.w, size && size.h); const [cw, ch] = win.getSize();
  if (cw < w || ch < h) win.setSize(Math.max(cw, w), Math.max(ch, h), true);
});
on('shell:show', (_e, file) => { if (typeof file === 'string' && exported.has(path.resolve(file))) shell.showItemInFolder(file); });
handle('theme:set', (e, t) => {
  if (!t || !sec.validColor(t.color) || !sec.validColor(t.symbol)) return;
  const w = BrowserWindow.fromWebContents(e.sender); if (!w) return;
  try { w.setBackgroundColor(t.color); if (w.setTitleBarOverlay) w.setTitleBarOverlay({ color: t.color, symbolColor: t.symbol, height: 40 }); } catch (_) { /* plataforma sem suporte */ }
});
handle('shortcut:set', (_e, flag) => {
  globalShortcut.unregister(ACCEL);
  if (flag !== true) return true;
  return globalShortcut.register(ACCEL, () => { const w = mainWin; if (!w) return; if (w.isVisible() && w.isFocused()) w.hide(); else { if (w.isMinimized()) w.restore(); w.show(); w.focus(); } });
});
handle('app:version', () => app.getVersion());

// cotações (feito no processo principal: sem CORS e sem abrir a CSP da página)
handle('rates:get', async () => {
  for (const url of ['https://open.er-api.com/v6/latest/USD', 'https://api.exchangerate-api.com/v4/latest/USD']) {
    try {
      const r = await net.fetch(url, { signal: AbortSignal.timeout(8000) }); if (!r.ok) continue;
      const j = await r.json(); if (j && j.rates && j.rates.BRL) return { ok: true, rates: j.rates, ts: Date.now() };
    } catch (_) { /* tenta a próxima fonte */ }
  }
  return { ok: false };
});

/* ---------- início, logs e configurações ---------- */
function boot() {
  const dir = app.getPath('userData');
  logger = createLogger(path.join(dir, 'logs'));
  store = createStore(path.join(dir, 'settings.json'), { autoCheck: true, channel: 'stable', skipped: '', lastRun: '' });
  logger.info(`AllCalculadora ${app.getVersion()} | Electron ${process.versions.electron} | ${process.platform} ${process.arch} | instalado=${app.isPackaged}`);
  process.on('uncaughtException', (e) => logger.error('uncaughtException', e));
  process.on('unhandledRejection', (e) => logger.error('unhandledRejection', e));
  const prev = store.get().lastRun; store.set({ lastRun: app.getVersion() });
  pendingWhatsNew = !!prev && prev !== app.getVersion(); // mostra "O que mudou" só após atualizar
}

/* ---------- Central de Atualizações (GitHub Releases) ---------- */
function setupUpdates() {
  let updater = null;
  if (app.isPackaged) { try { ({ autoUpdater: updater } = require('electron-updater')); } catch (e) { logger.error('electron-updater indisponível', e); } }
  center = createUpdateCenter({
    updater: updater || new (require('events'))(), version: app.getVersion(), packaged: !!updater && app.isPackaged, store, logger,
    send: (s) => { if (mainWin && !mainWin.isDestroyed()) mainWin.webContents.send('upd:status', s); },
  });
  center.attach(); center.start();
}
const readChangelog = () => { try { return fs.readFileSync(path.join(__dirname, '..', 'CHANGELOG.md'), 'utf8'); } catch (_) { return ''; } };
handle('upd:state', () => center.getState());
handle('upd:settings', () => center.getSettings());
handle('upd:set', (_e, patch) => center.setSettings(patch));
handle('upd:check', () => center.check({ manual: true }));
handle('upd:download', () => center.download());
handle('upd:install', () => center.install());
handle('upd:skip', () => center.skip());
handle('app:info', () => ({ version: app.getVersion(), electron: process.versions.electron, chrome: process.versions.chrome, node: process.versions.node, platform: `${process.platform} ${process.arch}`, packaged: app.isPackaged, logDir: logger && logger.dir }));
handle('app:whatsnew', () => ({ version: app.getVersion(), notes: section(readChangelog(), app.getVersion()), show: pendingWhatsNew }));
handle('app:whatsnew-ack', () => { pendingWhatsNew = false; });
handle('logs:open', () => shell.openPath(logger.dir));
handle('link:open', (_e, key) => { if (Object.prototype.hasOwnProperty.call(LINKS, key)) return shell.openExternal(LINKS[key]); });

if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => { const w = BrowserWindow.getAllWindows()[0]; if (w) { if (w.isMinimized()) w.restore(); w.show(); w.focus(); } });
  app.on('web-contents-created', (_e, c) => { c.on('will-attach-webview', (ev) => ev.preventDefault()); });
  app.whenReady().then(() => {
    session.defaultSession.setPermissionRequestHandler((_w, _p, cb) => cb(false)); // sem câmera, microfone, localização etc.
    Menu.setApplicationMenu(null);
    boot(); setupUpdates(); createWindow();
    app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) createWindow(); });
  });
  app.on('will-quit', () => globalShortcut.unregisterAll());
  app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
}
