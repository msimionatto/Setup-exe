// Configurações do app salvas em arquivo JSON (userData/settings.json), com gravação atômica
const fs = require('fs');
const path = require('path');

function createStore(file, defaults = {}) {
  let data = { ...defaults };
  try { data = { ...defaults, ...JSON.parse(fs.readFileSync(file, 'utf8')) }; } catch (_) { /* primeiro uso ou arquivo ilegível */ }
  return {
    get: () => ({ ...data }),
    set(patch) {
      data = { ...data, ...patch };
      try {
        fs.mkdirSync(path.dirname(file), { recursive: true });
        const tmp = file + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(data, null, 2)); fs.renameSync(tmp, file);
      } catch (_) { /* disco indisponível: mantém em memória */ }
      return { ...data };
    },
  };
}
module.exports = { createStore };
