// Uso: node scripts/release-notes.js v2.2.0        -> imprime as notas daquela versão (do CHANGELOG.md)
//      node scripts/release-notes.js v2.2.0 --check -> falha se a tag não bater com a versão do package.json
//      node scripts/release-notes.js --check        -> confere o CHANGELOG.md com a versão do package.json
const fs = require('fs');
const path = require('path');
const { section } = require('../src/changelog');
const pkg = require('../package.json');

const args = process.argv.slice(2); const check = args.includes('--check');
const tag = (args.find((a) => !a.startsWith('--')) || pkg.version).replace(/^v/, '');
const log = fs.readFileSync(path.join(__dirname, '..', 'CHANGELOG.md'), 'utf8');

if (check) {
  if (tag !== pkg.version) { console.error(`A tag (${tag}) não bate com a versão do package.json (${pkg.version}).`); process.exit(1); }
  if (!section(log, pkg.version)) { console.error(`CHANGELOG.md não tem a seção "## ${pkg.version}".`); process.exit(1); }
  console.log(`ok: versão ${pkg.version} confere com o CHANGELOG.md`);
} else process.stdout.write((section(log, tag) || `Versão ${tag}`) + '\n');
