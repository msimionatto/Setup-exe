// Troca o nome do aplicativo em todo o projeto.  Uso: node scripts/rename-app.js "NovoNome"
// (não mexe no endereço do repositório GitHub nem no histórico do CHANGELOG.md)
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const pkgFile = path.join(root, 'package.json');
const pkg = JSON.parse(fs.readFileSync(pkgFile, 'utf8'));
const next = (process.argv[2] || '').trim();
if (!/^[\p{L}\p{N} ]{2,40}$/u.test(next)) { console.error('Informe o novo nome (2 a 40 letras/números). Ex.: node scripts/rename-app.js "AllCalculadora"'); process.exit(1); }

const oldName = pkg.build.productName; const oldSlug = pkg.name;
const newSlug = next.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
if (oldName === next) { console.log('O nome já é esse.'); process.exit(0); }

const skip = new Set(['.git', 'node_modules', 'dist']);
const files = [];
(function walk(d) { for (const f of fs.readdirSync(d)) { if (skip.has(f)) continue; const p = path.join(d, f); if (fs.statSync(p).isDirectory()) walk(p); else if (/\.(js|html|css|md|json|yml)$/.test(f) && f !== 'CHANGELOG.md' && f !== 'package-lock.json') files.push(p); } })(root);

let changed = 0;
for (const p of files) {
  const s = fs.readFileSync(p, 'utf8');
  const t = s.split(`br.com.${oldSlug}.app`).join(`br.com.${newSlug}.app`).split(oldName).join(next).split(oldSlug).join(newSlug);
  if (t !== s) { fs.writeFileSync(p, t); changed++; }
}
console.log(`"${oldName}" -> "${next}" (${changed} arquivos). Confira com: git diff --stat`);
