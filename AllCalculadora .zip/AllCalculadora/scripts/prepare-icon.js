// Prepara o ícone do instalador (roda sozinho antes de "npm run dist").
// O electron-builder exige ícone com pelo menos 256x256; se o Logo.ico for menor, ele PARA depois de criar
// a pasta win-unpacked e não gera o instalador. Este script escolhe a melhor fonte e nunca bloqueia o build:
//   1) imagens/Logo.ico (>= 256x256)  2) imagens/Logo.png (>= 256x256, o electron-builder converte)  3) ícone padrão do Electron
const fs = require('fs');
const path = require('path');

function icoMax(buf) {
  if (buf.length < 6 || buf[0] !== 0 || buf[1] !== 0 || buf[2] !== 1 || buf[3] !== 0) return null;
  let max = 0;
  for (let i = 0, n = buf.readUInt16LE(4); i < n; i++) { const o = 6 + i * 16; if (o + 2 > buf.length) break; max = Math.max(max, buf[o] || 256, buf[o + 1] || 256); }
  return max;
}
function pngSize(buf) {
  if (buf.length < 24 || buf.toString('latin1', 1, 4) !== 'PNG') return null;
  return { w: buf.readUInt32BE(16), h: buf.readUInt32BE(20) };
}
const read = (f) => { try { return fs.readFileSync(f); } catch (_) { return null; } };

function prepare(root) {
  const img = path.join(root, 'imagens'); const out = path.join(root, 'build');
  fs.mkdirSync(out, { recursive: true });
  for (const f of ['icon.ico', 'icon.png']) fs.rmSync(path.join(out, f), { force: true });
  const ico = read(path.join(img, 'Logo.ico')); const icoSize = ico ? icoMax(ico) : null;
  const png = read(path.join(img, 'Logo.png')); const ps = png ? pngSize(png) : null;
  const warnings = [];
  if (!ico) warnings.push('imagens/Logo.ico não encontrado.'); else if (icoSize === null) warnings.push('imagens/Logo.ico não é um arquivo .ico válido.'); else if (icoSize < 256) warnings.push(`imagens/Logo.ico tem só ${icoSize}x${icoSize}; o instalador exige pelo menos 256x256.`);
  if (icoSize >= 256) { fs.copyFileSync(path.join(img, 'Logo.ico'), path.join(out, 'icon.ico')); return { source: 'Logo.ico', size: icoSize, warnings }; }
  if (ps && ps.w >= 256 && ps.h >= 256) {
    fs.writeFileSync(path.join(out, 'icon.png'), png);
    if (ps.w !== ps.h) warnings.push(`Logo.png não é quadrado (${ps.w}x${ps.h}); o ícone pode ficar distorcido.`);
    return { source: 'Logo.png', size: Math.max(ps.w, ps.h), warnings };
  }
  warnings.push(png ? (ps ? `imagens/Logo.png tem só ${ps.w}x${ps.h}.` : 'imagens/Logo.png não é um PNG válido.') : 'imagens/Logo.png não encontrado.');
  return { source: null, size: 0, warnings };
}

if (require.main === module) {
  const r = prepare(path.join(__dirname, '..'));
  r.warnings.forEach((w) => console.warn('⚠ ' + w));
  if (r.source) console.log(`✔ Ícone do instalador: imagens/${r.source} (${r.size}x${r.size})`);
  else console.warn('⚠ Usando o ícone padrão do Electron. Coloque em imagens/ um Logo.ico (ou Logo.png) com pelo menos 256x256 para usar a sua logo.');
}
module.exports = { prepare, icoMax, pngSize };
