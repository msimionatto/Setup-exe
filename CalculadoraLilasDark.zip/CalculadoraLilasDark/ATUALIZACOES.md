# Atualização automática — guia

O LilasDark atualiza sozinho pelo **GitHub Releases** (electron-updater). Só funciona no app **instalado** (não no `npm start`).

## O que o app faz
- Verifica ao abrir (após ~20 s) e a cada **4 horas**; baixa em segundo plano e mostra o progresso.
- **Central de atualizações** (Configurações → Central de atualizações): verificar agora, baixar, reiniciar e atualizar, pular versão, ligar/desligar a verificação automática e escolher o canal **Estável** ou **Beta**.
- A bolinha verde no ícone de engrenagem avisa quando há atualização pronta. A versão baixada também é instalada ao fechar o app.
- Depois de atualizar, a tela **O que mudou** aparece uma única vez (vem do `CHANGELOG.md`).
- Erros viram mensagens claras, com o botão **Baixar manualmente**.
- **Log** em `%AppData%\LilasDark Calculadora\logs\lilasdark.log` (botão "Abrir pasta de logs"); configurações em `settings.json` na mesma pasta.

## Requisitos para funcionar
1. **Repositório público** (o app dos usuários consulta as releases sem login). Se precisar de repositório privado, hospede os arquivos fora do GitHub (veja "Alternativas").
2. A release precisa estar **publicada** (não rascunho). O projeto já usa `releaseType: release`.
3. A **tag** precisa ser igual à versão do `package.json` (ex.: `v2.2.1` ↔ `"version": "2.2.1"`) e o `CHANGELOG.md` precisa ter a seção `## 2.2.1`. O workflow confere isso.
4. Somente o **instalador** (NSIS) atualiza. A versão portátil foi removida do build.

## Publicar uma versão
1. Edite `version` no `package.json` e adicione `## x.y.z` no topo do `CHANGELOG.md`.
2. `git add -A && git commit -m "release: x.y.z"`
3. `git tag vx.y.z && git push && git push --tags`
4. O workflow **Release** roda testes, gera o instalador, publica `latest.yml` + `.exe` + `.blockmap` e coloca as notas do changelog na release.
5. Manualmente (sem Actions): `set GH_TOKEN=...` e `npm run release`.

## Roteiro de teste (máquina limpa)
1. Publique **v2.2.0** e instale o `.exe` em um Windows sem o projeto. Abra: não deve aparecer "O que mudou" (primeira instalação).
2. Aumente para **2.2.1** (package.json + CHANGELOG), publique a tag `v2.2.1`.
3. No Windows com a 2.2.0 aberta: Configurações → Central de atualizações → **Verificar agora**. Esperado: "Versão 2.2.1 disponível" → barra de progresso → **Reiniciar e atualizar**.
4. Depois de reiniciar: abre a tela **O que mudou** com as notas da 2.2.1; Sobre mostra 2.2.1.
5. Teste os caminhos extras: **Pular esta versão** (a verificação automática não volta a oferecê-la), internet desligada (mensagem de "Sem conexão"), canal Beta com uma pré-release (marque "Set as a pre-release" na release do GitHub).
6. Se algo falhar, abra a pasta de logs e veja `lilasdark.log`.

## Assinatura de código (recomendada)
Sem assinatura o update funciona, mas o Windows exibe o aviso do SmartScreen e não há verificação do autor.
1. Obtenha um certificado de assinatura de código (autoridade certificadora) **ou** use o Azure Trusted Signing.
2. Para certificado `.pfx`: converta para base64 e crie os secrets do repositório `CSC_LINK` e `CSC_KEY_PASSWORD` (o workflow já os repassa ao electron-builder).
3. **Só depois** de ter o certificado, adicione em `package.json` → `build.win` o campo `"publisherName": ["Nome exato do certificado"]`. Não adicione antes: com `publisherName` e instalador sem assinatura correspondente, o update é recusado.
4. A reputação no SmartScreen pode levar um tempo mesmo com certificado.

## Alternativas ao GitHub público
Troque `build.publish` por outro provedor, por exemplo servidor próprio:
```json
"publish": [{ "provider": "generic", "url": "https://seu-servidor/lilasdark/" }]
```
e publique nele os arquivos gerados em `dist/` (`latest.yml`, `.exe`, `.blockmap`). S3 e Azure Blob também são suportados pelo electron-builder.

## Instalação corporativa
O instalador é **por usuário** (não pede administrador) e instala em `%LocalAppData%\Programs`. Instalação silenciosa: `LilasDark-Setup-x.y.z.exe /S`.

## Mensagens de erro
| Mensagem | Causa provável |
|---|---|
| "Se o repositório do GitHub for privado…" | Repositório privado, release em rascunho ou sem `latest.yml` |
| "Sem conexão com a internet" | Sem rede, proxy ou firewall bloqueando github.com |
| "A assinatura da atualização não confere" | `publisherName` configurado sem instalador assinado pelo mesmo nome |
| "O arquivo baixado está corrompido" | Download interrompido; tente de novo |
