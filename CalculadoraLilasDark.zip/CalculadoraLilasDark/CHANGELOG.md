# Changelog

## 2.2.0
**Atualização automática**
- Central de Atualizações: verifica ao abrir e a cada 4 horas, mostra o progresso do download e o botão "Reiniciar e atualizar".
- Controles em Configurações: verificação automática (liga/desliga), canal Estável/Beta e "Pular esta versão".
- Tela "O que mudou" aparece uma vez depois de atualizar, com as notas da versão.
- Mensagens de erro claras (sem internet, repositório privado, assinatura, arquivo corrompido) com link para baixar manualmente.
- Tela "Sobre" (versão, licença, privacidade, links) e log em arquivo com botão "Abrir pasta de logs".
- Publicação corrigida: release sai publicada (não rascunho), instalador por usuário sem administrador e versão portátil removida.
- Release automática confere tag × versão × changelog e publica as notas.

## 2.1.0
**Base profissional**
- Respeita a opção "reduzir animações" do Windows (padrão desligado quando ativa).
- Entradas de todas as ferramentas (Financeira, Datas, Comercial, Matemática, Conversor, Moedas e Gráficos) ficam salvas entre sessões.
- Segurança: o processo principal só aceita mensagens da janela do app; payloads, cores, tamanhos e caminhos são validados; permissões de web negadas.
- Modo Programador com inteiros de 64 bits exatos (BigInt), com proteção de deslocamento e complemento de dois.
- Projeto: LICENSE (MIT), CI e release no GitHub Actions, ESLint, .editorconfig e testes de segurança.

**Animações**
- Splash de abertura com a logo; troca de modo deslizando na direção do card.
- Resultado com dígitos "rolando"; expressão colorida (operadores, funções e parênteses) com cursor piscando.
- Exclusão faz o item voar até a lixeira (com tampa animada); restauração voa até o histórico.
- Troca de tema com revelação circular; indicador deslizante nas abas das ferramentas.
- Financeira: barras de juros × amortização, linha-guia e dica no gráfico.
- Gráficos: zoom suave. Moedas: carregamento em esqueleto. Check animado nos avisos de sucesso. Som opcional das teclas.

## 2.0.0
- 7 novos modos (Financeira, Conversor, Moedas, Datas e horas, Comercial, Gráficos, Matemática), temas, variáveis e fórmulas, exportação PDF/Excel/fita, tutorial, formato brasileiro e atualização automática.

## 1.0.0
- Calculadora com modos Normal, Científica, Química e Programador, histórico, lixeira e download da conta.
