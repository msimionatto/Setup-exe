# Análise do projeto — LilasDark v2.2

> Fora do escopo por decisão do projeto: cálculos de INSS, IRRF e rescisão.

## Estado atual
| Área | Situação |
|---|---|
| Motor de cálculo | Parser próprio (sem `eval`), variáveis, 64 bits exatos no modo Programador |
| Modos | 11 (Normal, Científica, Química, Programador, Financeira, Conversor, Moedas, Datas e horas, Comercial, Gráficos, Matemática) |
| Qualidade | 45 testes automatizados, ESLint, CI no GitHub Actions |
| Segurança | contextIsolation + sandbox + CSP; IPC validado; permissões web negadas; caminhos revelados só se gerados pelo app |
| Acessibilidade de movimento | Respeita "reduzir animações" do Windows e tem chave própria nas Configurações |
| Persistência | Histórico, lixeira, variáveis, configurações e entradas de todas as ferramentas |

## Auto-update (v2.2) — situação dos itens
| Item | Situação |
|---|---|
| Release como rascunho | Corrigido (`releaseType: release`) |
| Repositório privado | **Ação sua:** o repositório precisa ser público (ou usar outro provedor — ver `ATUALIZACOES.md`); o app avisa com mensagem clara |
| Versão portátil | Removida do build; só o instalador NSIS (por usuário, sem administrador) |
| Assinatura digital | **Ação sua:** comprar o certificado; workflow e guia prontos (secrets `CSC_*` e `publisherName`) |
| Experiência de atualização | Central de atualizações: verificação a cada 4 h, progresso, reiniciar e atualizar, notas, erros claros |
| Controle do usuário | Liga/desliga, canal Estável/Beta e "Pular esta versão" |
| Log em arquivo | `logs/lilasdark.log` com rotação e botão "Abrir pasta de logs" |
| Tela Sobre, privacidade e novidades | Entregues |
| Roteiro de teste | Em `ATUALIZACOES.md` (execução depende de publicar duas versões) |

## Entregue na v2.1
- Base profissional: LICENSE, CI, release automatizado, ESLint, .editorconfig, testes de segurança, BigInt no Programador, entradas salvas.
- Animações: splash, dígitos rolando, expressão colorida, item voando para a lixeira, tampa animada, revelação circular de tema, indicador deslizante de abas, barras juros × amortização, dica no gráfico, zoom suave, esqueleto de carregamento, check animado, som opcional.

## Ainda não validado no Electron real
PDF e impressão da fita, cotações da internet, atalho global, cor da barra de título por tema e auto-update (só no app instalado e com versão publicada).

## Pendências (por prioridade)
**Média**
- Assinatura digital do instalador (evita aviso do SmartScreen). O workflow de release já aceita `CSC_LINK` e `CSC_KEY_PASSWORD`.
- Troca de `exceljs` por gerador de xlsx mais leve (reduz ~20 MB).
- Foco preso no modal e navegação por setas no menu de modos.
- Teste ponta a ponta com Playwright para Electron.

**Funcionalidades futuras**
- Comparador de investimentos (poupança × CDB × LCI × Tesouro, IR regressivo), ponto de equilíbrio, ROI e DRE simples, CET/IOF e amortização extra.
- Feriados editáveis por estado/município (Carnaval e Corpus Christi opcionais).
- Backup e restauração (histórico, variáveis, configurações) e busca/favoritos no histórico.
- Modo Praticar (exercícios), Geometria, Probabilidade; gráficos com derivada, interseção e área; química com balanceamento, molaridade e lei dos gases.
- Atalhos `Ctrl+1…9` para trocar de modo e colar com `Ctrl+V`.
- Idioma (inglês).

## Observações
- Impostos e cotações são referências; confirme alíquotas com seu contador e taxas com a instituição.
- A versão portátil (`portable`) não atualiza sozinha; só o instalador NSIS.
- Mac e Linux funcionam, mas não foram polidos (a barra de título pode sobrepor a logo).
