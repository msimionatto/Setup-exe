/* LilasDark - núcleo das ferramentas: formulários, resultados animados, passo a passo */
(function (root) {
  'use strict';
  const reg = [];
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const uerr = (m) => Object.assign(new Error(m), { user: true });
  const ok = Number.isFinite;
  const F = { loc: 'pt-BR' };
  const nf = (o) => new Intl.NumberFormat(F.loc, o);
  F.num = (x, d = 2) => (ok(x) ? nf({ minimumFractionDigits: d, maximumFractionDigits: d }).format(x) : '—');
  F.max = (x, d = 6) => (ok(x) ? nf({ maximumFractionDigits: d }).format(x) : '—');
  F.int = (x) => (ok(x) ? nf({ maximumFractionDigits: 0 }).format(x) : '—');
  F.money = (x) => (ok(x) ? nf({ style: 'currency', currency: 'BRL' }).format(x) : '—');
  F.pct = (x, d = 2) => (ok(x) ? F.num(x, d) + '%' : '—');
  F.sci = (x) => {
    if (!ok(x)) return '—';
    const a = Math.abs(x);
    if (a !== 0 && (a >= 1e12 || a < 1e-6)) { const [m, e] = x.toExponential(6).split('e'); return nf({ maximumFractionDigits: 6 }).format(Number(m)) + 'E' + e.replace('+', ''); }
    return F.max(x, 8);
  };
  // aceita "1.234,56", "1234.56", "R$ 10", "12%"
  F.parse = (s) => {
    if (typeof s === 'number') return s;
    s = String(s ?? '').trim().replace(/\s|R\$|%/g, '').replace(/−/g, '-');
    if (!s) return NaN;
    if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.');
    return /^[+-]?(\d+\.?\d*|\.\d+)(e[+-]?\d+)?$/i.test(s) ? Number(s) : NaN;
  };

  const define = (t) => { reg.push(t); return t; };
  const anim = () => typeof document !== 'undefined' && document.body.dataset.anim !== 'off';
  // entradas das ferramentas ficam salvas entre sessões
  const recall = (id) => { try { return JSON.parse(localStorage.getItem('lilasdark.tool.' + id)); } catch (_) { return null; } };
  const keep = (id, data) => { try { localStorage.setItem('lilasdark.tool.' + id, JSON.stringify(data)); } catch (_) { /* sem armazenamento */ } };

  function countUp(el, from, to, fmt, ms = 380) {
    if (!anim() || !ok(from) || from === to) { el.textContent = fmt(to); return; }
    const t0 = performance.now();
    const tick = (t) => {
      const k = Math.min(1, (t - t0) / ms); const e = 1 - Math.pow(1 - k, 3);
      el.textContent = fmt(from + (to - from) * e);
      if (k < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }

  function chartHTML(c) {
    const W = 320, H = 124, P = 8;
    const all = c.series.flatMap((s) => s.values).filter(ok);
    if (all.length < 2) return '';
    let mn = Math.min(...all), mx = Math.max(...all);
    if (mn === mx) { mn -= 1; mx += 1; }
    const cols = ['var(--lilac)', 'var(--accent)', 'var(--ok)'];
    const paths = c.series.map((s, k) => {
      const n = s.values.length;
      const pts = s.values.map((y, i) => [P + (W - 2 * P) * (n === 1 ? 0 : i / (n - 1)), H - P - (H - 2 * P) * ((y - mn) / (mx - mn))]);
      const d = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
      const area = k === 0 ? `<path class="area" d="${d} L${pts[n - 1][0].toFixed(1)} ${H - P} L${pts[0][0].toFixed(1)} ${H - P} Z"/>` : '';
      return area + `<path class="line draw" pathLength="1" d="${d}" stroke="${s.c || cols[k % 3]}"/>`;
    }).join('');
    const legend = c.series.map((s, k) => `<span><i style="background:${s.c || cols[k % 3]}"></i>${esc(s.name)}</span>`).join('');
    return `<div class="chartbox"><svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" class="chart">${paths}</svg><div class="cax"><span>${esc(c.x0 || '')}</span><span>${esc(c.x1 || '')}</span></div><div class="clg">${legend}</div></div>`;
  }
  const tableHTML = (t) => `<div class="tblw">${t.caption ? `<div class="cap">${esc(t.caption)}</div>` : ''}<div class="tbl"><table><thead><tr>${t.head.map((h) => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${t.rows.slice(0, 240).map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join('')}</tr>`).join('')}</tbody></table></div></div>`;
  const matrixHTML = (m) => `<div class="mx" style="--c:${m[0].length}">${m.flat().map((c) => `<span>${esc(c)}</span>`).join('')}</div>`;
  const text = (r) => (r.text !== undefined ? r.text : r.fmt(r.raw));

  function outHTML(res) {
    let h = '';
    if (res.results && res.results.length) h += `<div class="rgrid">${res.results.map((r, i) => `<div class="rc${r.main ? ' main' : ''}${r.tone ? ' ' + r.tone : ''}" style="--i:${i}"><span class="rl">${esc(r.label)}</span><span class="rv" data-i="${i}">${esc(text(r))}</span></div>`).join('')}</div>`;
    (res.matrices || []).forEach((m) => { h += `<div class="mxw"><div class="cap">${esc(m.label)}</div>${matrixHTML(m.m)}</div>`; });
    if (res.bars) {
      const tot = (b) => (b.a + b.b) || 1;
      h += `<div class="barsw"><div class="cap">${esc(res.bars.caption)}</div>${res.bars.items.map((b, i) => `<div class="sb" style="--i:${i}"><span class="sbl">${esc(b.label)}</span><span class="sbt"><i class="j" style="width:${((b.a / tot(b)) * 100).toFixed(1)}%"></i><i class="am" style="width:${((b.b / tot(b)) * 100).toFixed(1)}%"></i></span><em>${((b.a / tot(b)) * 100).toFixed(0)}% juros</em></div>`).join('')}<div class="clg"><span><i style="background:var(--accent)"></i>Juros</span><span><i style="background:var(--lilac2)"></i>Amortização</span></div></div>`;
    }
    if (res.chart) h += chartHTML(res.chart);
    if (res.table) h += tableHTML(res.table);
    if (res.note) h += `<p class="note">${esc(res.note)}</p>`;
    if (res.steps && res.steps.length) h += `<details class="steps"><summary>Passo a passo</summary><ol>${res.steps.map((s) => `<li>${s}</li>`).join('')}</ol></details>`;
    h += '<div class="oact"><button class="mini" data-act="save">Salvar no histórico</button><button class="mini" data-act="copy">Copiar resultado</button></div>';
    return h;
  }

  const lbl = (f, raw) => (typeof f.label === 'function' ? f.label(raw) : f.label);
  function fieldHTML(f, raw) {
    const hint = f.hint ? `<small>${esc(f.hint)}</small>` : '';
    if (f.type === 'check') return `<label class="chk wide" data-f="${f.k}"><input type="checkbox" data-k="${f.k}"${raw[f.k] ? ' checked' : ''}><span>${esc(lbl(f, raw))}</span></label>`;
    let ctl;
    if (f.type === 'select') ctl = `<select data-k="${f.k}">${f.options.map(([v, l]) => `<option value="${esc(v)}"${String(raw[f.k]) === String(v) ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
    else if (f.type === 'textarea') ctl = `<textarea data-k="${f.k}" rows="${f.rows || 4}" placeholder="${esc(f.ph || '')}" spellcheck="false">${esc(raw[f.k] ?? '')}</textarea>`;
    else ctl = `<input data-k="${f.k}" type="${f.type === 'date' || f.type === 'time' ? f.type : 'text'}" inputmode="${f.type === 'number' ? 'decimal' : 'text'}" value="${esc(raw[f.k] ?? '')}" placeholder="${esc(f.ph || '')}" autocomplete="off" spellcheck="false">`;
    return `<label class="fld${f.wide || f.type === 'textarea' ? ' wide' : ''}" data-f="${f.k}"><span class="fl">${esc(lbl(f, raw))}</span><span class="inp">${f.pre ? `<em>${esc(f.pre)}</em>` : ''}${ctl}${f.suf ? `<em>${esc(f.suf)}</em>` : ''}</span>${hint}</label>`;
  }

  // linha-guia e dica ao passar o mouse sobre o gráfico
  function attachChart(box, c) {
    if (!box || !c) return;
    const svg = box.querySelector('svg'); const tip = document.createElement('div'); const line = document.createElement('div');
    tip.className = 'ctip'; line.className = 'cline'; tip.hidden = line.hidden = true; box.append(line, tip);
    svg.addEventListener('pointermove', (e) => {
      const r = svg.getBoundingClientRect(), b = box.getBoundingClientRect(); const n = c.series[0].values.length; if (n < 2) return;
      const i = Math.round(Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * (n - 1)); const x = r.left - b.left + (i / (n - 1)) * r.width;
      line.style.left = x + 'px'; line.style.top = r.top - b.top + 'px'; line.style.height = r.height + 'px';
      tip.innerHTML = `<b>${esc(c.xs ? c.xs[i] : 'ponto ' + (i + 1))}</b>` + c.series.map((s) => `<span>${esc(s.name)}: ${(c.fmt || F.money)(s.values[i])}</span>`).join('');
      tip.style.left = Math.min(Math.max(0, x - 60), box.clientWidth - 140) + 'px'; tip.hidden = line.hidden = false;
    });
    svg.addEventListener('pointerleave', () => { tip.hidden = line.hidden = true; });
  }

  function mount(tool, host, ctx) {
    if (tool.render) { host.innerHTML = ''; tool.render(host, ctx); return; }
    const st = tool._st || (tool._st = (() => {
      const o = { sec: tool.sections[0].id, raw: {}, prev: {} }; const m = recall(tool.id);
      if (m && tool.sections.some((s) => s.id === m.sec)) { o.sec = m.sec; o.raw = m.raw && typeof m.raw === 'object' ? m.raw : {}; }
      return o;
    })());
    const secOf = () => tool.sections.find((s) => s.id === st.sec) || tool.sections[0];
    host.innerHTML = `<div class="thead"><div class="tg">${esc(tool.glyph)}</div><div><h2>${esc(tool.name)}</h2><p>${esc(tool.desc)}</p></div></div>
      <div class="stabs ind"><span class="indbar"></span>${tool.sections.map((s) => `<button data-s="${s.id}" class="${s.id === st.sec ? 'on' : ''}">${esc(s.name)}</button>`).join('')}</div><div class="sbody"></div>`;
    const body = host.querySelector('.sbody'); let last = null; let shown = false;
    const tabs = host.querySelector('.stabs'), ind = tabs.querySelector('.indbar');
    const moveInd = () => { // indicador deslizante da aba ativa
      const b = tabs.querySelector('button.on'); if (!b) return;
      ind.style.width = b.offsetWidth + 'px'; ind.style.height = b.offsetHeight + 'px'; ind.style.top = b.offsetTop + 'px'; ind.style.transform = `translateX(${b.offsetLeft}px)`;
      if (tabs.scrollTo) tabs.scrollTo({ left: Math.max(0, b.offsetLeft - 24), behavior: 'smooth' });
    };
    const persist = () => {
      const raw = {};
      for (const s of tool.sections) { const r = st.raw[s.id]; if (!r) continue; raw[s.id] = {}; for (const f of s.fields) if (typeof f.def !== 'function' && r[f.k] !== undefined) raw[s.id][f.k] = r[f.k]; }
      keep(tool.id, { sec: st.sec, raw });
    };
    host.querySelector('.stabs').addEventListener('click', (e) => {
      const b = e.target.closest('[data-s]'); if (!b) return;
      st.sec = b.dataset.s; host.querySelectorAll('.stabs button').forEach((x) => x.classList.toggle('on', x === b)); moveInd(); persist(); draw();
    });

    function draw() {
      const sec = secOf(); const raw = st.raw[sec.id] || (st.raw[sec.id] = {});
      for (const f of sec.fields) if (raw[f.k] === undefined) raw[f.k] = typeof f.def === 'function' ? f.def() : (f.def !== undefined ? f.def : (f.type === 'check' ? false : ''));
      body.classList.remove('enter'); void body.offsetWidth; body.classList.add('enter');
      body.innerHTML = `${sec.learn ? `<details class="learn"><summary>Como funciona</summary><div>${sec.learn}</div></details>` : ''}<div class="fgrid">${sec.fields.map((f) => fieldHTML(f, raw)).join('')}</div><div class="out"></div>`;
      const onIn = (e) => { const el = e.target.closest('[data-k]'); if (!el) return; raw[el.dataset.k] = el.type === 'checkbox' ? el.checked : el.value; persist(); run(); };
      body.querySelector('.fgrid').addEventListener('input', onIn);
      body.querySelector('.fgrid').addEventListener('change', onIn);
      body.querySelector('.out').addEventListener('click', (e) => {
        const a = e.target.closest('[data-act]'); if (!a || !last) return;
        const main = last.results.find((r) => r.main) || last.results[0];
        if (a.dataset.act === 'save') ctx.save({ expr: `${tool.name} · ${sec.name}`, res: text(main), mode: tool.id, data: { sec: sec.id, raw: { ...raw } } });
        else navigator.clipboard.writeText(last.results.map((r) => `${r.label}: ${text(r)}`).join('\n')).then(() => ctx.toast('Resultados copiados'), () => ctx.toast('Não foi possível copiar'));
      });
      shown = false; run();
    }

    function run() {
      const sec = secOf(); const raw = st.raw[sec.id]; const out = body.querySelector('.out');
      const v = {}; const missing = [];
      for (const f of sec.fields) {
        const wrap = body.querySelector(`[data-f="${f.k}"]`); const vis = !f.show || f.show(raw); wrap.hidden = !vis;
        if (typeof f.label === 'function') { const sp = wrap.querySelector('.fl') || wrap.querySelector('span'); if (sp) sp.textContent = f.label(raw); }
        const val = raw[f.k];
        if (f.type === 'number') { v[f.k] = F.parse(val); if (Number.isNaN(v[f.k])) { if (f.zero) v[f.k] = 0; else if (!f.opt && vis) missing.push(lbl(f, raw)); } }
        else if (f.type === 'check') v[f.k] = !!val;
        else { v[f.k] = val; if (!f.opt && vis && !String(val).trim()) missing.push(lbl(f, raw)); }
      }
      const wasOpen = out.querySelector('.steps') && out.querySelector('.steps').open;
      let res = null;
      if (missing.length) { last = null; shown = false; out.className = 'out'; out.innerHTML = `<div class="hintcard"><b>Preencha para calcular</b><span>${esc(missing.join(' · '))}</span></div>`; return; }
      try { res = sec.calc(v, ctx); } catch (e) {
        last = null; out.className = 'out';
        out.innerHTML = `<div class="errcard"><b>Ops!</b><span>${esc(e.user ? e.message : 'Não foi possível calcular com esses valores.')}</span></div>`; shown = false; return;
      }
      last = res; out.className = 'out' + (shown ? '' : ' fresh'); out.innerHTML = outHTML(res); attachChart(out.querySelector('.chartbox'), res.chart);
      if (wasOpen) out.querySelector('.steps').open = true;
      res.results.forEach((r, i) => {
        if (r.raw === undefined || !r.fmt) return;
        const key = sec.id + ':' + r.label; const el = out.querySelector(`.rv[data-i="${i}"]`);
        if (shown) countUp(el, st.prev[key], r.raw, r.fmt); st.prev[key] = r.raw;
      });
      shown = true;
    }
    draw(); moveInd();
  }

  function restore(toolId, data) {
    const t = reg.find((x) => x.id === toolId); if (!t || !data) return;
    t._st = t._st || { sec: t.sections[0].id, raw: {}, prev: {} };
    t._st.sec = data.sec; t._st.raw[data.sec] = { ...data.raw };
  }

  const api = { define, list: () => reg, get: (id) => reg.find((t) => t.id === id), F, esc, uerr, chartHTML, tableHTML, matrixHTML, mount, restore, countUp, recall, keep };
  root.Tools = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
