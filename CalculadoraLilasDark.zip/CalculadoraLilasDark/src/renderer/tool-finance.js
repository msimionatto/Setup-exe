/* LilasDark - Financeira */
(function (root) {
  'use strict';
  const { define, F, uerr } = root.Tools;
  const mrate = (r, per) => (per === 'ano' ? Math.pow(1 + r / 100, 1 / 12) - 1 : r / 100);
  const mons = (t, per) => (per === 'anos' ? t * 12 : t);
  const RPER = [['mes', 'ao mês'], ['ano', 'ao ano']];
  const TPER = [['meses', 'meses'], ['anos', 'anos']];
  const fvf = (vp, pmt, i, n) => { const g = Math.pow(1 + i, n); return vp * g + (i === 0 ? pmt * n : (pmt * (g - 1)) / i); };
  const R = (k, label, raw, fmt, main) => ({ k, label, raw, fmt, main });
  const npv = (r, c) => c.reduce((a, x, k) => a + x / Math.pow(1 + r, k), 0);
  function irr(c) {
    let lo = -0.9999, hi = 1; let flo = npv(lo, c), fhi = npv(hi, c);
    while (flo * fhi > 0 && hi < 1e4) { hi *= 2; fhi = npv(hi, c); }
    if (flo * fhi > 0) return null;
    for (let k = 0; k < 200; k++) { const mid = (lo + hi) / 2, fm = npv(mid, c); if (flo * fm <= 0) { hi = mid; fhi = fm; } else { lo = mid; flo = fm; } }
    return (lo + hi) / 2;
  }
  function payback(c, r) {
    let cum = 0;
    for (let k = 0; k < c.length; k++) {
      const x = c[k] / Math.pow(1 + r, k); const prev = cum; cum += x;
      if (k > 0 && cum >= 0 && x > 0) return k - 1 + -prev / x;
    }
    return null;
  }
  const flows = (s) => {
    const a = String(s).split(/[\n;]+/).map((t) => t.trim()).filter(Boolean).map(F.parse);
    if (a.some((x) => Number.isNaN(x))) throw uerr('Há valores inválidos na lista de fluxos.');
    if (a.length < 2) throw uerr('Informe ao menos 2 fluxos (investimento e retorno).');
    return a;
  };
  const idxs = (len, max = 60) => { const st = Math.max(1, Math.ceil(len / max)); const o = []; for (let i = 0; i < len; i += st) o.push(i); if (o[o.length - 1] !== len - 1) o.push(len - 1); return o; };
  const sample = (arr, max = 60) => idxs(arr.length, max).map((i) => arr[i]);

  const sections = [
    { id: 'compound', name: 'Juros compostos',
      learn: 'Nos <b>juros compostos</b>, os juros do mês entram no saldo e rendem nos meses seguintes ("juros sobre juros").<br><code>VF = VP·(1+i)ⁿ + PMT·[((1+i)ⁿ−1)/i]</code><br>VP = valor inicial · PMT = aporte mensal · i = taxa mensal · n = meses. Exemplo: R$ 1.000 a 1% ao mês por 12 meses viram R$ 1.126,83.',
      fields: [
        { k: 'vp', label: 'Valor inicial', type: 'number', pre: 'R$', def: '1000', zero: true },
        { k: 'pmt', label: 'Aporte mensal', type: 'number', pre: 'R$', def: '200', zero: true, hint: 'Depositado no fim de cada mês' },
        { k: 'rate', label: 'Taxa de juros', type: 'number', suf: '%', def: '1' },
        { k: 'rper', label: 'Período da taxa', type: 'select', options: RPER, def: 'mes' },
        { k: 'time', label: 'Prazo', type: 'number', def: '12' },
        { k: 'tper', label: 'Unidade do prazo', type: 'select', options: TPER, def: 'meses' },
      ],
      calc(v) {
        const i = mrate(v.rate, v.rper), n = mons(v.time, v.tper);
        if (n <= 0) throw uerr('O prazo precisa ser maior que zero.');
        const fv = fvf(v.vp, v.pmt, i, n); const inv = v.vp + v.pmt * n; const gain = fv - inv;
        const bal = [], put = [];
        for (let k = 0; k <= Math.floor(n); k++) { bal.push(fvf(v.vp, v.pmt, i, k)); put.push(v.vp + v.pmt * k); }
        return {
          results: [R('fv', 'Valor final', fv, F.money, true), R('inv', 'Total investido', inv, F.money), R('gain', 'Juros ganhos', gain, F.money), R('ret', 'Rentabilidade total', inv ? (gain / inv) * 100 : 0, F.pct)],
          chart: { series: [{ name: 'Patrimônio', values: sample(bal) }, { name: 'Investido', values: sample(put) }], x0: 'início', x1: `${F.max(n, 1)} meses`, xs: idxs(bal.length).map((i) => `mês ${i}`) },
          steps: [`Taxa mensal: <code>i = ${F.num(i * 100, 4)}%</code>${v.rper === 'ano' ? ' (convertida da taxa anual: (1+i<sub>a</sub>)<sup>1/12</sup>−1)' : ''}`, `Fator de crescimento: <code>(1+i)ⁿ = ${F.max(Math.pow(1 + i, n), 6)}</code>`, `Valor inicial corrigido: <code>${F.money(v.vp * Math.pow(1 + i, n))}</code>`, `Aportes corrigidos: <code>${F.money(fv - v.vp * Math.pow(1 + i, n))}</code>`, `Total: <code>${F.money(fv)}</code>`],
        };
      } },
    { id: 'simple', name: 'Juros simples',
      learn: 'Nos <b>juros simples</b>, a taxa incide sempre sobre o capital inicial.<br><code>J = C · i · n</code> e <code>M = C + J</code>. Taxas anuais são divididas por 12 (proporcionais).',
      fields: [
        { k: 'c', label: 'Capital', type: 'number', pre: 'R$', def: '1000' },
        { k: 'rate', label: 'Taxa de juros', type: 'number', suf: '%', def: '2' },
        { k: 'rper', label: 'Período da taxa', type: 'select', options: RPER, def: 'mes' },
        { k: 'time', label: 'Prazo', type: 'number', def: '6' },
        { k: 'tper', label: 'Unidade do prazo', type: 'select', options: TPER, def: 'meses' },
      ],
      calc(v) {
        const im = (v.rper === 'ano' ? v.rate / 12 : v.rate) / 100, n = mons(v.time, v.tper);
        const j = v.c * im * n;
        return { results: [R('m', 'Montante', v.c + j, F.money, true), R('j', 'Juros', j, F.money)], steps: [`Taxa mensal: <code>${F.num(im * 100, 4)}%</code>`, `<code>J = ${F.money(v.c)} × ${F.num(im * 100, 4)}% × ${F.max(n, 2)} = ${F.money(j)}</code>`, `<code>M = C + J = ${F.money(v.c + j)}</code>`] };
      } },
    { id: 'price', name: 'Parcelas (Price/SAC)',
      learn: '<b>Price:</b> parcelas iguais (juros altos no início, amortização crescente).<br><b>SAC:</b> amortização constante; as parcelas começam maiores e diminuem.<br><code>PMT = PV·i / (1−(1+i)⁻ⁿ)</code><br>Em geral o SAC paga menos juros no total; o Price tem parcela inicial menor.',
      fields: [
        { k: 'pv', label: 'Valor financiado', type: 'number', pre: 'R$', def: '10000' },
        { k: 'rate', label: 'Taxa de juros', type: 'number', suf: '%', def: '1' },
        { k: 'rper', label: 'Período da taxa', type: 'select', options: RPER, def: 'mes' },
        { k: 'n', label: 'Nº de parcelas', type: 'number', def: '12' },
        { k: 'sys', label: 'Mostrar tabela de', type: 'select', options: [['price', 'Price'], ['sac', 'SAC']], def: 'price' },
      ],
      calc(v) {
        const i = mrate(v.rate, v.rper), n = Math.round(v.n);
        if (n < 1) throw uerr('Informe ao menos 1 parcela.'); if (v.pv <= 0) throw uerr('O valor financiado precisa ser positivo.');
        const pp = i === 0 ? v.pv / n : (v.pv * i) / (1 - Math.pow(1 + i, -n));
        const P = [], S = []; let sp = v.pv, ss = v.pv; const am = v.pv / n;
        for (let k = 1; k <= n; k++) {
          const jp = sp * i, ap = pp - jp; sp -= ap; P.push([k, pp, jp, ap, Math.max(0, sp)]);
          const js = ss * i; ss -= am; S.push([k, am + js, js, am, Math.max(0, ss)]);
        }
        const totP = pp * n, totS = S.reduce((a, r) => a + r[1], 0);
        const rows = (v.sys === 'sac' ? S : P).map((r) => [String(r[0]), ...r.slice(1).map(F.money)]);
        const src = v.sys === 'sac' ? S : P; const pick = [...new Set([0, Math.floor(n / 4), Math.floor(n / 2), Math.floor((3 * n) / 4), n - 1])];
        const bars = { caption: 'Quanto de cada parcela é juros × amortização', items: pick.map((i) => ({ label: `Parcela ${i + 1}`, a: src[i][2], b: src[i][3] })) };
        return {
          results: [R('pmtP', 'Price: parcela fixa', pp, F.money, true), R('totP', 'Price: total pago', totP, F.money), R('jurP', 'Price: juros totais', totP - v.pv, F.money),
            R('sac1', 'SAC: 1ª parcela', S[0][1], F.money), R('sacN', 'SAC: última parcela', S[n - 1][1], F.money), R('totS', 'SAC: total pago', totS, F.money), R('jurS', 'SAC: juros totais', totS - v.pv, F.money),
            R('diff', 'Economia do SAC em juros', totP - totS, F.money)],
          chart: { series: [{ name: 'Parcela Price', values: sample(P.map((r) => r[1])) }, { name: 'Parcela SAC', values: sample(S.map((r) => r[1])) }], x0: 'parcela 1', x1: `parcela ${n}`, xs: idxs(n).map((i) => `parcela ${i + 1}`) },
          bars,
          table: { caption: `Tabela ${v.sys === 'sac' ? 'SAC' : 'Price'}`, head: ['Nº', 'Parcela', 'Juros', 'Amortização', 'Saldo'], rows },
          steps: [`Taxa mensal: <code>i = ${F.num(i * 100, 4)}%</code>`, `Price: <code>PMT = ${F.money(v.pv)} × i / (1 − (1+i)<sup>−${n}</sup>) = ${F.money(pp)}</code>`, `SAC: amortização fixa <code>${F.money(v.pv)} / ${n} = ${F.money(am)}</code>; cada parcela = amortização + juros sobre o saldo devedor.`],
        };
      } },
    { id: 'pvfv', name: 'Valor presente/futuro',
      learn: 'Dinheiro muda de valor no tempo. <code>VF = VP·(1+i)ⁿ</code>. Escolha o que quer descobrir e preencha o resto. A taxa e o prazo devem estar na mesma unidade (ex.: % ao mês e meses).',
      fields: [
        { k: 'solve', label: 'Quero calcular', type: 'select', options: [['fv', 'Valor futuro (VF)'], ['pv', 'Valor presente (VP)'], ['rate', 'Taxa (i)'], ['n', 'Prazo (n)']], def: 'fv' },
        { k: 'vp', label: 'Valor presente (VP)', type: 'number', pre: 'R$', def: '1000', show: (r) => r.solve !== 'pv' },
        { k: 'vf', label: 'Valor futuro (VF)', type: 'number', pre: 'R$', def: '1500', show: (r) => r.solve !== 'fv' },
        { k: 'i', label: 'Taxa por período', type: 'number', suf: '%', def: '1', show: (r) => r.solve !== 'rate' },
        { k: 'n', label: 'Nº de períodos', type: 'number', def: '12', show: (r) => r.solve !== 'n' },
      ],
      calc(v) {
        const s = v.solve; let r;
        if (s === 'fv') r = R('r', 'Valor futuro', v.vp * Math.pow(1 + v.i / 100, v.n), F.money, true);
        else if (s === 'pv') r = R('r', 'Valor presente', v.vf / Math.pow(1 + v.i / 100, v.n), F.money, true);
        else if (s === 'rate') { if (v.vp <= 0 || v.vf <= 0 || v.n <= 0) throw uerr('VP, VF e n devem ser positivos.'); r = R('r', 'Taxa por período', (Math.pow(v.vf / v.vp, 1 / v.n) - 1) * 100, (x) => F.num(x, 4) + '%', true); }
        else { if (v.vp <= 0 || v.vf <= 0 || v.i <= -100) throw uerr('Valores inválidos.'); r = R('r', 'Prazo (períodos)', Math.log(v.vf / v.vp) / Math.log(1 + v.i / 100), (x) => F.num(x, 2), true); }
        return { results: [r], steps: ['Fórmula-base: <code>VF = VP · (1 + i)ⁿ</code>', 'Isolamos a incógnita escolhida e aplicamos os valores informados.'] };
      } },
    { id: 'rates', name: 'Taxas equivalentes',
      learn: 'Uma taxa mensal de 1% <b>não</b> equivale a 12% ao ano: com capitalização composta fica 12,68%. <code>(1+i<sub>ano</sub>) = (1+i<sub>mês</sub>)¹²</code>.<br>Informe a inflação para ver a <b>taxa real</b> (Fisher): <code>(1+i)/(1+π) − 1</code>.',
      fields: [
        { k: 'rate', label: 'Taxa', type: 'number', suf: '%', def: '1' },
        { k: 'from', label: 'Período da taxa', type: 'select', options: [['365', 'ao dia'], ['12', 'ao mês'], ['6', 'ao bimestre'], ['4', 'ao trimestre'], ['2', 'ao semestre'], ['1', 'ao ano']], def: '12' },
        { k: 'infl', label: 'Inflação anual (opcional)', type: 'number', suf: '%', opt: true, def: '' },
      ],
      calc(v) {
        const ppy = Number(v.from); const annual = Math.pow(1 + v.rate / 100, ppy) - 1;
        const eq = (p) => (Math.pow(1 + annual, 1 / p) - 1) * 100;
        const res = [R('ano', 'Efetiva ao ano', annual * 100, (x) => F.num(x, 4) + '%', true), R('sem', 'Ao semestre', eq(2), (x) => F.num(x, 4) + '%'), R('tri', 'Ao trimestre', eq(4), (x) => F.num(x, 4) + '%'), R('mes', 'Ao mês', eq(12), (x) => F.num(x, 4) + '%'), R('dia', 'Ao dia (365)', eq(365), (x) => F.num(x, 5) + '%'), R('nom', 'Nominal anual (proporcional)', v.rate * ppy, (x) => F.num(x, 4) + '%')];
        if (!Number.isNaN(v.infl)) res.push(R('real', 'Taxa real anual', ((1 + annual) / (1 + v.infl / 100) - 1) * 100, (x) => F.num(x, 4) + '%'));
        return { results: res, steps: [`Efetiva anual: <code>(1 + ${F.num(v.rate, 4)}%)<sup>${ppy}</sup> − 1 = ${F.num(annual * 100, 4)}%</code>`, 'Para outros períodos: <code>(1 + i<sub>ano</sub>)<sup>1/p</sup> − 1</code>'] };
      } },
    { id: 'npv', name: 'VPL, TIR e Payback',
      learn: '<b>VPL</b> traz os fluxos para o valor de hoje: <code>Σ FCₖ/(1+r)ᵏ</code>. VPL &gt; 0 indica projeto que cria valor.<br><b>TIR</b> é a taxa que zera o VPL. <b>Payback</b> é o tempo para recuperar o investimento. Digite um fluxo por linha; o primeiro (período 0) costuma ser negativo.',
      fields: [
        { k: 'rate', label: 'Taxa de desconto (% por período)', type: 'number', suf: '%', def: '10' },
        { k: 'cf', label: 'Fluxos de caixa (um por linha)', type: 'textarea', rows: 5, def: '-1000\n300\n400\n500\n600', ph: '-1000\n300\n400...' },
      ],
      calc(v) {
        const c = flows(v.cf); const r = v.rate / 100; const val = npv(r, c);
        const t = irr(c); const pb = payback(c, 0); const pbd = payback(c, r);
        const inflow = c.slice(1).reduce((a, x, k) => a + x / Math.pow(1 + r, k + 1), 0);
        const res = [R('vpl', 'VPL', val, F.money, true), { k: 'tir', label: 'TIR', text: t === null ? 'não encontrada' : F.num(t * 100, 4) + '%', raw: t === null ? undefined : t * 100, fmt: (x) => F.num(x, 4) + '%' },
          { k: 'pb', label: 'Payback simples', text: pb === null ? 'não se paga' : F.num(pb, 2) + ' períodos' }, { k: 'pbd', label: 'Payback descontado', text: pbd === null ? 'não se paga' : F.num(pbd, 2) + ' períodos' }];
        if (c[0] < 0) res.push(R('pi', 'Índice de lucratividade', inflow / -c[0], (x) => F.num(x, 3)));
        return { results: res, note: val > 0 ? 'VPL positivo: o projeto remunera acima da taxa de desconto.' : 'VPL não positivo: o projeto não cobre a taxa de desconto exigida.',
          steps: c.map((x, k) => `Período ${k}: <code>${F.money(x)} / (1+${F.num(v.rate, 2)}%)<sup>${k}</sup> = ${F.money(x / Math.pow(1 + r, k))}</code>`).concat([`Soma = VPL = <code>${F.money(val)}</code>`]) };
      } },
    { id: 'goal', name: 'Meta de poupança',
      learn: 'Descubra quanto guardar por mês para chegar a um valor. Isolando o aporte na fórmula de juros compostos: <code>PMT = (VF − VP·(1+i)ⁿ)·i / ((1+i)ⁿ − 1)</code>.',
      fields: [
        { k: 'goal', label: 'Quanto quero juntar', type: 'number', pre: 'R$', def: '50000' },
        { k: 'vp', label: 'Já tenho', type: 'number', pre: 'R$', def: '5000', zero: true },
        { k: 'rate', label: 'Rentabilidade', type: 'number', suf: '%', def: '0,8' },
        { k: 'rper', label: 'Período da taxa', type: 'select', options: RPER, def: 'mes' },
        { k: 'time', label: 'Prazo', type: 'number', def: '36' },
        { k: 'tper', label: 'Unidade do prazo', type: 'select', options: TPER, def: 'meses' },
      ],
      calc(v) {
        const i = mrate(v.rate, v.rper), n = mons(v.time, v.tper); if (n <= 0) throw uerr('O prazo precisa ser maior que zero.');
        const g = Math.pow(1 + i, n); const pmt = i === 0 ? (v.goal - v.vp) / n : ((v.goal - v.vp * g) * i) / (g - 1);
        if (pmt < 0) return { results: [{ k: 'pmt', label: 'Aporte mensal', text: 'R$ 0,00 — você já atinge a meta', main: true }], steps: ['O valor atual, corrigido pela taxa, já supera a meta.'] };
        return { results: [R('pmt', 'Aporte mensal necessário', pmt, F.money, true), R('tot', 'Total depositado', pmt * n + v.vp, F.money), R('jur', 'Juros que trabalham por você', v.goal - pmt * n - v.vp, F.money)], steps: [`Taxa mensal <code>${F.num(i * 100, 4)}%</code> · ${F.max(n, 1)} meses`, `Fator <code>(1+i)ⁿ = ${F.max(g, 6)}</code>`, `<code>PMT = ${F.money(pmt)}</code>`] };
      } },
  ];
  define({ id: 'finance', name: 'Financeira', glyph: 'R$', desc: 'Juros, parcelas, VPL/TIR e metas com passo a passo', sections });
})(typeof window !== 'undefined' ? window : globalThis);
