/* LilasDark - Comercial e impostos (Brasil) */
(function (root) {
  'use strict';
  const { define, F, uerr } = root.Tools;
  const R = (k, label, raw, fmt, main, tone) => ({ k, label, raw, fmt, main, tone });
  const P4 = (x) => F.num(x, 2) + '%';
  const sections = [
    { id: 'percent', name: 'Porcentagem',
      learn: 'Escolha o tipo de problema. <code>X% de Y = Y·X/100</code> · <code>variação = (novo − antigo)/antigo</code>. Aumentar 20% é multiplicar por 1,20; diminuir 20% é multiplicar por 0,80.',
      fields: [
        { k: 'kind', label: 'O que calcular', type: 'select', def: 'of', options: [['of', 'X% de Y'], ['is', 'X é quantos % de Y'], ['var', 'Variação % de A para B'], ['inc', 'Aumentar Y em X%'], ['dec', 'Diminuir Y em X%']] },
        { k: 'a', label: (r) => ({ of: 'Percentual (X)', is: 'Valor (X)', var: 'Valor antigo (A)', inc: 'Percentual (X)', dec: 'Percentual (X)' }[r.kind]), type: 'number', def: '15' },
        { k: 'b', label: (r) => ({ of: 'Valor total (Y)', is: 'Total (Y)', var: 'Valor novo (B)', inc: 'Valor (Y)', dec: 'Valor (Y)' }[r.kind]), type: 'number', def: '200' },
      ],
      calc(v) {
        const { kind: k, a, b } = v; let r, st;
        if (k === 'of') { r = R('r', `${F.max(a)}% de ${F.max(b)}`, (a * b) / 100, (x) => F.max(x, 4), true); st = [`<code>${F.max(b)} × ${F.max(a)} ÷ 100</code>`]; }
        else if (k === 'is') { if (b === 0) throw uerr('O total não pode ser zero.'); r = R('r', 'Percentual', (a / b) * 100, P4, true); st = [`<code>(${F.max(a)} ÷ ${F.max(b)}) × 100</code>`]; }
        else if (k === 'var') { if (a === 0) throw uerr('O valor antigo não pode ser zero.'); const x = ((b - a) / a) * 100; r = R('r', x >= 0 ? 'Aumento' : 'Redução', x, P4, true, x >= 0 ? 'up' : 'down'); st = [`<code>(${F.max(b)} − ${F.max(a)}) ÷ ${F.max(a)} × 100</code>`]; }
        else if (k === 'inc') { r = R('r', 'Valor com aumento', b * (1 + a / 100), (x) => F.max(x, 4), true); st = [`<code>${F.max(b)} × (1 + ${F.max(a)}/100)</code>`]; }
        else { r = R('r', 'Valor com desconto', b * (1 - a / 100), (x) => F.max(x, 4), true); st = [`<code>${F.max(b)} × (1 − ${F.max(a)}/100)</code>`]; }
        return { results: [r], steps: st };
      } },
    { id: 'markup', name: 'Preço de venda',
      learn: '<b>Margem</b> é o lucro sobre o <b>preço de venda</b>; <b>markup</b> é o acréscimo sobre o <b>custo</b>. Para atingir a margem desejada: <code>Preço = Custo / (1 − margem − despesas variáveis)</code>.',
      fields: [
        { k: 'cost', label: 'Custo do produto', type: 'number', pre: 'R$', def: '60' },
        { k: 'margin', label: 'Margem de lucro desejada', type: 'number', suf: '%', def: '25' },
        { k: 'exp', label: 'Impostos + comissões sobre a venda', type: 'number', suf: '%', zero: true, def: '10', hint: 'Soma dos percentuais que saem do preço' },
      ],
      calc(v) {
        const d = 1 - (v.margin + v.exp) / 100; if (d <= 0) throw uerr('Margem + despesas devem somar menos de 100%.');
        const price = v.cost / d; const profit = price * (v.margin / 100);
        return { results: [R('price', 'Preço de venda', price, F.money, true), R('profit', 'Lucro por unidade', profit, F.money), R('markup', 'Markup sobre o custo', (price / v.cost - 1) * 100, P4), R('exp', 'Despesas sobre a venda', price * (v.exp / 100), F.money)],
          steps: [`Divisor: <code>1 − (${F.num(v.margin)}% + ${F.num(v.exp)}%) = ${F.max(d, 4)}</code>`, `Preço: <code>${F.money(v.cost)} ÷ ${F.max(d, 4)} = ${F.money(price)}</code>`] };
      } },
    { id: 'margin', name: 'Margem e lucro',
      learn: 'Informe o preço de venda e o custo para ver lucro, <b>margem</b> (sobre a venda) e <b>markup</b> (sobre o custo).',
      fields: [{ k: 'price', label: 'Preço de venda', type: 'number', pre: 'R$', def: '100' }, { k: 'cost', label: 'Custo', type: 'number', pre: 'R$', def: '65' }, { k: 'qty', label: 'Quantidade', type: 'number', def: '1', zero: true }],
      calc(v) {
        if (v.price <= 0) throw uerr('O preço deve ser positivo.'); const q = v.qty || 1; const lucro = (v.price - v.cost) * q;
        return { results: [R('profit', 'Lucro total', lucro, F.money, true, lucro >= 0 ? 'up' : 'down'), R('margin', 'Margem', ((v.price - v.cost) / v.price) * 100, P4), R('markup', 'Markup', v.cost ? ((v.price - v.cost) / v.cost) * 100 : NaN, P4), R('rev', 'Faturamento', v.price * q, F.money)],
          steps: [`Lucro = (preço − custo) × qtd = <code>${F.money(lucro)}</code>`, `Margem = lucro ÷ preço = <code>${F.num(((v.price - v.cost) / v.price) * 100)}%</code>`] };
      } },
    { id: 'tax', name: 'Impostos na nota',
      learn: '<b>Por fora:</b> o imposto é somado ao valor. <b>Por dentro:</b> o valor já inclui o imposto (o líquido é o que sobra). Alíquotas variam por estado, produto e regime tributário — os valores iniciais são <b>apenas exemplos</b>; confirme com seu contador.',
      fields: [
        { k: 'val', label: 'Valor base', type: 'number', pre: 'R$', def: '1000' },
        { k: 'mode', label: 'Tipo de cálculo', type: 'select', def: 'in', options: [['in', 'Por dentro (já incluso)'], ['out', 'Por fora (somar ao valor)']] },
        { k: 'icms', label: 'ICMS', type: 'number', suf: '%', def: '18', zero: true }, { k: 'ipi', label: 'IPI', type: 'number', suf: '%', def: '0', zero: true },
        { k: 'pis', label: 'PIS', type: 'number', suf: '%', def: '0,65', zero: true }, { k: 'cofins', label: 'COFINS', type: 'number', suf: '%', def: '3', zero: true },
        { k: 'iss', label: 'ISS', type: 'number', suf: '%', def: '0', zero: true },
      ],
      calc(v) {
        const T = [['ICMS', v.icms], ['IPI', v.ipi], ['PIS', v.pis], ['COFINS', v.cofins], ['ISS', v.iss]].filter((t) => t[1] > 0);
        const vals = T.map(([n, r]) => [n, r, (v.val * r) / 100]); const total = vals.reduce((a, t) => a + t[2], 0);
        const res = vals.map(([n, r, x]) => R(n.toLowerCase(), `${n} (${F.num(r)}%)`, x, F.money));
        res.unshift(R('total', 'Total de impostos', total, F.money, true));
        res.push(v.mode === 'in' ? R('net', 'Valor líquido', v.val - total, F.money) : R('gross', 'Valor com impostos', v.val + total, F.money));
        res.push(R('burden', 'Carga sobre o valor base', v.val ? (total / v.val) * 100 : 0, P4));
        return { results: res, note: 'Cálculo simplificado, sem substituição tributária, base reduzida ou cascata de impostos.', steps: vals.map(([n, r, x]) => `${n}: <code>${F.money(v.val)} × ${F.num(r)}% = ${F.money(x)}</code>`) };
      } },
    { id: 'discount', name: 'Descontos',
      learn: 'Dois descontos seguidos <b>não somam</b>: 10% + 10% = 19% (e não 20%), porque o segundo incide sobre o valor já reduzido. <code>Final = Preço·(1−d₁)·(1−d₂)</code>.',
      fields: [{ k: 'p', label: 'Preço original', type: 'number', pre: 'R$', def: '250' }, { k: 'd1', label: '1º desconto', type: 'number', suf: '%', def: '10' }, { k: 'd2', label: '2º desconto (opcional)', type: 'number', suf: '%', zero: true, def: '5' }],
      calc(v) {
        if (v.d1 >= 100 || v.d2 >= 100) throw uerr('Descontos devem ser menores que 100%.');
        const f = v.p * (1 - v.d1 / 100) * (1 - v.d2 / 100);
        return { results: [R('final', 'Preço final', f, F.money, true), R('save', 'Você economiza', v.p - f, F.money, false, 'up'), R('eff', 'Desconto efetivo', (1 - f / v.p) * 100, P4)], steps: [`Após o 1º: <code>${F.money(v.p * (1 - v.d1 / 100))}</code>`, `Após o 2º: <code>${F.money(f)}</code>`] };
      } },
    { id: 'split', name: 'Dividir a conta',
      learn: 'Divida a conta entre pessoas, com gorjeta opcional (o serviço de 10% é comum em restaurantes no Brasil).',
      fields: [{ k: 'total', label: 'Valor da conta', type: 'number', pre: 'R$', def: '240' }, { k: 'n', label: 'Nº de pessoas', type: 'number', def: '4' }, { k: 'tip', label: 'Gorjeta / serviço', type: 'number', suf: '%', zero: true, def: '10' }],
      calc(v) {
        const n = Math.round(v.n); if (n < 1) throw uerr('Informe ao menos 1 pessoa.');
        const tip = v.total * (v.tip / 100); const all = v.total + tip;
        return { results: [R('pp', 'Por pessoa', all / n, F.money, true), R('tip', 'Gorjeta total', tip, F.money), R('all', 'Total com gorjeta', all, F.money)], steps: [`Gorjeta: <code>${F.money(v.total)} × ${F.num(v.tip)}% = ${F.money(tip)}</code>`, `Por pessoa: <code>${F.money(all)} ÷ ${n} = ${F.money(all / n)}</code>`] };
      } },
  ];
  define({ id: 'business', name: 'Comercial', glyph: '%', desc: 'Porcentagem, margem, markup, impostos e descontos', sections });
})(typeof window !== 'undefined' ? window : globalThis);
