/* LilasDark - Conversor de unidades + Moedas */
(function (root) {
  'use strict';
  const { define, F, esc, countUp, recall, keep } = root.Tools;
  const U = {
    length: ['Comprimento', [['mm', 'milímetro', 0.001], ['cm', 'centímetro', 0.01], ['m', 'metro', 1], ['km', 'quilômetro', 1000], ['in', 'polegada', 0.0254], ['ft', 'pé', 0.3048], ['yd', 'jarda', 0.9144], ['mi', 'milha', 1609.344], ['nmi', 'milha náutica', 1852]]],
    mass: ['Massa', [['mg', 'miligrama', 1e-6], ['g', 'grama', 0.001], ['kg', 'quilograma', 1], ['t', 'tonelada', 1000], ['oz', 'onça', 0.028349523125], ['lb', 'libra', 0.45359237], ['@', 'arroba (15 kg)', 15]]],
    volume: ['Volume', [['mL', 'mililitro', 0.001], ['L', 'litro', 1], ['m³', 'metro cúbico', 1000], ['cs', 'colher de chá', 0.005], ['cS', 'colher de sopa', 0.015], ['xic', 'xícara (240 mL)', 0.24], ['floz', 'onça fluida (US)', 0.0295735295625], ['gal', 'galão (US)', 3.785411784]]],
    area: ['Área', [['cm²', 'cm²', 1e-4], ['m²', 'm²', 1], ['km²', 'km²', 1e6], ['ha', 'hectare', 10000], ['ac', 'acre', 4046.8564224], ['ft²', 'pé²', 0.09290304], ['alq', 'alqueire paulista', 24200]]],
    speed: ['Velocidade', [['m/s', 'metro/segundo', 1], ['km/h', 'quilômetro/hora', 1 / 3.6], ['mph', 'milha/hora', 0.44704], ['kn', 'nó', 1852 / 3600]]],
    time: ['Tempo', [['ms', 'milissegundo', 0.001], ['s', 'segundo', 1], ['min', 'minuto', 60], ['h', 'hora', 3600], ['d', 'dia', 86400], ['sem', 'semana', 604800], ['mês', 'mês (30,44 d)', 2629746], ['ano', 'ano (365,24 d)', 31556952]]],
    energy: ['Energia', [['J', 'joule', 1], ['kJ', 'quilojoule', 1000], ['cal', 'caloria', 4.184], ['kcal', 'quilocaloria', 4184], ['Wh', 'watt-hora', 3600], ['kWh', 'quilowatt-hora', 3.6e6], ['BTU', 'BTU', 1055.05585262]]],
    pressure: ['Pressão', [['Pa', 'pascal', 1], ['kPa', 'quilopascal', 1000], ['bar', 'bar', 1e5], ['atm', 'atmosfera', 101325], ['mmHg', 'mmHg', 133.322387415], ['psi', 'psi', 6894.757293168]]],
    power: ['Potência', [['W', 'watt', 1], ['kW', 'quilowatt', 1000], ['cv', 'cavalo-vapor', 735.49875], ['hp', 'horsepower', 745.69987158227], ['BTU/h', 'BTU/hora', 0.29307107]]],
    data: ['Dados', [['bit', 'bit', 0.125], ['B', 'byte', 1], ['KB', 'quilobyte (10³)', 1e3], ['MB', 'megabyte (10⁶)', 1e6], ['GB', 'gigabyte (10⁹)', 1e9], ['TB', 'terabyte (10¹²)', 1e12], ['KiB', 'kibibyte (2¹⁰)', 1024], ['MiB', 'mebibyte (2²⁰)', 1048576], ['GiB', 'gibibyte (2³⁰)', 1073741824], ['TiB', 'tebibyte (2⁴⁰)', 1099511627776]]],
    angle: ['Ângulo', [['°', 'grau', 1], ['rad', 'radiano', 180 / Math.PI], ['grad', 'grado', 0.9], ['volta', 'volta', 360]]],
    temp: ['Temperatura', [['°C', 'Celsius'], ['°F', 'Fahrenheit'], ['K', 'Kelvin'], ['°R', 'Rankine']]],
  };
  const toC = { '°C': (x) => x, '°F': (x) => ((x - 32) * 5) / 9, K: (x) => x - 273.15, '°R': (x) => ((x - 491.67) * 5) / 9 };
  const fromC = { '°C': (x) => x, '°F': (x) => (x * 9) / 5 + 32, K: (x) => x + 273.15, '°R': (x) => ((x + 273.15) * 9) / 5 };
  function convert(cat, val, from, to) {
    if (cat === 'temp') return fromC[to](toC[from](val));
    const u = U[cat][1]; const f = u.find((x) => x[0] === from), t = u.find((x) => x[0] === to);
    return (val * f[2]) / t[2];
  }
  const anim = () => document.body.dataset.anim !== 'off';

  define({
    id: 'convert', name: 'Conversor', glyph: '⇄', desc: 'Comprimento, massa, volume, temperatura, dados e mais', convert, UNITS: U,
    render(host, ctx) {
      const st = (this._g = this._g || Object.assign({ cat: 'length', val: '1', from: 'm', to: 'ft' }, recall('convert')));
      const draw = () => {
        const units = U[st.cat][1];
        if (!units.some((u) => u[0] === st.from)) st.from = units[0][0];
        if (!units.some((u) => u[0] === st.to)) st.to = units[Math.min(1, units.length - 1)][0];
        const opts = (sel) => units.map((u) => `<option value="${esc(u[0])}"${u[0] === sel ? ' selected' : ''}>${esc(u[1])} (${esc(u[0])})</option>`).join('');
        host.innerHTML = `<div class="thead"><div class="tg">⇄</div><div><h2>Conversor</h2><p>Escolha a grandeza, digite o valor e troque as unidades.</p></div></div>
          <div class="stabs">${Object.entries(U).map(([k, v]) => `<button data-c="${k}" class="${k === st.cat ? 'on' : ''}">${v[0]}</button>`).join('')}</div>
          <div class="sbody enter"><div class="cv">
            <label class="fld"><span class="fl">Valor</span><span class="inp"><input id="cvV" value="${esc(st.val)}" inputmode="decimal" autocomplete="off"></span></label>
            <div class="cvrow"><label class="fld"><span class="fl">De</span><span class="inp"><select id="cvF">${opts(st.from)}</select></span></label>
            <button class="swap" id="cvS" title="Trocar unidades">⇅</button>
            <label class="fld"><span class="fl">Para</span><span class="inp"><select id="cvT">${opts(st.to)}</select></span></label></div></div>
            <div class="out fresh"><div class="rgrid"><div class="rc main"><span class="rl" id="cvL"></span><span class="rv" id="cvR"></span></div></div>
            <div class="tblw"><div class="cap">Todas as conversões</div><div class="tbl"><table><tbody id="cvA"></tbody></table></div></div>
            <div class="oact"><button class="mini" id="cvSave">Salvar no histórico</button><button class="mini" id="cvCopy">Copiar resultado</button></div></div></div>`;
        run(false);
      };
      let prev = NaN;
      function run(animate) {
        keep('convert', st);
        const v = F.parse(st.val); const R = host.querySelector('#cvR'); const A = host.querySelector('#cvA');
        if (Number.isNaN(v)) { R.textContent = '—'; A.innerHTML = ''; host.querySelector('#cvL').textContent = 'Digite um valor'; return; }
        const r = convert(st.cat, v, st.from, st.to); host.querySelector('#cvL').textContent = `${F.sci(v)} ${st.from} =`;
        if (animate) countUp(R, prev, r, (x) => `${F.sci(x)} ${st.to}`); else R.textContent = `${F.sci(r)} ${st.to}`; prev = r;
        A.innerHTML = U[st.cat][1].map((u) => `<tr data-u="${esc(u[0])}" class="${u[0] === st.to ? 'on' : ''}"><td>${esc(u[1])}</td><td>${esc(F.sci(convert(st.cat, v, st.from, u[0])))} ${esc(u[0])}</td></tr>`).join('');
        host._res = `${F.sci(v)} ${st.from} = ${F.sci(r)} ${st.to}`;
      }
      host.onclick = (e) => {
        const c = e.target.closest('[data-c]'); if (c) { st.cat = c.dataset.c; const u = U[st.cat][1]; st.from = u[0][0]; st.to = u[Math.min(1, u.length - 1)][0]; return draw(); }
        if (e.target.closest('#cvS')) { [st.from, st.to] = [st.to, st.from]; const b = e.target.closest('#cvS'); b.classList.add('spin'); setTimeout(draw, anim() ? 260 : 0); return; }
        const row = e.target.closest('tr[data-u]'); if (row) { st.to = row.dataset.u; host.querySelector('#cvT').value = st.to; return run(true); }
        if (e.target.closest('#cvSave')) ctx.save({ expr: `Conversor · ${U[st.cat][0]}`, res: host._res, mode: 'convert' });
        if (e.target.closest('#cvCopy')) navigator.clipboard.writeText(host._res || '').then(() => ctx.toast('Resultado copiado'));
      };
      host.oninput = (e) => { if (e.target.id === 'cvV') { st.val = e.target.value; run(true); } };
      host.onchange = (e) => { if (e.target.id === 'cvF') st.from = e.target.value; else if (e.target.id === 'cvT') st.to = e.target.value; else return; run(true); };
      draw();
    },
  });

  /* ---------- Moedas ---------- */
  const CUR = [['BRL', 'Real brasileiro'], ['USD', 'Dólar americano'], ['EUR', 'Euro'], ['GBP', 'Libra esterlina'], ['ARS', 'Peso argentino'], ['CLP', 'Peso chileno'], ['UYU', 'Peso uruguaio'], ['PYG', 'Guarani paraguaio'], ['COP', 'Peso colombiano'], ['MXN', 'Peso mexicano'], ['CAD', 'Dólar canadense'], ['AUD', 'Dólar australiano'], ['CHF', 'Franco suíço'], ['JPY', 'Iene japonês'], ['CNY', 'Yuan chinês'], ['INR', 'Rupia indiana'], ['ZAR', 'Rand sul-africano'], ['AED', 'Dirham dos Emirados'], ['TRY', 'Lira turca'], ['SEK', 'Coroa sueca']];
  const KEY = 'lilasdark.rates';
  const rateConvert = (amount, from, to, rates) => (amount / rates[from]) * rates[to];
  define({
    id: 'currency', name: 'Moedas', glyph: '$', desc: 'Cotações de referência atualizadas pela internet', rateConvert,
    render(host, ctx) {
      const st = (this._g = this._g || Object.assign({ amt: '100', from: 'USD', to: 'BRL' }, recall('currency'), { manual: '' }));
      let cache = null; try { cache = JSON.parse(localStorage.getItem(KEY)); } catch (_) {}
      let status = '';
      const stamp = (t) => new Date(t).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
      const opts = (sel) => CUR.map((c) => `<option value="${c[0]}"${c[0] === sel ? ' selected' : ''}>${c[0]} · ${c[1]}</option>`).join('');
      const build = () => {
        host.innerHTML = `<div class="thead"><div class="tg">$</div><div><h2>Moedas</h2><p>Converta entre moedas com cotação de referência.</p></div></div>
          <div class="sbody enter"><details class="learn"><summary>Como funciona</summary><div>As cotações vêm de uma fonte pública e servem de <b>referência</b>. Bancos e casas de câmbio aplicam <b>spread</b> e, em compras internacionais, <b>IOF</b>, então o valor final costuma ser diferente. Sem internet, o app usa a última cotação salva ou a que você informar manualmente.</div></details>
          <div class="cv"><label class="fld"><span class="fl">Valor</span><span class="inp"><input id="cuA" value="${esc(st.amt)}" inputmode="decimal" autocomplete="off"></span></label>
          <div class="cvrow"><label class="fld"><span class="fl">De</span><span class="inp"><select id="cuF">${opts(st.from)}</select></span></label><button class="swap" id="cuS" title="Trocar moedas">⇅</button>
          <label class="fld"><span class="fl">Para</span><span class="inp"><select id="cuT">${opts(st.to)}</select></span></label></div>
          <label class="fld"><span class="fl">Cotação manual (opcional)</span><span class="inp"><em>1 ${st.from} =</em><input id="cuM" value="${esc(st.manual)}" inputmode="decimal" placeholder="usa a cotação da internet" autocomplete="off"><em>${st.to}</em></span></label></div>
          <div class="out fresh"><div class="rgrid"><div class="rc main"><span class="rl" id="cuL"></span><span class="rv" id="cuR">—</span></div></div>
          <div class="rstat"><span id="cuSt"></span><button class="mini" id="cuRef">Atualizar cotações</button></div>
          <div class="tblw"><div class="cap">Em outras moedas</div><div class="tbl"><table><tbody id="cuTb"></tbody></table></div></div>
          <div class="oact"><button class="mini" id="cuSave">Salvar no histórico</button></div></div></div>`;
        calc(false);
      };
      let prev = NaN;
      function calc(animate) {
        const a = F.parse(st.amt); const man = F.parse(st.manual); const rates = cache && cache.rates;
        const R = host.querySelector('#cuR'); const tb = host.querySelector('#cuTb');
        host.querySelector('#cuSt').textContent = status || (cache ? `Cotação de ${stamp(cache.ts)}` : 'Sem cotações — conecte-se ou informe manualmente');
        keep('currency', { amt: st.amt, from: st.from, to: st.to }); R.classList.toggle('skel', status.startsWith('Buscando'));
        if (Number.isNaN(a)) { R.textContent = '—'; tb.innerHTML = ''; host.querySelector('#cuL').textContent = 'Digite um valor'; return; }
        let r = NaN;
        if (!Number.isNaN(man) && man > 0) r = a * man; else if (rates && rates[st.from] && rates[st.to]) r = rateConvert(a, st.from, st.to, rates);
        host.querySelector('#cuL').textContent = `${F.num(a, 2)} ${st.from} =`;
        const money = (x) => `${F.num(x, 2)} ${st.to}`;
        if (Number.isNaN(r)) R.textContent = 'sem cotação'; else if (animate) countUp(R, prev, r, money); else R.textContent = money(r);
        prev = r; host._res = Number.isNaN(r) ? '' : `${F.num(a, 2)} ${st.from} = ${money(r)}`;
        tb.innerHTML = rates ? ['BRL', 'USD', 'EUR', 'GBP', 'ARS', 'JPY', 'CAD', 'CHF'].filter((c) => c !== st.from && rates[c]).map((c) => `<tr data-u="${c}"><td>${c}</td><td>${F.num(rateConvert(a, st.from, c, rates), 2)}</td></tr>`).join('') : '';
      }
      async function refresh(force) {
        if (!ctx.api.getRates) return;
        if (!force && cache && Date.now() - cache.ts < 6 * 3600e3) return;
        const btn = host.querySelector('#cuRef'); if (btn) btn.classList.add('busy'); status = 'Buscando cotações…'; calc(false);
        try {
          const r = await ctx.api.getRates();
          if (r && r.ok) { cache = { ts: r.ts, rates: r.rates }; try { localStorage.setItem(KEY, JSON.stringify(cache)); } catch (_) {} status = ''; }
          else status = cache ? `Sem conexão — usando cotação de ${stamp(cache.ts)}` : 'Sem conexão e sem cotação salva';
        } catch (_) { status = cache ? `Sem conexão — usando cotação de ${stamp(cache.ts)}` : 'Sem conexão e sem cotação salva'; }
        if (host.isConnected && host.querySelector('#cuR')) { const b = host.querySelector('#cuRef'); if (b) b.classList.remove('busy'); calc(true); }
      }
      host.onclick = (e) => {
        if (e.target.closest('#cuS')) { [st.from, st.to] = [st.to, st.from]; st.manual = ''; return build(); }
        if (e.target.closest('#cuRef')) return refresh(true);
        const row = e.target.closest('tr[data-u]'); if (row) { st.to = row.dataset.u; st.manual = ''; return build(); }
        if (e.target.closest('#cuSave') && host._res) ctx.save({ expr: 'Moedas', res: host._res, mode: 'currency' });
      };
      host.oninput = (e) => { if (e.target.id === 'cuA') st.amt = e.target.value; else if (e.target.id === 'cuM') st.manual = e.target.value; else return; calc(true); };
      host.onchange = (e) => { if (e.target.id === 'cuF') { st.from = e.target.value; st.manual = ''; } else if (e.target.id === 'cuT') { st.to = e.target.value; st.manual = ''; } else return; build(); };
      build(); refresh(false);
    },
  });
})(typeof window !== 'undefined' ? window : globalThis);
