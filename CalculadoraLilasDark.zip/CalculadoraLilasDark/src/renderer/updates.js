/* LilasDark - Central de Atualizações, Sobre e "O que mudou" */
(() => {
  'use strict';
  const api = window.lilas || {}; const UI = window.LilasUI;
  if (!api.upd || !UI) return;
  const $ = (s) => document.querySelector(s); const esc = UI.esc;
  let st = { state: 'idle' }; let cfg = { autoCheck: true, channel: 'stable' };
  const when = (t) => (t ? new Date(t).toLocaleString('pt-BR') : 'nunca');
  const busy = () => st.state === 'checking' || st.state === 'downloading';
  const mdLite = (text) => { // markdown mínimo e seguro: títulos em **negrito**, listas com "- " e `código`
    let html = '', open = false;
    const inl = (s) => esc(s).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/`(.+?)`/g, '<code>$1</code>');
    for (const raw of String(text).split('\n')) {
      const l = raw.trim(); if (!l) continue;
      if (l.startsWith('- ')) { if (!open) { html += '<ul>'; open = true; } html += `<li>${inl(l.slice(2))}</li>`; }
      else { if (open) { html += '</ul>'; open = false; } html += `<h5>${inl(l)}</h5>`; }
    }
    return html + (open ? '</ul>' : '');
  };
  const headline = (s) => ({
    checking: ['Verificando…', 'Consultando a versão mais recente.'],
    available: [`Versão ${s.version} disponível`, 'Baixe para instalar.'],
    downloading: [`Baixando ${s.version || 'atualização'}… ${s.percent || 0}%`, 'Você pode continuar usando o app.'],
    ready: [`Versão ${s.version} pronta`, 'Reinicie para concluir a instalação. Ela também é instalada ao fechar o app.'],
    none: ['Você está na versão mais recente', `Versão ${s.current || '—'}`],
    skipped: [`Versão ${s.version} ignorada`, 'Você escolheu pular esta versão.'],
    error: ['Não foi possível atualizar', s.error || ''],
    dev: ['Atualizações só no app instalado', 'Você está executando em modo de desenvolvimento.'],
  }[s.state] || ['Pronto para verificar', `Versão instalada: ${s.current || '—'}`]);

  function centerHTML() {
    const s = st; const [t, sub] = headline(s); const pct = Math.max(0, Math.min(100, s.percent | 0));
    const b = [];
    if (s.state === 'ready') b.push('<button class="mini pri" data-u="install">Reiniciar e atualizar</button>');
    if (s.state === 'available') b.push('<button class="mini pri" data-u="download">Baixar atualização</button>', '<button class="mini" data-u="skip">Pular esta versão</button>');
    if (s.state === 'skipped') b.push('<button class="mini pri" data-u="download">Baixar mesmo assim</button>');
    if (s.state === 'error') b.push('<button class="mini pri" data-u="manual">Baixar manualmente</button>');
    b.push(`<button class="mini" data-u="check"${busy() ? ' disabled' : ''}>Verificar agora</button>`);
    return `<div class="mbox" id="updCenter" role="dialog" aria-label="Central de atualizações"><div class="mhead"><h3>Central de atualizações</h3><button class="icon" data-close aria-label="Fechar">✕</button></div>
      <div class="ucard ${esc(s.state)}"><div class="ubig">${esc(t)}</div><div class="usub">${esc(sub)}</div>
      ${s.state === 'downloading' ? `<div class="prog"><i style="width:${pct}%"></i></div>` : ''}${s.state === 'checking' ? '<div class="prog ind"><i></i></div>' : ''}
      <div class="uact">${b.join('')}</div></div>
      ${s.notes && ['available', 'downloading', 'ready', 'skipped'].includes(s.state) ? `<h4>Novidades da versão ${esc(s.version)}</h4><div class="notes">${mdLite(s.notes)}</div>` : ''}
      <h4>Preferências</h4>
      <div class="set"><span>Verificar automaticamente<small>Ao abrir o app e a cada 4 horas</small></span><button class="sw${cfg.autoCheck ? ' on' : ''}" data-u="auto" role="switch" aria-checked="${!!cfg.autoCheck}"></button></div>
      <div class="set"><span>Canal de atualização<small>Beta recebe versões em teste antes das estáveis</small></span><select data-u-chan><option value="stable"${cfg.channel === 'stable' ? ' selected' : ''}>Estável</option><option value="beta"${cfg.channel === 'beta' ? ' selected' : ''}>Beta</option></select></div>
      <div class="usub" style="margin-top:12px">Versão instalada: <b>${esc(s.current || '—')}</b> · Última verificação: ${esc(when(s.lastCheck))}</div>
      <div class="uact"><button class="mini" data-u="logs">Abrir pasta de logs</button><button class="mini" data-u="about">Sobre</button></div></div>`;
  }
  const centerOpen = () => !$('#modal').hidden && !!$('#updCenter');
  async function openCenter() { [cfg, st] = await Promise.all([api.upd.settings(), api.upd.state()]); UI.openModal(centerHTML()); }
  async function openAbout() {
    const i = await api.appInfo();
    UI.openModal(`<div class="mbox about" role="dialog" aria-label="Sobre"><div class="mhead"><span></span><button class="icon" data-close aria-label="Fechar">✕</button></div>
      <img id="aboutLogo" src="../../imagens/Logo.png" alt=""><h3>LilasDark | Calculadora</h3><div class="usub">Versão ${esc(i.version)}</div>
      <div class="ainfo"><span>Electron</span><b>${esc(i.electron)}</b><span>Chromium</span><b>${esc(i.chrome)}</b><span>Node.js</span><b>${esc(i.node)}</b><span>Sistema</span><b>${esc(i.platform)}</b><span>Instalação</span><b>${i.packaged ? 'Instalado' : 'Modo de desenvolvimento'}</b><span>Licença</span><b>MIT — © ${new Date().getFullYear()} Marcos Simionatto</b></div>
      <div class="priv"><b>Privacidade:</b> o LilasDark funciona offline e não coleta nem envia dados dos seus cálculos. As únicas conexões externas são ao GitHub (verificar e baixar atualizações) e a serviços públicos de câmbio (apenas no modo Moedas).</div>
      <div class="aact"><button class="mini" data-ab="upd">Central de atualizações</button><button class="mini" data-ab="news">Ver novidades</button><button class="mini" data-ab="issues">Reportar problema</button><button class="mini" data-ab="repo">Repositório</button><button class="mini" data-ab="logs">Abrir pasta de logs</button></div>
      <div class="usub" style="margin-top:12px">Desenvolvido por Marcos Simionatto</div></div>`);
    const im = $('#aboutLogo'); const hide = () => { im.style.display = 'none'; }; im.addEventListener('error', hide); if (im.complete && im.naturalWidth === 0) hide();
  }
  async function showNews(auto) {
    const w = await api.whatsNew();
    if (!w || !w.notes) { if (!auto) UI.toast('Sem notas para esta versão'); return; }
    UI.openModal(`<div class="mbox" role="dialog" aria-label="O que mudou"><div class="mhead"><h3>O que mudou na versão ${esc(w.version)}</h3><button class="icon" data-close aria-label="Fechar">✕</button></div><div class="notes">${mdLite(w.notes)}</div><div class="uact"><button class="mini pri" data-close>Entendi</button></div></div>`);
    if (auto) api.ackWhatsNew();
  }

  function onStatus(s) {
    const prev = st.state; st = s;
    const dot = $('#dotUpd'); if (dot) { dot.hidden = !['ready', 'available'].includes(s.state); $('#btnSettings').title = dot.hidden ? 'Configurações e ajuda' : 'Configurações — há uma atualização'; }
    if (centerOpen()) $('#modal').innerHTML = centerHTML();
    if (s.state === 'ready' && prev !== 'ready') UI.toast(`Atualização ${s.version} pronta`, { label: 'Reiniciar e atualizar', fn: () => api.upd.install() });
    else if (s.state === 'available' && prev !== 'available' && s.manual) UI.toast(`Versão ${s.version} disponível`, { label: 'Abrir', fn: openCenter });
    if (s.manual && prev === 'checking') {
      if (s.state === 'none') UI.toast('Você já está na versão mais recente');
      else if (s.state === 'dev') UI.toast('Atualizações funcionam no app instalado');
      else if (s.state === 'error') UI.toast(s.error, { label: 'Baixar manualmente', fn: () => api.openLink('releases') });
    }
  }
  document.addEventListener('click', async (e) => {
    const u = e.target.closest('[data-u]'); const ab = e.target.closest('[data-ab]');
    if (u) {
      const a = u.dataset.u;
      if (a === 'check') await api.upd.check(); else if (a === 'download') await api.upd.download(); else if (a === 'install') await api.upd.install(); else if (a === 'skip') await api.upd.skip();
      else if (a === 'manual') await api.openLink('releases'); else if (a === 'logs') await api.openLogs(); else if (a === 'about') openAbout();
      else if (a === 'auto') { cfg = await api.upd.setSettings({ autoCheck: !cfg.autoCheck }); if (centerOpen()) $('#modal').innerHTML = centerHTML(); }
    } else if (ab) {
      const a = ab.dataset.ab;
      if (a === 'upd') openCenter(); else if (a === 'news') showNews(false); else if (a === 'logs') api.openLogs(); else api.openLink(a);
    }
  });
  document.addEventListener('change', async (e) => { if (e.target.matches('[data-u-chan]')) { cfg = await api.upd.setSettings({ channel: e.target.value }); if (centerOpen()) $('#modal').innerHTML = centerHTML(); } });

  api.upd.onStatus(onStatus);
  api.upd.state().then((s) => { st = s; onStatus(s); });
  api.upd.settings().then((c) => { cfg = c; });
  api.whatsNew().then((w) => { if (w && w.show) setTimeout(() => { if ($('#modal').hidden && $('#tour').hidden) showNews(true); }, 2200); });
  window.LilasUpdates = { open: openCenter, about: openAbout, news: () => showNews(false) };
})();
