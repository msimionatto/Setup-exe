# LilasDark | Calculadora

Calculadora desktop (Electron + JavaScript) com tema lilás escuro, 11 modos e foco em uso profissional.

## Modos
| Modo | O que faz |
|---|---|
| **Normal** | Operações, %, memória (MC/MR/M+/M−/MS) |
| **Científica** | Trigonometria (DEG/RAD/GRAD) e inversas, hiperbólicas, ln/log, potências, raízes, n!, nPr, nCr, mod, EXP, π, e, Ans |
| **Química** | Massa molar de qualquer fórmula, composição %, mol↔g↔partículas, constantes, pH |
| **Programador** | HEX/DEC/OCT/BIN, AND/OR/XOR/NOT, deslocamentos |
| **Financeira** | Juros compostos/simples, Price × SAC (com tabela), VP/VF, taxas equivalentes + taxa real, VPL/TIR/Payback, meta de poupança |
| **Conversor** | 12 grandezas (comprimento, massa, volume, área, velocidade, tempo, energia, pressão, potência, dados, ângulo, temperatura) |
| **Moedas** | Cotações de referência pela internet (com cache offline e cotação manual) |
| **Datas e horas** | Diferença entre datas, dias úteis (com feriados nacionais), somar/subtrair, idade, horas trabalhadas |
| **Comercial** | Porcentagem, preço de venda (markup), margem, impostos na nota, descontos, dividir conta |
| **Gráficos** | Até 3 funções, zoom (roda) e arrastar, raízes automáticas, leitura de valores |
| **Matemática** | 1º e 2º grau, sistemas (Gauss-Jordan), matrizes, estatística, regressão, frações, MDC/MMC/fatoração |

## Recursos gerais
- **Educativo:** cada ferramenta tem *Como funciona* (fórmula + exemplo) e *Passo a passo*; teclas com dicas ao passar o mouse; tutorial guiado na primeira abertura.
- **Histórico, Lixeira e Variáveis/Fórmulas** (use `preco*1,12` nas contas).
- **Baixar conta:** texto + print (.txt + .png), PDF, Excel (.xlsx) ou fita para impressão.
- **5 temas** (Lilás Escuro/Claro, Meia-noite, Grafite, Esmeralda) com revelação circular, formato brasileiro (1.234,56), casas decimais, animações (respeita "reduzir animações" do Windows), som opcional e atalho global `Ctrl+Alt+L`.
- **Entradas salvas:** o que você digita em cada ferramenta volta na próxima abertura.
- **Programador em 64 bits exatos** (BigInt).
- **Atualização automática** pelo GitHub Releases: Central de atualizações (progresso, pular versão, canal Estável/Beta), tela "O que mudou", "Sobre", log em arquivo e mensagens de erro claras. Veja `ATUALIZACOES.md`.
- Atalhos: `Enter`, `Esc`, `Backspace`, `Del`, `Ctrl+H`, `Ctrl+S`, `Ctrl+C`, `P` (π).

## Rodando
```bash
npm install
npm start
npm test        # testes do motor, das ferramentas e da segurança
npm run lint    # ESLint
```

## Imagens
Coloque em `imagens/`: `Logo.png` (logo no app, relatórios e Excel) e `Logo.ico` (ícone, ideal 256×256).

## Gerar instalador / publicar versão
```bash
npm run dist                      # instalador local em dist/
set GH_TOKEN=seu_token            # PowerShell: $env:GH_TOKEN="seu_token"
npm run release                   # publica no GitHub Releases (habilita o auto-update)
# ou crie a tag: git tag v2.2.0 && git push --tags  (o workflow publica sozinho)
```

> Veja `ANALISE.md` (estado do projeto e pendências) e `CHANGELOG.md`.

> Impostos e cotações são **referências**; confirme alíquotas com seu contador e taxas com a instituição.

Desenvolvido por Marcos Simionatto
